-----------------------------------------------------------------------------------------------
-- Client Lua Script for BijiPlates
-- Copyright (c) NCsoft. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
require "ChallengesLib"
require "Unit"
require "GameLib"
require "Apollo"
require "PathMission"
require "Quest"
require "Episode"
require "math"
require "string"
require "DialogSys"
require "PublicEvent"
require "PublicEventObjective"
require "CommunicatorLib"
require "Tooltip"
require "GroupLib"
require "PlayerPathLib"
require "GuildLib"
require "GuildTypeLib"
 
local BijiPlates = {} 

-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
local karPathSprite =
{
	[PlayerPathLib.PlayerPathType_Soldier] 		= "CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSol",
	[PlayerPathLib.PlayerPathType_Settler] 		= "CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSet",
	[PlayerPathLib.PlayerPathType_Scientist] 	= "CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSci",
	[PlayerPathLib.PlayerPathType_Explorer] 	= "CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathExp",
}

-- Acceptable window heights per font.
local fontHeight = {
	["CRB_Pixel"] 		= 14,
	["CRB_Interface9"]  = 15,
	["CRB_Interface10"] = 17,
	["CRB_Interface11"] = 18,
	["CRB_Interface12"] = 19,
	["CRB_Interface14"] = 22,
	["Nameplates"]		= 15,
}

local healthTexture = {
	"Flat_Health",
	"BijiGrad_1",
	"BijiGrad_2",
	"BijiGrad_3",
	"BijiGrad_4",
	"WhiteFill",
	"BijiGrad_5",
	"BijiGrad_6",
	"BijiGrad_7",
	"BijiGrad_8",
	"BijiGrad_9",
	"BijiGrad_10",
	"BijiGrad_11",
	"BijiGrad_12",
}

local shieldTexture = {
	"Flat_Shield",
	"BijiGrad_1s",
	"BijiGrad_2s",
	"BijiGrad_3s",
	"BijiGrad_4s",
	"WhiteFill",
	"BijiGrad_5",
	"BijiGrad_6",
	"BijiGrad_7",
	"BijiGrad_8",
	"BijiGrad_9s",
	"BijiGrad_10s",
	"BijiGrad_11s",
	"BijiGrad_12s",
}

local className = {
	["4"] = "[md] ",
	["3"] = "[es] ",
	["7"] = "[ss] ",
	["1"] = "[wr] ",
	["5"] = "[st] ",
	["2"] = "[en] ",
}

local bDebug = false; -- Am I in debug mode? 
local bCheckUnit = false;
local bCheckBuffs = false;

local restored = false; -- Restored user settings yet?

local updateBuffs = false; -- Can update buffs yet?
local buffUpdateInterval = 0.50; -- Interval to update buffs related function (seconds)

local trackMaster = false; -- Is trackmaster installed?
local subdued = false;
local subduedSent = false;

local knTargetRange = 40000 -- the distance^2 that normal nameplates should draw within (max targeting range)

-- Not using yet, maybe a todo.
local PlateType = {
	["Neutral"] = 0,
	
	["Friendly"] = 1,
	["FriendlyPlayer"] = 2,
	["FriendlyPet"] = 3,
	
	["Hostile"] = 4,
	["HostilePlayer"] = 5,
	["HostilePet"] = 6,
}

local myUserSettings = {
	--General Settings
	"setNeverShow",
	"setEnableOcclusion", --Buggy right now
	"setWotWThrottle",
	"setCombatSelf",
	
	"setDrawDistance", --Draw distance
	"setPlateScale",
	"setHealthCutoff", --Cutoff to change color
	"setBuffCutoff",
	
	"setShowTitles",
	"setShowIcons", 
	"setShowHealth",
	"setShowHealthPercent",
	"setShowShield",
	"setShowShieldPercent",
	"setShowLevel",
	"setShowArmor",
	
	"setIconQuest",
	"setIconMission",
	"setIconFriend",
	"setIconEvent",
	"setIconChallenge",
	"setIconRival",
	
	-- tank options
	"setShowThreatAlert",
	-- healer options
	"setShowCleanseAlert",
	"setHideFullFriendlyBars",
	
	"setPlateOpacity", -- nothing yet
	
	"setShowMyPets",
	"setShowFriendlyPets",
	"setShowHostilePets",
	
	-- STYLE SETTINGS
	"setStyle",
	
	"setSAOSize",
	
	"setFlatHealthTexture",
	"setFlatShieldTexture",
	"setFlatWidth",
	"setFlatHealthHeight",
	"setFlatShieldHeight",
	
	"setUnitNameFont",
	"setUnitNameFontType",
	"setUnitGuildFont",
	"setUnitGuildFontType",
	
	--Targeted Settings
	"setT_M", -- My Targets Marker
	"setT_N", -- My Targets Name
	"setT_G", -- My Targets Guild
	"setT_B", -- My Targets Bars
	"setT_C", -- My Targets Cast Bar
	"setT_D", -- My Targets Debuffs/Buffs
	
	--My Nameplate Settings
	"setM_N", "setM_N_C", -- My Name / Combat Only
	"setM_G", "setM_G_C", -- My Guild / Combat Only
	"setM_B", "setM_B_C", -- My Bars / Combat Only
	"setM_C", "setM_C_C", -- My Cast Bar / Combat Only
	"setM_D", "setM_D_C", -- My Cast Bar / Combat Only
	"setM_R", "setM_R_C", -- My Cast Bar / Combat Only
	
	--Neutral Nameplate Settings
	"setN_N", "setN_N_C", -- Neutral Name / Combat Only
	"setN_G", "setN_G_C", -- Neutral Guild / Combat Only
	"setN_B", "setN_B_C", -- Neutral Bars / Combat Only
	"setN_C", "setN_C_C", -- Neutral Cast Bar / Combat Only
	"setN_D", "setN_D_C", -- Neutral Cast Bar / Combat Only
	
	--Friendly Nameplate Settings
	"setF_N", "setF_N_C", -- Friendly Name / Combat Only
	"setF_G", "setF_G_C", -- Friendly Guild / Combat Only
	"setF_B", "setF_B_C", -- Friendly Bars / Combat Only
	"setF_C", "setF_C_C", -- Friendly Cast Bar / Combat Only
	"setF_D", "setF_D_C", -- Friendly Cast Bar / Combat Only
	"setF_Important",	  -- Always show important NPC Name & Guild
		--Friendly Player Nameplate Settings
		"setFP_N", "setFP_N_C", -- Friendly Player Name / Combat Only
		"setFP_G", "setFP_G_C", -- Friendly Player Guild / Combat Only
		"setFP_B", "setFP_B_C", -- Friendly Player Bars / Combat Only
		"setFP_C", "setFP_C_C", -- Friendly Player Cast Bar / Combat Only
		"setFP_D", "setFP_D_C", -- Friendly Player Debuff Bar / Combat Only
		"setFP_CN", "setFP_CN_C", -- Friendly Player Class Name / Combat Only
		
		--PARTY Player Nameplate Settings
		"setPP_N", "setPP_N_C", -- PARTY Player Name / Combat Only
		"setPP_G", "setPP_G_C", -- PARTY Player Guild / Combat Only
		"setPP_B", "setPP_B_C", -- PARTY Player Bars / Combat Only
		"setPP_C", "setPP_C_C", -- PARTY Player Cast Bar / Combat Only
		"setPP_D", "setPP_D_C", -- PARTY Player Debuff Bar / Combat Only
		"setPP_CN", "setPP_CN_C", -- PARTY Player Class Name / Combat Only
		
	--Hostile Nameplate Settings
	"setH_N", "setH_N_C", -- Hostile Name / Combat Only
	"setH_G", "setH_G_C", -- Hostile Guild / Combat Only
	"setH_B", "setH_B_C", -- Hostile Bars / Combat Only
	"setH_C", "setH_C_C", -- Hostile Cast Bar / Combat Only
	"setH_D", "setH_D_C", -- Hostile Cast Bar / Combat Only
		--Hostile Player Nameplate Settings
		"setHP_N", "setHP_N_C", -- Hostile Player Name / Combat Only
		"setHP_G", "setHP_G_C", -- Hostile Player Guild / Combat Only
		"setHP_B", "setHP_B_C", -- Hostile Player Bars / Combat Only
		"setHP_C", "setHP_C_C", -- Hostile Player Cast Bar / Combat Only
		"setHP_D", "setHP_D_C", -- Hostile Player Debuff Bar / Combat Only
		"setHP_CN", "setHP_CN_C", -- Hostile Player Class Name / Combat Only
		
	--Color Settings
	"setOpacity", -- TODO: after.
	"setColorBackgroundBar",
	"setColorBackdropBar",
	"setColorShieldBar",
	"setColorShieldBar",
	"setColorAbsorbBar",
	"setColorVulnerableBar",
	"setColorVulnerableTimerBar",
	"setColorCastBar",
	
	"setColorNeutralName",
	"setColorNeutralBar",
	"setColorNeutralBarCutoff",
	
	"setColorFriendlyName",
	"setColorFriendlyBar",
	"setColorFriendlyBarCutoff",
	
	"setColorFriendlyPlayerName",
	"setColorFriendlyPlayerNameUnflagged", -- friendly player not flagged for pvp
	"setColorFriendlyPlayerBar",
	"setColorFriendlyPlayerBarCutoff",
	
	"setColorHostileName",
	"setColorHostileBar",
	"setColorHostileBarCutoff",
	
	"setColorHostilePlayerName",
	"setColorHostilePlayerNameUnflagged", -- hostile player not flagged for pvp
	"setColorHostilePlayerBar",
	"setColorHostilePlayerBarCutoff",
	
	"setColorPartyName", -- player is in your party
	"setColorGuildName", -- player is in your guild
	"setColorFriendName", -- player is in your friends list
	"setColorRivalName", -- player is in your rivals list
	
	
	"setShowClassColors",
	
	"setColorWarriorBar",
	"setColorStalkerBar",
	"setColorEngineerBar",
	
	"setColorEsperBar",
	"setColorSpellslingerBar",
	"setColorMedicBar",
}

 
-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function BijiPlates:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 
    return o
end


function BijiPlates:Init()
    Apollo.RegisterAddon(self, true)
end
 

-----------------------------------------------------------------------------------------------
-- BijiPlates OnLoad
-----------------------------------------------------------------------------------------------
function BijiPlates:OnLoad()
	self.playerUnit = nil

    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)
	Apollo.RegisterEventHandler("UnitGibbed",					"OnUnitGibbed", self)

	Apollo.RegisterSlashCommand("BijiPlates", 					"OnBijiPlatesOn", self)
	Apollo.RegisterSlashCommand("Bijiplates", 					"OnBijiPlatesOn", self)
	Apollo.RegisterSlashCommand("bijiplates", 					"OnBijiPlatesOn", self)
	
    Apollo.RegisterEventHandler("UnitCreated", 					"OnUnitCreated", self)
	Apollo.RegisterEventHandler("UnitDestroyed", 				"OnUnitDestroyed", self)
	Apollo.RegisterEventHandler("UnitTextBubbleCreate", 		"OnUnitTextBubbleToggled", self)
	Apollo.RegisterEventHandler("UnitTextBubblesDestroyed", 	"OnUnitTextBubbleToggled", self)
	Apollo.RegisterEventHandler("TargetUnitChanged", 			"OnTargetUnitChanged", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", 			"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("VarChange_FrameCount", 		"OnFrame", self)
	Apollo.RegisterEventHandler("UnitNameChanged", 				"OnUnitNameChanged", self)
	Apollo.RegisterEventHandler("KeyBindingKeyChanged", 		"OnKeyBindingUpdated", self)
	Apollo.RegisterEventHandler("UnitPvpFlagsChanged", 			"OnUnitPvpFlagsChanged", self)
	Apollo.RegisterEventHandler("UnitTitleChanged", 			"OnUnitTitleChanged", self)
	Apollo.RegisterEventHandler("PlayerTitleChange", 			"OnPlayerTitleChanged", self)
	Apollo.RegisterEventHandler("UnitGuildNameplateChanged", 	"OnUnitGuildNameplateChanged",self)
	Apollo.RegisterEventHandler("ApplyCCState", 				"OnApplyCCState", self)
	Apollo.RegisterEventHandler("RemoveCCState", 				"OnRemoveCCState", self)
	Apollo.RegisterEventHandler("UnitLevelChanged", 			"OnUnitLevelChanged", self)

	Apollo.RegisterEventHandler("UnitMemberOfGuildChange", 		"OnUnitMemberOfGuildChange", self)
	Apollo.RegisterEventHandler("GuildChange", 					"OnGuildChange", self)  -- notification that a guild was added / removed.
	Apollo.RegisterEventHandler("ChangeWorld", 					"OptionsChanged", self)
	
	Apollo.RegisterEventHandler("CharacterCreated", 			"OptionsChanged", self)

	-- These events update the reward icons/quest framing
	Apollo.RegisterEventHandler("QuestInit", 					"OnQuestInit", self)
	Apollo.RegisterEventHandler("QuestStateChanged", 			"OnQuestStateChanged", self)
	Apollo.RegisterEventHandler("UnitActivationTypeChanged", 	"OnUnitActivationTypeChanged", self)
	Apollo.RegisterEventHandler("QuestObjectiveUpdated", 		"OnQuestObjectiveUpdated", self)
	Apollo.RegisterEventHandler("PublicEventStart", 			"OnPublicEventStart", self)
	Apollo.RegisterEventHandler("PublicEventObjectiveUpdate", 	"OnPublicEventObjectiveUpdate", self)
	Apollo.RegisterEventHandler("PublicEventEnd", 				"OnPublicEventEnd", self)
	Apollo.RegisterEventHandler("ChallengeAbandon",				"OnChallengeUpdate", self)
	Apollo.RegisterEventHandler("ChallengeLeftArea", 			"OnChallengeUpdate", self)
	Apollo.RegisterEventHandler("ChallengeFailTime", 			"OnChallengeUpdate", self)
	Apollo.RegisterEventHandler("ChallengeFailArea", 			"OnChallengeUpdate", self)
	Apollo.RegisterEventHandler("ChallengeActivate",			"OnChallengeUpdate", self)
	Apollo.RegisterEventHandler("ChallengeCompleted", 			"OnChallengeUpdate", self)
	Apollo.RegisterEventHandler("ChallengeFailGeneric", 		"OnChallengeUpdate", self)
	Apollo.RegisterEventHandler("PlayerPathMissionUnlocked", 	"OnPlayerPathMissionChange", self)
	Apollo.RegisterEventHandler("PlayerPathMissionUpdate", 		"OnPlayerPathMissionChange", self)
	Apollo.RegisterEventHandler("PlayerPathMissionComplete", 	"OnPlayerPathMissionChange", self)
	Apollo.RegisterEventHandler("PlayerPathMissionDeactivate", 	"OnPlayerPathMissionChange", self)
	Apollo.RegisterEventHandler("PlayerPathMissionActivate", 	"OnPlayerPathMissionChange", self)
	
	--Apollo.RegisterEventHandler("TargetThreatListUpdated",		"OnTargetThreatListUpdated", self)
	--Apollo.RegisterEventHandler("DamageOrHealingDone", 			"OnDamageOrHealingDone", self)
	
	Apollo.RegisterTimerHandler("InitialParseTimer", "OptionsChanged", self)
	Apollo.CreateTimer("InitialParseTimer", 1.0, false); Apollo.StopTimer("InitialParseTimer");
	
	-- timer to update buffs at a lesser interval
    Apollo.RegisterTimerHandler("BuffUpdater", "UpdateBuffs", self)
	Apollo.CreateTimer("BuffUpdater", buffUpdateInterval, true) 
	
	-- Load custom sprite sheet
	Apollo.LoadSprites("BijiPlates_Sprites.xml")
	
    -- load our forms
	self.xmlDoc = XmlDoc.CreateFromFile("BijiPlates.xml")
	
	self.wndMain = Apollo.LoadForm(self.xmlDoc, "SettingsForm", nil, self)
	self.wndSettingsList = Apollo.LoadForm(self.xmlDoc, "SettingsList", self.wndMain:FindChild("Window_MainSettings"), self)
	self.wndSettingsColors = Apollo.LoadForm(self.xmlDoc, "SettingsColors", self.wndMain:FindChild("Window_MainSettings"), self)
	self.wndSettingsStyle = Apollo.LoadForm(self.xmlDoc, "SettingsStyle", self.wndMain:FindChild("Window_MainSettings"), self)
	self.wndMain:Show(false)
	self.wndSettingsColors:Show(false)
	self.wndSettingsStyle:Show(false)
	self.wndSettingsStyle:FindChild("PreviewHealth_SAO"):SetSprite("SAO_Health")
	self.wndSettingsStyle:FindChild("PreviewShield_SAO"):SetSprite("SAO_Shield")
	self.wndSettingsStyle:FindChild("PreviewHealth_Flat"):SetSprite("Flat_Health")
	self.wndSettingsStyle:FindChild("PreviewShield_Flat"):SetSprite("Flat_Shield")
	
	self.unitPlayerDisposComparisonTEMP 	= nil
	self.bInitialLoadAllClear 				= false -- delays drawing until everything's come in
	self.arDisplayedNameplates 				= {}
	self.arUnit2Nameplate 					= {}
	self.arFreeWindows 						= {}
	
	self.bPlayerInCombat = false -- Abandon in favor of checking individual units.
	
	self.nMaxRange = 50
	self.bBlinded = false
	
	--Apollo.CreateTimer("SecondaryParseTimer", 60.0, true) -- failsafe load; updates if things weren't. runs every minute to keep things clean
	
	local wndTemp = Apollo.LoadForm(self.xmlDoc, "TestPlate", nil, self)
	wndTemp:Destroy()
	
	self:DefaultSettings()
	self:DefaultColors()
	self:RefreshSettings()

	if GameLib.GetPlayerUnit() then self:OptionsChanged()end
	
	-- Is TrackMaster installed?
	trackMaster = Apollo.GetAddon("TrackMaster");
end

function BijiPlates:UpdateBuffs()
	updateBuffs = true;
end

-- Save User Settings
function BijiPlates:OnSave(eType)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Character then return end

	local tSave = {}
	for idx,property in ipairs(myUserSettings) do tSave[property] = self[property] end
	
	return tSave
end


-- Restore Saved User Settings
function BijiPlates:OnRestore(eType, t)
	if eType ~= GameLib.CodeEnumAddonSaveLevel.Character then return end
	
	for idx,property in ipairs(myUserSettings) do
		if t[property] ~= nil then self[property] = t[property] end
	end
end


-- Open Settings Window
function BijiPlates:OnBijiPlatesOn()
	self.wndMain:Show(true)
	self:RefreshSettings()
end


-- Set Default Settings Options
function BijiPlates:DefaultSettings()
	self.setNeverShow = false;
	self.setEnableOcclusion = false;
	self.setWotWThrottle = false;
	self.setCombatSelf = true;
	
	self.setDrawDistance = 70;
	self.setPlateScale = 100;
	self.setHealthCutoff = 30;
	self.setBuffCutoff = 60
	
	self.setShowIcons = true;
	self.setShowTitles = true;
	self.setShowNumbers = false; -- deprecated
	
	self.setShowHealth = false;
	self.setShowHealthPercent = false;
	self.setShowShield = false;
	self.setShowShieldPercent = false;
	self.setShowLevel = false;
	self.setShowArmor = true;
	
	self.setIconQuest = true;
	self.setIconMission = true;
	self.setIconFriend = true;
	self.setIconEvent = true;
	self.setIconChallenge = true;
	self.setIconRival = true;
	
	
	self.setShowThreatAlert = false;
	
	self.setShowCleanseAlert = false;
	self.setHideFullFriendlyBars = false;
	
	-- Targeted Settings
	self.setT_M = true;
	self.setT_N = true;
	self.setT_G = false;
	self.setT_B = true;
	self.setT_C = true;
	self.setT_D = false;
	
	-- My Nameplate Settings
	self.setM_N = false; self.setM_N_C = false;
	self.setM_G = false; self.setM_G_C = false;
	self.setM_B = false; self.setM_B_C = true;
	self.setM_C = false; self.setM_C_C = false;
	self.setM_D = false; self.setM_D_C = false;
	self.setM_R = false; self.setM_R_C = false;
	
	-- Neutral Nameplate Settings
	self.setN_N = true; self.setN_N_C = true; 
	self.setN_G = true; self.setN_G_C = true; 
	self.setN_B = false; self.setN_B_C = true; 
	self.setN_C = false; self.setN_C_C = true; 
	self.setN_D = false; self.setN_D_C = false; 
	
	-- Friendly Nameplate Settings
	self.setF_N = true; self.setF_N_C = true; 
	self.setF_G = true; self.setF_G_C = true; 
	self.setF_B = false; self.setF_B_C = true; 
	self.setF_C = false; self.setF_C_C = false; 
	self.setF_D = false; self.setF_D_C = false; 
	self.setF_Important = true;
		-- Friendly PLAYER Nameplate Settings
		self.setFP_N = true; self.setFP_N_C = true;  
		self.setFP_G = true; self.setFP_G_C = true; 
		self.setFP_B = true; self.setFP_B_C = true; 
		self.setFP_C = false; self.setFP_C_C = true; 
		self.setFP_D = false; self.setFP_D_C = false; 
		self.setFP_CN = false; self.setFP_CN_C = false; 
		
		-- Party PLAYER Nameplate Settings
		self.setPP_N = true; self.setPP_N_C = true;  
		self.setPP_G = true; self.setPP_G_C = true; 
		self.setPP_B = true; self.setPP_B_C = true; 
		self.setPP_C = false; self.setPP_C_C = true; 
		self.setPP_D = false; self.setPP_D_C = false; 
		self.setPP_CN = false; self.setPP_CN_C = false; 
		
	-- Hostile Nameplate Settings
	self.setH_N = true; self.setH_N_C = true;
	self.setH_G = true; self.setH_G_C = true;
	self.setH_B = false; self.setH_B_C = true;
	self.setH_C = false; self.setH_C_C = true;
	self.setH_D = false; self.setH_D_C = false;
		-- Hostile PLAYER Nameplate Settings
		self.setHP_N = true; self.setHP_N_C = true;
		self.setHP_G = true; self.setHP_G_C = true;
		self.setHP_B = true; self.setHP_B_C = true;
		self.setHP_C = true; self.setHP_C_C = true;
		self.setHP_D = false; self.setHP_D_C = false;
		self.setHP_CN = false; self.setHP_CN_C = false;
		
	-- Pet Settings
	self.setShowMyPets = true;
	self.setShowFriendlyPets = false;
	self.setShowHostilePets = true;
		
	
	-- Colors Page
	------------------------------
	self.setShowClassColors = false;
	
	-- Style Page
	------------------------------
	self.setStyle = "sao"
	
	self.setSAOSize = 100;
	
	self.setFlatHealthTexture = 1;
	self.setFlatShieldTexture = 1;
	self.setFlatWidth = 80;
	self.setFlatHealthHeight = 11;
	self.setFlatShieldHeight = 5;
	
	self.setUnitNameFont = "CRB_Interface11"
	self.setUnitNameFontType = "_O"
	
	self.setUnitGuildFont = "CRB_Interface10"
	self.setUnitGuildFontType = "_O"
end


-- Set Default Colors
function BijiPlates:DefaultColors()

	self.setOpacity = "FF"

	self.setColorBackgroundBar = "8e8f8d"
	self.setColorBackdropBar = "585959"

	self.setColorShieldBar = "75e4ec"
	self.setColorAbsorbBar = "ff9b00"
	self.setColorVulnerableBar = "e50000"
	self.setColorVulnerableTimerBar = "e583c3"
	self.setColorCastBar = "feb308"

	self.setColorNeutralName = "fff569"
	self.setColorNeutralBar = "f3d829"
	self.setColorNeutralBarCutoff = "c0fb2d"

	self.setColorFriendlyName = "76cd26"
	self.setColorFriendlyBar = "15b01a"
	self.setColorFriendlyBarCutoff = "ff9408"
	
	self.setColorFriendlyPlayerName = "00add6"
	self.setColorFriendlyPlayerNameUnflagged = "00add6"
	self.setColorFriendlyPlayerBar = "15b01a"
	self.setColorFriendlyPlayerBarCutoff = "f97306"
	
	self.setColorPartyName = "069af3"
	self.setColorGuildName = "dbb40c"

	self.setColorHostileName = "d9544d"
	self.setColorHostileBar = "e50000"
	self.setColorHostileBarCutoff = "fe02a2"
	
	self.setColorHostilePlayerName = "e50000"
	self.setColorHostilePlayerNameUnflagged = "fff569"
	self.setColorHostilePlayerBar = "e50000"
	self.setColorHostilePlayerBarCutoff = "fe02a2"
	
	--Class colors
	self.setColorWarriorBar = "9a0200"
	self.setColorStalkerBar = "703be7"
	self.setColorEngineerBar = "a83c09"
	self.setColorEsperBar = "c875c4"
	self.setColorSpellslingerBar = "cdc50a"
	self.setColorMedicBar = "01386a"
end

-- Set Default values and config windows
function BijiPlates:RefreshSettings()

	-- GENERAL SETTINGS
	if self.setNeverShow ~= nil then 
		self.wndMain:FindChild("Button_NeverShow"):SetCheck(self.setNeverShow) end
	if self.setEnableOcclusion ~= nil then 
		self.wndMain:FindChild("Button_EnableOcclusion"):SetCheck(self.setEnableOcclusion) end
	if self.setWotWThrottle ~= nil then
		self.wndMain:FindChild("Button_WotWThrottle"):SetCheck(self.setWotWThrottle) end
	if self.setDrawDistance ~= nil then 
		self.wndMain:FindChild("Label_DrawDistanceDisplay"):SetText(string.format("%sm",  math.floor(self.setDrawDistance))) 
		self.wndMain:FindChild("Slider_DrawDistance"):SetValue(self.setDrawDistance) end --SET SCROLL BAR
	if self.setBuffCutoff ~= nil then 
		self.wndMain:FindChild("EditBox_BuffCutoff"):SetText(self.setBuffCutoff) end
	if self.setShowTitles ~= nil then 
		self.wndMain:FindChild("Button_ShowTitles"):SetCheck(self.setShowTitles) end
	if self.setShowIcons ~= nil then 
		self.wndMain:FindChild("Button_ShowIcons"):SetCheck(self.setShowIcons) end

	if self.setHealthCutoff ~= nil then 
		self.wndMain:FindChild("Label_HealthCutoffDisplay"):SetText(string.format("%s%%",  math.floor(self.setHealthCutoff))) 
		self.wndMain:FindChild("Slider_HealthCutoff"):SetValue(self.setHealthCutoff) end --SET SCROLL BAR
	if self.setCombatSelf ~= nil then 
		self.wndMain:FindChild("Button_CombatSelf"):SetCheck(self.setCombatSelf) end
		
	if self.setShowHealth ~= nil then 
		self.wndMain:FindChild("Button_ShowHealthNumber"):SetCheck(self.setShowHealth) end
	if self.setShowHealthPercent ~= nil then
		self.wndMain:FindChild("Button_ShowHealthPercent"):SetCheck(self.setShowHealthPercent) end
	if self.setShowShield ~= nil then 
		self.wndMain:FindChild("Button_ShowShieldNumber"):SetCheck(self.setShowShield) end
	if self.setShowShieldPercent ~= nil then
		self.wndMain:FindChild("Button_ShowShieldPercent"):SetCheck(self.setShowShieldPercent) end
	if self.setShowLevel ~= nil then 
		self.wndMain:FindChild("Button_ShowLevelNumber"):SetCheck(self.setShowLevel) end
	if self.setShowArmor ~= nil then 
		self.wndMain:FindChild("Button_ShowArmorCount"):SetCheck(self.setShowArmor) end
		
	if self.setIconQuest ~= nil then
		self.wndMain:FindChild("Button_IconQuest"):SetCheck(self.setIconQuest) end
	if self.setIconMission ~= nil then
		self.wndMain:FindChild("Button_IconMission"):SetCheck(self.setIconMission) end
	if self.setIconFriend ~= nil then
		self.wndMain:FindChild("Button_IconFriend"):SetCheck(self.setIconFriend) end
	if self.setIconEvent ~= nil then
		self.wndMain:FindChild("Button_IconEvent"):SetCheck(self.setIconEvent) end
	if self.setIconChallenge ~= nil then
		self.wndMain:FindChild("Button_IconChallenge"):SetCheck(self.setIconChallenge) end
	if self.setIconRival ~= nil then
		self.wndMain:FindChild("Button_IconRival"):SetCheck(self.setIconRival) end
	
	if self.setShowThreatAlert ~= nil then 
		self.wndMain:FindChild("Button_ShowThreatAlert"):SetCheck(self.setShowThreatAlert) end
	if self.setShowCleanseAlert ~= nil then 
		self.wndMain:FindChild("Button_ShowCleanseAlert"):SetCheck(self.setShowCleanseAlert) end
	if self.setHideFullFriendlyBars ~= nil then 
		self.wndMain:FindChild("Button_HideFullFriendlyBars"):SetCheck(self.setHideFullFriendlyBars) end
		
	if self.setPlateScale ~= nil then 
		self.wndMain:FindChild("Label_PlateScaleDisplay"):SetText(math.floor(self.setPlateScale ) / 100) 
		self.wndMain:FindChild("Slider_PlateScale"):SetValue(self.setPlateScale ) end --SET SCROLL BAR
	
	-- Pet Settings
	if self.setShowMyPets ~= nil then 
		self.wndMain:FindChild("Button_setShowMyPets"):SetCheck(self.setShowMyPets) end
	if self.setShowFriendlyPets ~= nil then 
		self.wndMain:FindChild("Button_setShowFriendlyPets"):SetCheck(self.setShowFriendlyPets) end
	if self.setShowHostilePets ~= nil then 
		self.wndMain:FindChild("Button_setShowHostilePets"):SetCheck(self.setShowHostilePets) end
		
		
	if self.setShowClassColors ~= nil then -- On Colors Page.
		self.wndMain:FindChild("Button_ShowClassColors"):SetCheck(self.setShowClassColors ) end
		
	-- Targeted Settings
	if self.setT_M ~= nil then self.wndMain:FindChild("Button_setT_M"):SetCheck(self.setT_M) end
	if self.setT_N ~= nil then self.wndMain:FindChild("Button_setT_N"):SetCheck(self.setT_N) end
	if self.setT_G ~= nil then self.wndMain:FindChild("Button_setT_G"):SetCheck(self.setT_G) end
	if self.setT_B ~= nil then self.wndMain:FindChild("Button_setT_B"):SetCheck(self.setT_B) end
	if self.setT_C ~= nil then self.wndMain:FindChild("Button_setT_C"):SetCheck(self.setT_C) end
	if self.setT_D ~= nil then self.wndMain:FindChild("Button_setT_D"):SetCheck(self.setT_D) end
	
	-- My Nameplate Settings
	if self.setM_N ~= nil 	then self.wndMain:FindChild("Button_setM_N"):SetCheck(self.setM_N)		end
	if self.setM_N_C ~= nil	then self.wndMain:FindChild("Button_setM_N_C"):SetCheck(self.setM_N_C)	end
	if self.setM_G ~= nil 	then self.wndMain:FindChild("Button_setM_G"):SetCheck(self.setM_G)		end
	if self.setM_G_C ~= nil	then self.wndMain:FindChild("Button_setM_G_C"):SetCheck(self.setM_G_C)	end
	if self.setM_B ~= nil	then self.wndMain:FindChild("Button_setM_B"):SetCheck(self.setM_B)		end
	if self.setM_B_C ~= nil	then self.wndMain:FindChild("Button_setM_B_C"):SetCheck(self.setM_B_C)	end
	if self.setM_C ~= nil	then self.wndMain:FindChild("Button_setM_C"):SetCheck(self.setM_C)		end
	if self.setM_C_C ~= nil	then self.wndMain:FindChild("Button_setM_C_C"):SetCheck(self.setM_C_C)	end
	if self.setM_D ~= nil	then self.wndMain:FindChild("Button_setM_D"):SetCheck(self.setM_D)		end
	if self.setM_D_C ~= nil	then self.wndMain:FindChild("Button_setM_D_C"):SetCheck(self.setM_D_C)	end
	if self.setM_R ~= nil	then self.wndMain:FindChild("Button_setM_R"):SetCheck(self.setM_R)		end
	if self.setM_R_C ~= nil	then self.wndMain:FindChild("Button_setM_R_C"):SetCheck(self.setM_R_C)	end
	
	-- Neutral Nameplate Settings
	if self.setN_N ~= nil 	then self.wndMain:FindChild("Button_setN_N"):SetCheck(self.setN_N)		end
	if self.setN_N_C ~= nil	then self.wndMain:FindChild("Button_setN_N_C"):SetCheck(self.setN_N_C)	end
	if self.setN_G ~= nil 	then self.wndMain:FindChild("Button_setN_G"):SetCheck(self.setN_G)		end
	if self.setN_G_C ~= nil	then self.wndMain:FindChild("Button_setN_G_C"):SetCheck(self.setN_G_C)	end
	if self.setN_B ~= nil 	then self.wndMain:FindChild("Button_setN_B"):SetCheck(self.setN_B)		end
	if self.setN_B_C ~= nil	then self.wndMain:FindChild("Button_setN_B_C"):SetCheck(self.setN_B_C)	end
	if self.setN_C ~= nil 	then self.wndMain:FindChild("Button_setN_C"):SetCheck(self.setN_C)		end
	if self.setN_C_C ~= nil	then self.wndMain:FindChild("Button_setN_C_C"):SetCheck(self.setN_C_C)	end
	if self.setN_D ~= nil 	then self.wndMain:FindChild("Button_setN_D"):SetCheck(self.setN_D)		end
	if self.setN_D_C ~= nil	then self.wndMain:FindChild("Button_setN_D_C"):SetCheck(self.setN_D_C)	end
	
	-- Friendly Nameplate Settings
	if self.setF_N ~= nil 	then self.wndMain:FindChild("Button_setF_N"):SetCheck(self.setF_N)		end
	if self.setF_N_C ~= nil	then self.wndMain:FindChild("Button_setF_N_C"):SetCheck(self.setF_N_C)	end
	if self.setF_G ~= nil 	then self.wndMain:FindChild("Button_setF_G"):SetCheck(self.setF_G)		end
	if self.setF_G_C ~= nil	then self.wndMain:FindChild("Button_setF_G_C"):SetCheck(self.setF_G_C)	end
	if self.setF_B ~= nil 	then self.wndMain:FindChild("Button_setF_B"):SetCheck(self.setF_B)		end
	if self.setF_B_C ~= nil	then self.wndMain:FindChild("Button_setF_B_C"):SetCheck(self.setF_B_C)	end
	if self.setF_C ~= nil 	then self.wndMain:FindChild("Button_setF_C"):SetCheck(self.setF_C)		end
	if self.setF_C_C ~= nil	then self.wndMain:FindChild("Button_setF_C_C"):SetCheck(self.setF_C_C)	end
	if self.setF_D ~= nil 	then self.wndMain:FindChild("Button_setF_D"):SetCheck(self.setF_D)		end
	if self.setF_D_C ~= nil	then self.wndMain:FindChild("Button_setF_D_C"):SetCheck(self.setF_D_C)	end
	if self.setF_Important ~= nil then self.wndMain:FindChild("Button_setF_Important"):SetCheck(self.setF_Important)	end
		-- Friendly PLAYER Nameplate Settings
		if self.setFP_N ~= nil	 then self.wndMain:FindChild("Button_setFP_N"):SetCheck(self.setFP_N)	  end
		if self.setFP_N_C ~= nil then self.wndMain:FindChild("Button_setFP_N_C"):SetCheck(self.setFP_N_C) end
		if self.setFP_G ~= nil	 then self.wndMain:FindChild("Button_setFP_G"):SetCheck(self.setFP_G)	  end
		if self.setFP_G_C ~= nil then self.wndMain:FindChild("Button_setFP_G_C"):SetCheck(self.setFP_G_C) end
		if self.setFP_B ~= nil	 then self.wndMain:FindChild("Button_setFP_B"):SetCheck(self.setFP_B)	  end
		if self.setFP_B_C ~= nil then self.wndMain:FindChild("Button_setFP_B_C"):SetCheck(self.setFP_B_C) end
		if self.setFP_C ~= nil	 then self.wndMain:FindChild("Button_setFP_C"):SetCheck(self.setFP_C)	  end
		if self.setFP_C_C ~= nil then self.wndMain:FindChild("Button_setFP_C_C"):SetCheck(self.setFP_C_C) end
		if self.setFP_D ~= nil	 then self.wndMain:FindChild("Button_setFP_D"):SetCheck(self.setFP_D)	  end
		if self.setFP_D_C ~= nil then self.wndMain:FindChild("Button_setFP_D_C"):SetCheck(self.setFP_D_C) end
		if self.setFP_CN ~= nil	 then self.wndMain:FindChild("Button_setFP_CN"):SetCheck(self.setFP_CN)	  end
		if self.setFP_CN_C ~= nil then self.wndMain:FindChild("Button_setFP_CN_C"):SetCheck(self.setFP_CN_C) end
	
		-- PARTY PLAYER Nameplate Settings
		if self.setPP_N ~= nil	 then self.wndMain:FindChild("Button_setPP_N"):SetCheck(self.setPP_N)	  end
		if self.setPP_N_C ~= nil then self.wndMain:FindChild("Button_setPP_N_C"):SetCheck(self.setPP_N_C) end
		if self.setPP_G ~= nil	 then self.wndMain:FindChild("Button_setPP_G"):SetCheck(self.setPP_G)	  end
		if self.setPP_G_C ~= nil then self.wndMain:FindChild("Button_setPP_G_C"):SetCheck(self.setPP_G_C) end
		if self.setPP_B ~= nil	 then self.wndMain:FindChild("Button_setPP_B"):SetCheck(self.setPP_B)	  end
		if self.setPP_B_C ~= nil then self.wndMain:FindChild("Button_setPP_B_C"):SetCheck(self.setPP_B_C) end
		if self.setPP_C ~= nil	 then self.wndMain:FindChild("Button_setPP_C"):SetCheck(self.setPP_C)	  end
		if self.setPP_C_C ~= nil then self.wndMain:FindChild("Button_setPP_C_C"):SetCheck(self.setPP_C_C) end
		if self.setPP_D ~= nil	 then self.wndMain:FindChild("Button_setPP_D"):SetCheck(self.setPP_D)	  end
		if self.setPP_D_C ~= nil then self.wndMain:FindChild("Button_setPP_D_C"):SetCheck(self.setPP_D_C) end
		if self.setPP_CN ~= nil	 then self.wndMain:FindChild("Button_setPP_CN"):SetCheck(self.setPP_CN)	  end
		if self.setPP_CN_C ~= nil then self.wndMain:FindChild("Button_setPP_CN_C"):SetCheck(self.setPP_CN_C) end
		
	-- Hostile Nameplate Settings
	if self.setH_N ~= nil 	then self.wndMain:FindChild("Button_setH_N"):SetCheck(self.setH_N)		end
	if self.setH_N_C ~= nil	then self.wndMain:FindChild("Button_setH_N_C"):SetCheck(self.setH_N_C)	end
	if self.setH_G ~= nil 	then self.wndMain:FindChild("Button_setH_G"):SetCheck(self.setH_G)		end
	if self.setH_G_C ~= nil	then self.wndMain:FindChild("Button_setH_G_C"):SetCheck(self.setH_G_C)	end
	if self.setH_B ~= nil 	then self.wndMain:FindChild("Button_setH_B"):SetCheck(self.setH_B)		end
	if self.setH_B_C ~= nil	then self.wndMain:FindChild("Button_setH_B_C"):SetCheck(self.setH_B_C)	end
	if self.setH_C ~= nil 	then self.wndMain:FindChild("Button_setH_C"):SetCheck(self.setH_C)		end
	if self.setH_C_C ~= nil	then self.wndMain:FindChild("Button_setH_C_C"):SetCheck(self.setH_C_C)	end
	if self.setH_D ~= nil 	then self.wndMain:FindChild("Button_setH_D"):SetCheck(self.setH_D)		end
	if self.setH_D_C ~= nil	then self.wndMain:FindChild("Button_setH_D_C"):SetCheck(self.setH_D_C)	end
		-- Hostile PLAYER Nameplate Settings
		if self.setHP_N ~= nil	 then self.wndMain:FindChild("Button_setHP_N"):SetCheck(self.setHP_N)	  end
		if self.setHP_N_C ~= nil then self.wndMain:FindChild("Button_setHP_N_C"):SetCheck(self.setHP_N_C) end
		if self.setHP_G ~= nil	 then self.wndMain:FindChild("Button_setHP_G"):SetCheck(self.setHP_G)	  end
		if self.setHP_G_C ~= nil then self.wndMain:FindChild("Button_setHP_G_C"):SetCheck(self.setHP_G_C) end
		if self.setHP_B ~= nil	 then self.wndMain:FindChild("Button_setHP_B"):SetCheck(self.setHP_B)	  end
		if self.setHP_B_C ~= nil then self.wndMain:FindChild("Button_setHP_B_C"):SetCheck(self.setHP_B_C) end
		if self.setHP_C ~= nil	 then self.wndMain:FindChild("Button_setHP_C"):SetCheck(self.setHP_C)	  end
		if self.setHP_C_C ~= nil then self.wndMain:FindChild("Button_setHP_C_C"):SetCheck(self.setHP_C_C) end 
		if self.setHP_D ~= nil	 then self.wndMain:FindChild("Button_setHP_D"):SetCheck(self.setHP_D)	  end
		if self.setHP_D_C ~= nil then self.wndMain:FindChild("Button_setHP_D_C"):SetCheck(self.setHP_D_C) end 
		if self.setHP_CN ~= nil	 then self.wndMain:FindChild("Button_setHP_CN"):SetCheck(self.setHP_CN)	  end
		if self.setHP_CN_C ~= nil then self.wndMain:FindChild("Button_setHP_CN_C"):SetCheck(self.setHP_CN_C) end 
	
	-- Color Settings
	--if self.setOpacity ~= nil then SET BAR end -- TODO: make options for this.
	if self.setColorBackgroundBar ~= nil then 
		self.wndMain:FindChild("Edit_BackgroundBar"):SetText(self.setColorBackgroundBar)
		self.wndMain:FindChild("Label_BackgroundBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorBackgroundBar)) end
	if self.setColorBackdropBar ~= nil then 
		self.wndMain:FindChild("Edit_BackdropBar"):SetText(self.setColorBackdropBar )
		self.wndMain:FindChild("Label_BackdropBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorBackdropBar)) end
	if self.setColorShieldBar ~= nil then 
		self.wndMain:FindChild("Edit_ShieldBar"):SetText(self.setColorShieldBar)
		self.wndMain:FindChild("Label_ShieldBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorShieldBar)) end
	if self.setColorAbsorbBar ~= nil then 
		self.wndMain:FindChild("Edit_AbsorbBar"):SetText(self.setColorAbsorbBar)
		self.wndMain:FindChild("Label_AbsorbBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorAbsorbBar)) end
	if self.setColorVulnerableBar ~= nil then 
		self.wndMain:FindChild("Edit_VulnerableBar"):SetText(self.setColorVulnerableBar )
		self.wndMain:FindChild("Label_VulnerableBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorVulnerableBar)) end
	if self.setColorVulnerableTimerBar ~= nil then 
		self.wndMain:FindChild("Edit_VulnerableTimerBar"):SetText(self.setColorVulnerableTimerBar )
		self.wndMain:FindChild("Label_VulnerableTimerBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorVulnerableTimerBar)) end
	if self.setColorCastBar ~= nil then
		self.wndMain:FindChild("Edit_CastBar"):SetText(self.setColorCastBar )
		self.wndMain:FindChild("Label_CastBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorCastBar)) end
	
	if self.setColorNeutralName ~= nil then 
		self.wndMain:FindChild("Edit_NeutralName"):SetText(self.setColorNeutralName )
		self.wndMain:FindChild("Label_NeutralName"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorNeutralName)) end
	if self.setColorNeutralBar ~= nil then 
		self.wndMain:FindChild("Edit_NeutralBar"):SetText(self.setColorNeutralBar )
		self.wndMain:FindChild("Label_NeutralBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorNeutralBar )) end
	if self.setColorNeutralBarCutoff ~= nil then 
		self.wndMain:FindChild("Edit_NeutralBarCutoff"):SetText(self.setColorNeutralBarCutoff )
		self.wndMain:FindChild("Label_NeutralBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorNeutralBarCutoff )) end
	
	if self.setColorFriendlyName ~= nil then 
		self.wndMain:FindChild("Edit_FriendlyName"):SetText(self.setColorFriendlyName )
		self.wndMain:FindChild("Label_FriendlyName"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorFriendlyName )) end
	if self.setColorFriendlyBar ~= nil then 
		self.wndMain:FindChild("Edit_FriendlyBar"):SetText(self.setColorFriendlyBar )
		self.wndMain:FindChild("Label_FriendlyBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorFriendlyBar )) end
	if self.setColorFriendlyBarCutoff ~= nil then 
		self.wndMain:FindChild("Edit_FriendlyBarCutoff"):SetText(self.setColorFriendlyBarCutoff )
		self.wndMain:FindChild("Label_FriendlyBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorFriendlyBarCutoff )) end
	
	if self.setColorFriendlyPlayerName ~= nil then 
		self.wndMain:FindChild("Edit_FriendlyPlayerName"):SetText(self.setColorFriendlyPlayerName )
		self.wndMain:FindChild("Label_FriendlyPlayerName"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorFriendlyPlayerName )) end
	if self.setColorFriendlyPlayerNameUnflagged ~= nil then 
		self.wndMain:FindChild("Edit_FriendlyPlayerNameUnflagged"):SetText(self.setColorFriendlyPlayerNameUnflagged )
		self.wndMain:FindChild("Label_FriendlyPlayerNameUnflagged"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorFriendlyPlayerNameUnflagged )) end
	if self.setColorFriendlyPlayerBar ~= nil then 
		self.wndMain:FindChild("Edit_FriendlyPlayerBar"):SetText(self.setColorFriendlyPlayerBar )
		self.wndMain:FindChild("Label_FriendlyPlayerBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorFriendlyPlayerBar )) end
	if self.setColorFriendlyPlayerBarCutoff ~= nil then 
		self.wndMain:FindChild("Edit_FriendlyPlayerBarCutoff"):SetText(self.setColorFriendlyPlayerBarCutoff )
		self.wndMain:FindChild("Label_FriendlyPlayerBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorFriendlyPlayerBarCutoff )) end
	
	if self.setColorHostileName ~= nil then 
		self.wndMain:FindChild("Edit_HostileName"):SetText(self.setColorHostileName )
		self.wndMain:FindChild("Label_HostileName"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorHostileName )) end
	if self.setColorHostileBar ~= nil then 
		self.wndMain:FindChild("Edit_HostileBar"):SetText(self.setColorHostileBar )
		self.wndMain:FindChild("Label_HostileBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorHostileBar )) end
	if self.setColorHostileBarCutoff ~= nil then 
		self.wndMain:FindChild("Edit_HostileBarCutoff"):SetText(self.setColorHostileBarCutoff )
		self.wndMain:FindChild("Label_HostileBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorHostileBarCutoff )) end
	
	if self.setColorHostilePlayerName ~= nil then 
		self.wndMain:FindChild("Edit_HostilePlayerName"):SetText(self.setColorHostilePlayerName )
		self.wndMain:FindChild("Label_HostilePlayerName"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorHostilePlayerName )) end
	if self.setColorHostilePlayerNameUnflagged ~= nil then 
		self.wndMain:FindChild("Edit_HostilePlayerNameUnflagged"):SetText(self.setColorHostilePlayerNameUnflagged )
		self.wndMain:FindChild("Label_HostilePlayerNameUnflagged"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorHostilePlayerNameUnflagged )) end
	if self.setColorHostilePlayerBar ~= nil then 
		self.wndMain:FindChild("Edit_HostilePlayerBar"):SetText(self.setColorHostilePlayerBar )
		self.wndMain:FindChild("Label_HostilePlayerBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorHostilePlayerBar )) end
	if self.setColorHostilePlayerBarCutoff ~= nil then 
		self.wndMain:FindChild("Edit_HostilePlayerBarCutoff"):SetText(self.setColorHostilePlayerBarCutoff )
		self.wndMain:FindChild("Label_HostilePlayerBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorHostilePlayerBarCutoff )) end

	if self.setColorPartyName ~= nil then 
		self.wndMain:FindChild("Edit_PartyName"):SetText(self.setColorPartyName)
		self.wndMain:FindChild("Label_PartyName"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorPartyName)) end
		
	--if self.setColorGuildName ~= nil then self.setColorGuildName = "dbb40c" end -- xkcdGold
		--self.wndMain:FindChild("Edit_GuildName"):SetText(self.setColorGuildName )
		--self.wndMain:FindChild("Label_GuildName"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorGuildName ))
		
	if self.setColorWarriorBar ~= nil then 
		self.wndMain:FindChild("Edit_WarriorBar"):SetText(self.setColorWarriorBar)
		self.wndMain:FindChild("Label_WarriorBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorWarriorBar)) end
	if self.setColorStalkerBar ~= nil then 
		self.wndMain:FindChild("Edit_StalkerBar"):SetText(self.setColorStalkerBar)
		self.wndMain:FindChild("Label_StalkerBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorStalkerBar)) end
	if self.setColorEngineerBar ~= nil then 
		self.wndMain:FindChild("Edit_EngineerBar"):SetText(self.setColorEngineerBar)
		self.wndMain:FindChild("Label_EngineerBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorEngineerBar)) end
	if self.setColorEsperBar ~= nil then 
		self.wndMain:FindChild("Edit_EsperBar"):SetText(self.setColorEsperBar)
		self.wndMain:FindChild("Label_EsperBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorEsperBar)) end
	if self.setColorSpellslingerBar ~= nil then 
		self.wndMain:FindChild("Edit_SpellslingerBar"):SetText(self.setColorSpellslingerBar)
		self.wndMain:FindChild("Label_SpellslingerBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorSpellslingerBar)) end
	if self.setColorMedicBar ~= nil then 
		self.wndMain:FindChild("Edit_MedicBar"):SetText(self.setColorMedicBar)
		self.wndMain:FindChild("Label_MedicBar"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorMedicBar)) end
	
	-- STYLE SETTINGS
	if self.setStyle ~= nil then
		self.wndMain:FindChild("Button_StyleFlat"):SetCheck(self.setStyle == "flat")
		self.wndMain:FindChild("Button_StyleSAO"):SetCheck(self.setStyle == "sao")
	end	
	
		if self.setSAOSize ~= nil then 
			self.wndMain:FindChild("Label_SAOSizeDisplay"):SetText(string.format("%s",  math.floor(self.setSAOSize))) 
			self.wndMain:FindChild("Slider_SAOSize"):SetValue(self.setSAOSize) end --SET SCROLL BAR
			
		if self.setFlatWidth ~= nil then 
			self.wndMain:FindChild("Label_FlatWidthDisplay"):SetText(string.format("%s",  math.floor(self.setFlatWidth ))) 
			self.wndMain:FindChild("Slider_FlatWidth"):SetValue(self.setFlatWidth ) end --SET SCROLL BAR
			
		if self.setFlatShieldHeight ~= nil then 
			self.wndMain:FindChild("Label_FlatShieldHeightDisplay"):SetText(string.format("%s",  math.floor(self.setFlatShieldHeight ))) 
			self.wndMain:FindChild("Slider_FlatShieldHeight"):SetValue(self.setFlatShieldHeight ) end --SET SCROLL BAR
			
		if self.setFlatHealthHeight ~= nil then 
			self.wndMain:FindChild("Label_FlatHealthHeightDisplay"):SetText(string.format("%s",  math.floor(self.setFlatHealthHeight ))) 
			self.wndMain:FindChild("Slider_FlatHealthHeight"):SetValue(self.setFlatHealthHeight ) end --SET SCROLL BAR
			
		if self.setFlatShieldTexture ~= nil then 
			self.wndMain:FindChild("Label_FlatShieldTextureDisplay"):SetText(string.format("%s",  math.floor(self.setFlatShieldTexture ))) 
			self.wndMain:FindChild("Slider_FlatShieldTexture"):SetValue(self.setFlatShieldTexture ) end --SET SCROLL BAR
			
		if self.setFlatHealthTexture ~= nil then 
			self.wndMain:FindChild("Label_FlatHealthTextureDisplay"):SetText(string.format("%s",  math.floor(self.setFlatHealthTexture ))) 
			self.wndMain:FindChild("Slider_FlatHealthTexture"):SetValue(self.setFlatHealthTexture ) end --SET SCROLL BAR
	
	if self.setUnitNameFontType ~= nil then
		self.wndMain:FindChild("Button_setUnitNameTypeShadow"):SetCheck(self.setUnitNameFontType == "" )
		self.wndMain:FindChild("Button_setUnitNameTypeOutline"):SetCheck(self.setUnitNameFontType == "_O")
	end	
	
	if self.setUnitNameFont ~= nil then
		self.wndMain:FindChild("Button_setUnitNameFontChoad"):SetCheck(self.setUnitNameFont == "CRB_Pixel")
		self.wndMain:FindChild("Button_setUnitNameFontInterface9"):SetCheck(self.setUnitNameFont == "CRB_Interface9")
		self.wndMain:FindChild("Button_setUnitNameFontInterface10"):SetCheck(self.setUnitNameFont == "CRB_Interface10")
		self.wndMain:FindChild("Button_setUnitNameFontInterface11"):SetCheck(self.setUnitNameFont == "CRB_Interface11")
		self.wndMain:FindChild("Button_setUnitNameFontInterface12"):SetCheck(self.setUnitNameFont == "CRB_Interface12")
		self.wndMain:FindChild("Button_setUnitNameFontInterface14"):SetCheck(self.setUnitNameFont == "CRB_Interface14")
		self.wndMain:FindChild("Button_setUnitNameFontNameplates"):SetCheck(self.setUnitNameFont == "Nameplates")
	end
	
	if self.setUnitGuildFontType ~= nil then
		self.wndMain:FindChild("Button_setUnitGuildTypeShadow"):SetCheck(self.setUnitGuildFontType == "")
		self.wndMain:FindChild("Button_setUnitGuildTypeOutline"):SetCheck(self.setUnitGuildFontType == "_O")
	end	
	
	if self.setUnitGuildFont ~= nil then
		self.wndMain:FindChild("Button_setUnitGuildFontChoad"):SetCheck(self.setUnitGuildFont == "CRB_Pixel")
		self.wndMain:FindChild("Button_setUnitGuildFontInterface9"):SetCheck(self.setUnitGuildFont == "CRB_Interface9" )
		self.wndMain:FindChild("Button_setUnitGuildFontInterface10"):SetCheck(self.setUnitGuildFont == "CRB_Interface10")
		self.wndMain:FindChild("Button_setUnitGuildFontInterface11"):SetCheck(self.setUnitGuildFont == "CRB_Interface11")
		self.wndMain:FindChild("Button_setUnitGuildFontInterface12"):SetCheck(self.setUnitGuildFont == "CRB_Interface12")
		self.wndMain:FindChild("Button_setUnitGuildFontInterface14"):SetCheck(self.setUnitGuildFont == "CRB_Interface14")
		self.wndMain:FindChild("Button_setUnitGuildFontNameplates"):SetCheck(self.setUnitGuildFont == "Nameplates")
	end	

end

-----------------------------------------------------------------------------------------------
-- BijiPlates Functions: CREATE THE PLATES
-----------------------------------------------------------------------------------------------

-- New unit created, build main options here.
function BijiPlates:OnUnitCreated(unitNew) 
	if not unitNew then return end

	local idUnit = unitNew:GetId()
	-- don't create unit if we already know about it
	local tNameplate = self.arUnit2Nameplate[idUnit]
	if tNameplate ~= nil then return end

	tNameplate = self:CreateNameplateObject(unitNew)
	tNameplate.bBrandNew = true
	
	--if not self:HelperVerifyVisibilityOptions(tNameplate) then
		--self.arUnit2Nameplate[idUnit] = nil
	--end
end

function BijiPlates:OnUnitGibbed(unitUpdated)
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate ~= nil then
		tNameplate.bGibbed = true
	end
end


-- Create nameplate object from the unit.
function BijiPlates:CreateNameplateObject(unit)

	local tNameplate = {
		unitOwner 		= unit,
		idUnit 			= unit:GetId(),
		bOnScreen 		= false,
		bOccluded 		= false,
		bGibbed			= false,
		bSpeechBubble 	= false,
		bIsTarget 		= false,
		bIsCluster 		= false,
		bIsCasting 		= false,
		strGuildColor	= nil,
		nVulnerableTime = 0, 
		bShowBars		= false, -- Show Health Bars?
		bShowCastBar	= false, -- Show Cast Bar?
		bInCombat		= false, -- Is Unit In Combar?
		healthPlate 	= nil,   -- Link to active health plate (style)
		shieldPlate 	= nil    -- Link to active shield plate (style)
	}

	self.arUnit2Nameplate[tNameplate.idUnit] = tNameplate
	self:ParseRewards(tNameplate)

	return tNameplate
end


-- Create nameplae window from the nameplate object.
function BijiPlates:CreateNameplateWindow(tNameplate)
	if tNameplate.wndNameplate ~= nil then return end -- Nameplate alrady has a window? Bail out.
	if tNameplate.unitOwner == nil then return end -- Nameplate has no owner? Bail out.

	tNameplate.wndNameplate = table.remove(self.arFreeWindows)
	if tNameplate.wndNameplate == nil then
		tNameplate.wndNameplate = Apollo.LoadForm(self.xmlDoc, "TestPlate", "InWorldHudStratum", self)
	end

	tNameplate.wndNameplate:SetData(tNameplate.unitOwner)
	tNameplate.wndNameplate:FindChild("Name"):SetData(tNameplate.unitOwner)
	tNameplate.wndNameplate:SetUnit(tNameplate.unitOwner, 1)  -- 1 for overhead, 0 for underfoot
	
	tNameplate.bOnScreen = tNameplate.wndNameplate:IsOnScreen()
	tNameplate.bOccluded = tNameplate.wndNameplate:IsOccluded()
	tNameplate.wndNameplate:Show(false, true)

	self.arDisplayedNameplates[tNameplate.wndNameplate:GetId()] = tNameplate
	
	local myStyle = "sao"; -- default style
	
	tNameplate.healthPlate = tNameplate.wndNameplate:FindChild("HealthPlate_" .. myStyle)
	tNameplate.shieldPlate = tNameplate.wndNameplate:FindChild("ShieldPlate_" .. myStyle)
	
	
	-- Set Up SAO Sprites
	---------------------------------
	local tempHealth = tNameplate.wndNameplate:FindChild("HealthPlate_sao");
	local tempShield = tNameplate.wndNameplate:FindChild("ShieldPlate_sao");
	
	tempHealth:FindChild("HealthBar"):SetFullSprite("SAO_Health")
	tempHealth:FindChild("HealthBarBack"):SetEmptySprite("SAO_Health")
	tempHealth:FindChild("HealthBarBack"):SetFullSprite("SAO_Health")
	tempHealth:FindChild("NotTargeting"):SetSprite("SAO_Health_Border_Thick")
	
	tempShield:FindChild("ShieldBar"):SetEmptySprite("SAO_Shield")
	tempShield:FindChild("ShieldBar"):SetFullSprite("SAO_Shield")
	
	-- Set Up Flat Sprites
	---------------------------------
	tempHealth = tNameplate.wndNameplate:FindChild("HealthPlate_flat");
	tempShield = tNameplate.wndNameplate:FindChild("ShieldPlate_flat");
	
	tempHealth:FindChild("HealthBar"):SetFullSprite("Flat_Health")
	tempHealth:FindChild("HealthBarBack"):SetEmptySprite("Flat_Health")
	tempHealth:FindChild("HealthBarBack"):SetFullSprite("Flat_Health")
	tempHealth:FindChild("NotTargeting"):SetSprite("Flat_Border")
	
	tempShield:FindChild("ShieldBar"):SetEmptySprite("Flat_Shield")
	tempShield:FindChild("ShieldBar"):SetFullSprite("Flat_Shield")
	
	
	
	self:SetNormalNameplate(tNameplate)
	tNameplate.wndNameplate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)
		
	return tNameplate.wndNameplate
end

function BijiPlates:OnUnitNameChanged(unitUpdated, strNewName)
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then
		return
	end

	local nNameWidth = Apollo.GetTextWidth(self.setUnitNameFont, strName .. " ")
	
	if self.setUnitNameFont == "Nameplates" then
		namePlate:FindChild("Name"):SetFont(self.setUnitNameFont .. "")
	else
		namePlate:FindChild("Name"):SetFont(self.setUnitNameFont .. self.setUnitNameFontType)
	end
	namePlate:FindChild("Name"):SetAnchorOffsets(0, 0, nNameWidth, fontHeight[tostring(self.setUnitNameFont)])
	namePlate:FindChild("NameContainer"):SetAnchorOffsets(-200, 0, 200, fontHeight[tostring(self.setUnitNameFont)])
	namePlate:FindChild("NameContainer"):ArrangeChildrenHorz(1)
end


-- SET NAMEPLATE DATA: Set data that can be updated by events.
function BijiPlates:SetNormalNameplate(tNameplate)
	if tNameplate.wndNameplate == nil then return end
	local namePlate = tNameplate.wndNameplate

	local unitOwner = tNameplate.unitOwner
	local eDisposition = unitOwner:GetDispositionTo(self.unitPlayerDisposComparisonTEMP)
	
	local bHiddenUnit = not unitOwner:ShouldShowNamePlate() 
				or unitOwner:GetHealth() == nil 
				or unitOwner:GetType() == "Collectible"
				or unitOwner:GetType() == "PinataLoot" 
				or unitOwner:IsDead()
				
	if unitOwner:GetType() == "Pickup" then bHiddenUnit = false end
	
	namePlate:Show(bHiddenUnit)
	--self:Show(wndNameplate:FindChild("TestPlateContainer"), not bHiddenUnit) 
	
	--[[ Potentially causing redrawing of vulnerability bar
	tNameplate.nVulnerableTime = 0
	]]
	local tempInCombat = unitOwner:IsInCombat()
	
	--self.setStyle = "normal"
	
	-- STYLE CONFIG
	self:StyleConfig(tNameplate)
	local healthPlate = tNameplate.healthPlate
	local shieldPlate = tNameplate.shieldPlate 
	
	
	
	-- Set Unit Name	
	----------------------			
	local strName = unitOwner:GetName()
	if self.setShowTitles == true then strName = unitOwner:GetTitleOrName() end
	-- For Testing: Player, NonPlayer, Simple, Harvest, Mount, Collectible, Pickup, Pet
	--strName = strName .. " - " .. unitOwner:GetType()
	--strName = strName .. " - " .. tostring(unitOwner:IsThePlayer())
	--strName = strName .. " - " .. unitOwner:GetClassId()
	
	if unitOwner:GetType() == "Player" then
	
	
		if eDisposition == 0 and ((self.setHP_CN and not tempInCombat) or (self.setHP_CN_C and tempInCombat)) then -- HOSTILE
			strName = className[tostring(unitOwner:GetClassId())] .. strName
		elseif unitOwner:IsInYourGroup() and ((self.setPP_CN and not tempInCombat) or (self.setPP_CN_C and tempInCombat)) then -- PARTY
			strName = className[tostring(unitOwner:GetClassId())] .. strName
		elseif eDisposition == 2 and ((self.setFP_CN and not tempInCombat) or (self.setFP_CN_C and tempInCombat)) then -- FRIENDLY
			strName = className[tostring(unitOwner:GetClassId())] .. strName
		end
	end
	
	namePlate:FindChild("Name"):SetText(strName)
	
	-- Default visibility
	self:Show(namePlate:FindChild("NameContainer"), true)
	self:Show(namePlate:FindChild("Targeted"), false)

	-- Set Unit Level
	local nLevel = unitOwner:GetLevel()
	if nLevel ~= nil then healthPlate:FindChild("Level"):SetText(unitOwner:GetLevel()) end
	
	-- Show Numbers?
	self:Show(healthPlate:FindChild("HP"), 		self.setShowHealth)
	self:Show(healthPlate:FindChild("Level"),	self.setShowLevel)
	self:Show(healthPlate:FindChild("Armor"),	self.setShowArmor)
	self:Show(shieldPlate:FindChild("SP"), 		self.setShowShield)

	-- Set the name, guild, and hp text color
	self:SetNameColor(tNameplate)
	
	-- Some Static Color Settings
	healthPlate:FindChild("AbsorbBar"):SetBarColor(ApolloColor.new(self.setOpacity..self.setColorAbsorbBar))
	healthPlate:FindChild("HealthBarBack"):SetBarColor(ApolloColor.new(self.setOpacity..self.setColorBackdropBar))
	healthPlate:FindChild("HealthBarBack"):SetBGColor(ApolloColor.new(self.setOpacity..self.setColorBackgroundBar))
	shieldPlate:FindChild("ShieldBar"):SetBGColor(ApolloColor.new(self.setOpacity..self.setColorBackgroundBar))
	
	namePlate:FindChild("ClassResourceBar"):SetBGColor(ApolloColor.new(self.setOpacity..self.setColorBackdropBar))
	
	-- Does the Unit have a guild?
	local strGuild = ""
	local hasGuild = false
	if unitOwner:GetType() == "Player" and unitOwner:GetGuildName() and string.len(unitOwner:GetGuildName()) > 0 then
		hasGuild = true
		strGuild = String_GetWeaselString(Apollo.GetString("Nameplates_GuildDisplay"), unitOwner:GetGuildName())
	elseif unitOwner:GetType() ~= "Player" and unitOwner:GetAffiliationName() and string.len(unitOwner:GetAffiliationName()) > 0 then
		hasGuild = true
		strGuild = unitOwner:GetAffiliationName()
	end
	
	--Guild / Affiliation
	self:Show(namePlate:FindChild("GuildName"), hasGuild)
	if namePlate:FindChild("GuildName"):IsShown() then
		namePlate:FindChild("GuildName"):SetTextRaw(strGuild)
	end
	
	-- Show Quest/Path/Friend/Rival Icons
	if self.setShowIcons and not unitOwner:IsThePlayer() then
		local bHasRewards = self:ShowRewardIcons(tNameplate) > 0
		self:Show(namePlate:FindChild("QuestRewards"), bHasRewards)
	else
		self:Show(namePlate:FindChild("QuestRewards"), false)
	end
	
	-- What does In Combat mean to the user?
	--local tempInCombat = (self.setCombatSelf and self.bPlayerInCombat) or tNameplate.bInCombat
	local tempInCombat = (self.setCombatSelf and self.bPlayerInCombat) or unitOwner:IsInCombat()

	-- Plate Visibility User Settings
	tNameplate.bShowBars = false;
	if eDisposition == 1 then -- NEUTRAL
		self:Show(namePlate:FindChild("Name"), 		
			(self.setN_N and not tempInCombat) or (self.setN_N_C and tempInCombat)) -- self.bPlayerInCombat
		self:Show(namePlate:FindChild("GuildName"),
			hasGuild and ((self.setN_G and not tempInCombat) or (self.setN_G_C and tempInCombat)))
			
		tNameplate.bShowBars = (self.setN_B and not tempInCombat) or (self.setN_B_C and tempInCombat)
		tNameplate.bShowCastBar = (self.setN_CC and not tempInCombat) or (self.setN_C_C and tempInCombat)
		
		self:Show(namePlate:FindChild("Debuffs"),  (self.setN_D and not tempInCombat) or (self.setN_D_C and tempInCombat))
		
	elseif eDisposition == 0 then -- HOSTILE
		if unitOwner:GetType() == "Player" then
			self:Show(namePlate:FindChild("Name"), 
				(self.setHP_N and not tempInCombat) or (self.setHP_N_C and tempInCombat))
			self:Show(namePlate:FindChild("GuildName"),
				hasGuild and ((self.setHP_G and not tempInCombat) or (self.setHP_G_C and tempInCombat)))

			tNameplate.bShowBars = (self.setHP_B and not tempInCombat) or (self.setHP_B_C and tempInCombat)
			tNameplate.bShowCastBar = (self.setHP_C and not tempInCombat) or (self.setHP_C_C and tempInCombat)
			
			self:Show(namePlate:FindChild("Debuffs"),  (self.setHP_D and not tempInCombat) or (self.setHP_D_C and tempInCombat))
		else
			self:Show(namePlate:FindChild("Name"), 
				(self.setH_N and not tempInCombat) or (self.setH_N_C and tempInCombat))
			self:Show(namePlate:FindChild("GuildName"), 
				hasGuild and ((self.setH_G and not tempInCombat) or (self.setH_G_C and tempInCombat)))
				
			tNameplate.bShowBars = (self.setH_B and not tempInCombat) or (self.setH_B_C and tempInCombat)
			tNameplate.bShowCastBar = (self.setH_C and not tempInCombat) or (self.setH_C_C and tempInCombat)
			
			self:Show(namePlate:FindChild("Debuffs"),  (self.setH_D and not tempInCombat) or (self.setH_D_C and tempInCombat))
		end
	elseif eDisposition == 2 then -- FRIENDLY
		if unitOwner:GetType() == "Player" and unitOwner:IsInYourGroup() then --PARTY PLAYER
			self:Show(namePlate:FindChild("Name"),
				(self.setPP_N and not tempInCombat) or (self.setPP_N_C and tempInCombat))
			self:Show(namePlate:FindChild("GuildName"), 
				hasGuild and ((self.setPP_G and not tempInCombat) or (self.setPP_G_C and tempInCombat)))
				
			tNameplate.bShowBars = (self.setPP_B and not tempInCombat) or (self.setPP_B_C and tempInCombat)
			tNameplate.bShowCastBar = (self.setPP_C and not tempInCombat) or (self.setPP_C_C and tempInCombat)
			
			self:Show(namePlate:FindChild("Debuffs"),  (self.setPP_D and not tempInCombat) or (self.setPP_D_C and tempInCombat))
		
		elseif unitOwner:GetType() == "Player" then -- FRIENDLY PLAYER
			self:Show(namePlate:FindChild("Name"),
				(self.setFP_N and not tempInCombat) or (self.setFP_N_C and tempInCombat))
			self:Show(namePlate:FindChild("GuildName"), 
				hasGuild and ((self.setFP_G and not tempInCombat) or (self.setFP_G_C and tempInCombat)))
				
			tNameplate.bShowBars = (self.setFP_B and not tempInCombat) or (self.setFP_B_C and tempInCombat)
			tNameplate.bShowCastBar = (self.setFP_C and not tempInCombat) or (self.setFP_C_C and tempInCombat)
			
			self:Show(namePlate:FindChild("Debuffs"),  (self.setFP_D and not tempInCombat) or (self.setFP_D_C and tempInCombat))
		else -- FRIENDLY NPC
			local isImportant = self:IsImportantNPC(unitOwner)
		
			self:Show(namePlate:FindChild("Name"), 
				(self.setF_N and not tempInCombat) or (self.setF_N_C and tempInCombat) or (isImportant and self.setF_Important))
			
			self:Show(namePlate:FindChild("GuildName"),
				hasGuild and ((self.setF_G and not tempInCombat) or (self.setF_G_C and tempInCombat) or (isImportant and self.setF_Important)))
				
			tNameplate.bShowBars = (self.setF_B and not tempInCombat) or (self.setF_B_C and tempInCombat)
			tNameplate.bShowCastBar = (self.setF_C and not tempInCombat) or (self.setF_C_C and tempInCombat)
			
			self:Show(namePlate:FindChild("Debuffs"),  (self.setF_D and not tempInCombat) or (self.setF_D_C and tempInCombat))
		end
	end
	
	-- If My Nameplate ( can also use self.bPlayerInCombat )
	if unitOwner:IsThePlayer() then
		self:Show(namePlate:FindChild("Name"), 		
			(self.setM_N and not tempInCombat) or (self.setM_N_C and tempInCombat))
		self:Show(namePlate:FindChild("GuildName"), 	
			(self.setM_G and not tempInCombat and hasGuild) or (self.setM_G_C and tempInCombat and hasGuild))
			
		tNameplate.bShowBars = (self.setM_B and not tempInCombat) or (self.setM_B_C and tempInCombat)
		tNameplate.bShowCastBar = (self.setM_C and not tempInCombat) or (self.setM_C_C and tempInCombat)
		
		self:Show(namePlate:FindChild("Debuffs"),  (self.setM_D and not tempInCombat) or (self.setM_D_C and tempInCombat))	
	end
	
	-- If nameplate is targeted, apply user settings overrides
	if tNameplate.bIsTarget then
		if self.setT_M then
			self:Show(namePlate:FindChild("Targeted"), self.setT_M) 
			
			if eDisposition == 0 then 
				namePlate:FindChild("Targeted"):SetSprite("CRB_DatachronSprites:sprDC_RedPlayRing")
			elseif unitOwner:IsInYourGroup() then
				namePlate:FindChild("Targeted"):SetSprite("CRB_DatachronSprites:sprDC_BluePlayRing")
			else
				namePlate:FindChild("Targeted"):SetSprite("CRB_DatachronSprites:sprDC_GreenPlayRing")
			end
		end
		
		-- Overwrite for ShowTarget Settings
		if self.setT_N then self:Show(namePlate:FindChild("Name"), true) end
		if self.setT_G and hasGuild then self:Show(namePlate:FindChild("GuildName"), true) end

		tNameplate.bShowBars = self.setT_B 
		tNameplate.bShowCastBar = self.setT_C
		
		if self.setT_D then self:Show(namePlate:FindChild("Debuffs"), true ) end
		
		--if self.setT_B then self:Show(wndNameplate:FindChild("ShieldPlate"), true) end
		--if self.setT_B then self:Show(wndNameplate:FindChild("HealthPlate"), true) end
		
		--if self.setShowTargetBars and hasHealth then self:Show(tNameplate.wndNameplate:FindChild("HealthPlate"), true) end
		--if self.setShowTargetBars and hasShield then self:Show(tNameplate.wndNameplate:FindChild("ShieldPlate"), true) end
	else
		self:Show(namePlate:FindChild("Targeted"), false)
	end	
	
	-- Resize Name Window
	local nNameWidth = Apollo.GetTextWidth(self.setUnitNameFont, strName .. " ")
	
	if self.setUnitNameFont == "Nameplates" then
		namePlate:FindChild("Name"):SetFont(self.setUnitNameFont .. "")
	else
		namePlate:FindChild("Name"):SetFont(self.setUnitNameFont .. self.setUnitNameFontType)
	end
	namePlate:FindChild("Name"):SetAnchorOffsets(0, 0, nNameWidth, fontHeight[tostring(self.setUnitNameFont)])
	namePlate:FindChild("NameContainer"):SetAnchorOffsets(-200, 0, 200, fontHeight[tostring(self.setUnitNameFont)])
	namePlate:FindChild("NameContainer"):ArrangeChildrenHorz(1)
	
	-- Resize Guild Window
	local nGuildWidth = Apollo.GetTextWidth(self.setUnitGuildFont, strGuild .. " ")
	
	if self.setUnitGuildFont == "Nameplates" then
		namePlate:FindChild("GuildName"):SetFont(self.setUnitGuildFont .. "")
	else
		namePlate:FindChild("GuildName"):SetFont(self.setUnitGuildFont .. self.setUnitGuildFontType)
	end
	namePlate:FindChild("GuildName"):SetAnchorOffsets(-nGuildWidth/2, 0, nGuildWidth/2, fontHeight[tostring(self.setUnitGuildFont)])
	
	
	-- Arrange Nameplate
	namePlate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)

	-- Scale based on distance -- performance hit.
	--local scale = 1 - (tNameplate.nDistance / 22500) / 3 -- 22500 is the max distance squared
	
	if self.setPlateScale ~= 100 then
		local scale = self.setPlateScale / 100;
		
		namePlate:FindChild("TestPlateContainer"):SetScale(scale)
		local tempWidth = namePlate:FindChild("TestPlate"):GetWidth() * scale
		local tempHeight = namePlate:FindChild("TestPlate"):GetHeight() * scale
		
		tNameplate.wndNameplate:FindChild("TestPlateContainer"):SetAnchorOffsets(
			namePlate:FindChild("TestPlate"):GetWidth() / 2 - tempWidth / 2, 
			namePlate:FindChild("TestPlate"):GetHeight() - tempHeight, 
			namePlate:FindChild("TestPlate"):GetWidth() / 2 - tempWidth / 2 , 
			namePlate:FindChild("TestPlate"):GetHeight() - tempHeight)
	end
	
end

function BijiPlates:StyleConfig(tNameplate)
	if tNameplate.wndNameplate == nil then return end
	local namePlate = tNameplate.wndNameplate
	if self.setStyle == "flat" then 
	self:Show(namePlate:FindChild("HealthPlate_sao"), false)
		self:Show(namePlate:FindChild("ShieldPlate_sao"), false)
		--self:Show(namePlate:FindChild("HealthPlate_flat"), true)
		--self:Show(namePlate:FindChild("ShieldPlate_flat"), true)
		tNameplate.healthPlate = namePlate:FindChild("HealthPlate_flat")
		tNameplate.shieldPlate = namePlate:FindChild("ShieldPlate_flat")
	
		tNameplate.healthPlate:SetAnchorOffsets(-self.setFlatWidth/2, 0, self.setFlatWidth/2, self.setFlatHealthHeight) -- default is 100 * 14
		tNameplate.shieldPlate:SetAnchorOffsets(-self.setFlatWidth/2, 0, self.setFlatWidth/2, self.setFlatShieldHeight) -- default is 100 * 5
		

		tNameplate.healthPlate:FindChild("HealthBar"):SetFullSprite(healthTexture[self.setFlatHealthTexture])
		tNameplate.healthPlate:FindChild("HealthBarBack"):SetEmptySprite(healthTexture[self.setFlatHealthTexture])
		tNameplate.healthPlate:FindChild("HealthBarBack"):SetFullSprite(healthTexture[self.setFlatHealthTexture])
		tNameplate.healthPlate:FindChild("NotTargeting"):SetSprite("Flat_Border")
		
		tNameplate.shieldPlate:FindChild("ShieldBar"):SetEmptySprite(shieldTexture[self.setFlatShieldTexture])
		tNameplate.shieldPlate:FindChild("ShieldBar"):SetFullSprite(shieldTexture[self.setFlatShieldTexture])
		
		--Resource Bar
		namePlate:FindChild("ClassResource"):SetAnchorOffsets(-self.setFlatWidth/2, 0, self.setFlatWidth/2, 16)
		namePlate:FindChild("ClassResourceBar"):SetEmptySprite(healthTexture[self.setFlatHealthTexture])
		namePlate:FindChild("ClassResourceBar"):SetFullSprite(healthTexture[self.setFlatHealthTexture])
		namePlate:FindChild("ClassResourceText"):SetOpacity(0.7)
		
	else -- Default to SAO style
		--self:Show(namePlate:FindChild("HealthPlate_sao"), true)
		--self:Show(namePlate:FindChild("ShieldPlate_sao"), true)
		self:Show(namePlate:FindChild("HealthPlate_flat"), false)
		self:Show(namePlate:FindChild("ShieldPlate_flat"), false)
		tNameplate.healthPlate = namePlate:FindChild("HealthPlate_sao")
		tNameplate.shieldPlate = namePlate:FindChild("ShieldPlate_sao")
		
		tNameplate.healthPlate:SetAnchorOffsets(-self.setSAOSize/2, 0, self.setSAOSize/2, self.setSAOSize * 0.14) -- default is 100 * 14
		tNameplate.shieldPlate:SetAnchorOffsets(-self.setSAOSize/2, 0, self.setSAOSize/2, self.setSAOSize * 0.05) -- default is 100 * 5
		
		--Resource Bar
		namePlate:FindChild("ClassResource"):SetAnchorOffsets(-self.setSAOSize/2, 0, self.setSAOSize/2, 16)
		namePlate:FindChild("ClassResourceBar"):SetEmptySprite(healthTexture[self.setFlatHealthTexture])
		namePlate:FindChild("ClassResourceBar"):SetFullSprite(healthTexture[self.setFlatHealthTexture])
		namePlate:FindChild("ClassResourceText"):SetOpacity(0.7)
	end
end

function BijiPlates:SetNameColor(tNameplate)
	if tNameplate.wndNameplate == nil then return end
	local namePlate = tNameplate.wndNameplate
	local healthPlate = tNameplate.healthPlate
	local shieldPlate = tNameplate.shieldPlate 
	
	local unitOwner = tNameplate.unitOwner
	local eDisposition = unitOwner:GetDispositionTo(self.unitPlayerDisposComparisonTEMP)
	
	-- Disposition Color Changes
	local tempTextColor = self.setColorNeutralName
	unitController = unitOwner:GetUnitOwner() or unitOwner
	
	if eDisposition == 1 then -- NEUTRAL
		tempTextColor = self.setColorNeutralName
	elseif eDisposition == 0 then -- HOSTILE
		if unitOwner:GetType() == "Player" then
			if unitController:IsPvpFlagged() == true then
				tempTextColor = self.setColorHostilePlayerName
			else
				tempTextColor = self.setColorHostilePlayerNameUnflagged
			end
		else
			tempTextColor = self.setColorHostileName
		end
	elseif eDisposition == 2 then -- FRIENDLY
		if unitOwner:GetType() == "Player" then
			if unitOwner:IsInYourGroup() then
				tempTextColor = self.setColorPartyName
			elseif unitController:IsPvpFlagged() == true then
				tempTextColor = self.setColorFriendlyPlayerName
			else
				tempTextColor = self.setColorFriendlyPlayerNameUnflagged
			end
		else
			tempTextColor = self.setColorFriendlyName
		end
	end
	
	-- set Text Color
	tempTextColor = ApolloColor.new(self.setOpacity..tempTextColor)
	namePlate:FindChild("Name"):SetTextColor(tempTextColor)
	namePlate:FindChild("GuildName"):SetTextColor(tempTextColor)
	healthPlate:FindChild("HP"):SetTextColor(tempTextColor)
	shieldPlate:FindChild("SP"):SetTextColor(ApolloColor.new(self.setOpacity..self.setColorShieldBar))
end


-- Config button to the side of OPTIONS
function BijiPlates:OnConfigure()
	self:OnBijiPlatesOn()
end

-----------------------------------------------------------------------------------------------
-- BijiPlates Functions: DESTROY THE PLATES
-----------------------------------------------------------------------------------------------

function BijiPlates:UnattachNameplateWindow(tNameplate)
	if tNameplate.wndNameplate ~= nil then
		local idWnd = tNameplate.wndNameplate:GetId()
		tNameplate.wndNameplate:SetNowhere()
		tNameplate.wndNameplate:Show(false)
-- not sure why old nameplates are being saved, this would explain the balloon in memory.
--		table.insert(self.arFreeWindows, tNameplate.wndNameplate)
		tNameplate.wndNameplate:Destroy()
		tNameplate.wndNameplate = nil
		self.arDisplayedNameplates[idWnd] = nil
	end
end

function BijiPlates:OnUnitDestroyed(unitDead)
	local idUnit = unitDead:GetId()

	local tNameplate = self.arUnit2Nameplate[idUnit]
	if tNameplate == nil then
		return
	end

	self:UnattachNameplateWindow(tNameplate)
	self.arUnit2Nameplate[idUnit] = nil
end

-----------------------------------------------------------------------------------------------
-- BijiPlates Functions: DRAW THE PLATES
-----------------------------------------------------------------------------------------------

-- On Every Frame: Check the nameplates, then draw them.
function BijiPlates:OnFrame()
	-- Restore Settings.
	if self.restored == false then self:OptionsChanged(); self.restored = true; end

	if self.bRewardInfoDirty then self:UpdateRewardInfo(); end

	if self.playerUnit ~= nil and self.playerUnit:IsValid() then

		if not self.bInitialLoadAllClear then
			for idx, tNameplate in pairs(self.arDisplayedNameplates) do
				if tNameplate.wndNameplate ~= nil then
					tNameplate.wndNameplate:Show(false)
				end
			end
			return
		end
		
		subdued = false;
		local updateBuffsThisFrame = updateBuffs
		for idx, tNameplate in pairs(self.arUnit2Nameplate) do
			local bShowNameplate = self:DrawNameplate(tNameplate, updateBuffsThisFrame)
		end
		
		if subdued == false and subduedSent == false then
			if trackMaster then Apollo.GetAddon("TrackMaster"):SetTarget(nil) end
			subduedSent = true;
		end
	
		updateBuffs = false;
	else
		self.playerUnit = GameLib.GetPlayerUnit()
	end


end

function BijiPlates:UnitSettingLookup(tNameplate)
	local unitOwner = tNameplate.unitOwner
	if unitOwner == nil then return nil end
	if unitOwner:IsThePlayer() then
		return "M"
	elseif tNameplate.bIsTarget then
		return "T"
	elseif unitOwner:IsInYourGroup() then
		return "PP"
	elseif unitOwner:IsACharacter() then
		local eDisposition = unitOwner:GetDispositionTo(self.unitPlayerDisposComparisonTEMP) 
		if Unit.CodeEnumDisposition.Hostile == eDisposition then
			return "HP"
		else
			return "FP"
		end
	else 
		local eDisposition = unitOwner:GetDispositionTo(self.unitPlayerDisposComparisonTEMP) 
		if Unit.CodeEnumDisposition.Hostile == eDisposition then
			return "H"
		elseif Unit.CodeEnumDisposition.Neutral == eDisposition then
			return "N"
		else
			return "F"
		end

	end
end

function BijiPlates:DrawNameplate(tNameplate,updateBuffsThisFrame)

	-- Check to see if plate should be shown.	
	---------------------------------------------------
	local bShowNameplate = self:HelperVerifyVisibilityOptions(tNameplate) and self:CheckDrawDistance(tNameplate)
	
	if self.setWotWThrottle then
		local doNotRender = {
			"Coldburrow Hunter",
			"Coldburrow Minion",
			"Coldburrow Shaman",
			"Coldburrow Warrior",
		}
		
		if tNameplate.unitOwner ~= nil then
			for _,v in ipairs(doNotRender) do
				if tNameplate.unitOwner:GetName() == v then
					bShowNameplate = false
				end
			end
		end
	end

	if not bShowNameplate then
		self:UnattachNameplateWindow(tNameplate)
		return false
	end
	
	if self.setNeverShow then
		if tNameplate.wndNameplate ~= nil then 
			tNameplate.wndNameplate:Destroy()
			tNameplate.wndNameplate = nil
		end
		return false
	end
	
	self:CreateNameplateWindow(tNameplate)

	-- Check Occlusion setting.
	if (self.setEnableOcclusion and tNameplate.bOccluded) or not tNameplate.bOnScreen then 
		bShowNameplate = false
	end

	-- Show Nameplate?
	if not bShowNameplate then
		if tNameplate.wndNameplate ~= nil then
			self:Show(tNameplate.wndNameplate, false)
		end
		return false
	end

	if tNameplate.unitOwner == nil then return false end
	local unitOwner = tNameplate.unitOwner
	local namePlate = tNameplate.wndNameplate
	
	--self:StyleConfig(tNameplate)
	local healthPlate = tNameplate.healthPlate
	local shieldPlate = tNameplate.shieldPlate 
	
	-- Mounted?
	if unitOwner:IsMounted() and namePlate:GetUnit() == unitOwner then
		namePlate:SetUnit(tNameplate.unitOwner:GetUnitMount(), 1)
    elseif not unitOwner:IsMounted() and namePlate:GetUnit() ~= unitOwner then
		namePlate:SetUnit(unitOwner, 1)
    end

	-- Subdue Weapon Tracker
	if unitOwner:GetType() == "Pickup" then
		local len = string.len(GameLib.GetPlayerUnit():GetName());
		if string.sub(unitOwner:GetName(), 1, len) == GameLib.GetPlayerUnit():GetName() then
			local loc = unitOwner:GetAttachmentPosition(1)["tLocation"]
			vec = Vector3.New(loc.x, loc.y, loc.z)
			if trackMaster then Apollo.GetAddon("TrackMaster"):SetTarget(vec) end
			subdued = true;
			subduedSent = false;
		end
	end

	-- Debugging
	if bDebug and unitOwner:IsThePlayer() and bCheckUnit == false then
		Event_FireGenericEvent("SendVarToRover", "unitOwner", unitOwner)
		Event_FireGenericEvent("SendVarToRover", "GetPosition", unitOwner:GetPosition())
		Event_FireGenericEvent("SendVarToRover", "vec", vec)
		bCheckUnit = true;
		
		--Print("ticktime:" .. tostring(unitOwner:GetShieldTickTime()))
		--Print("reboot:" .. tostring(unitOwner:GetShieldRebootTime()))
	end
	
	-- Get Info about the owner of the plate	
	---------------------------------------------------

	-- Check the disposition (friendly, neutral, hostile)
	if not self.unitPlayerDisposComparisonTEMP then
		self.unitPlayerDisposComparisonTEMP = GameLib.GetPlayerUnit()
	end

	local bWndMain = not tNameplate.bIsTarget and not tNameplate.bIsCluster
	local eDisposition = unitOwner:GetDispositionTo(self.unitPlayerDisposComparisonTEMP)
	
	local nHealthCurrent = unitOwner:GetHealth()
	local nHealthMax = unitOwner:GetMaxHealth()
	local nHealthPercent = 100
	
	local nAbsorbCurrent = unitOwner:GetAbsorptionValue()
	local nAbsorbMax = unitOwner:GetAbsorptionMax()
	
	local nShieldCurrent = unitOwner:GetShieldCapacity()
	local nShieldMax = unitOwner:GetShieldCapacityMax()
	--local nShieldReboot = unitOwner:GetShieldRebootTime() / 1000
	
	local nVulnerable = unitOwner:GetCCStateTimeRemaining(Unit.CodeEnumCCState.Vulnerability)
	
	local totalHealthPercentage = 0
	
	-- Double check nameplate color.
	self:SetNameColor(tNameplate)
	
	-- Interupt Armor
	healthPlate:FindChild("ArmorNumber"):SetText(unitOwner:GetInterruptArmorValue())
	self:Show(healthPlate:FindChild("Armor"), unitOwner:GetInterruptArmorValue() > 0 and self.setShowArmor )
	
	-- Set Plate Bars: Health, Shield, Vuln.
	---------------------------------------------------
	if tNameplate.bShowBars then
		local hasHealth = true
		-- Hit Points Text (hide if 0)
		if not nHealthCurrent or nHealthCurrent <= 0 then 
			if unitOwner:GetType() ~= "Player" then
				self:Show(healthPlate, false)
				hasHealth = false
			end
			nHealthCurrent = 0
		elseif nHealthCurrent > 0 then
			self:Show(healthPlate, true)
			nHealthPercent = (unitOwner:GetHealth() / unitOwner:GetMaxHealth()) * 100
			
			if self.setShowHealthDeficit then
				if self.setShowHealthPercent then
					healthPlate:FindChild("HP"):SetText(tostring(100 - math.floor(nHealthPercent)).."%")
				else
					healthPlate:FindChild("HP"):SetText(self:HelperFormatBigNumber(unitOwner:GetMaxHealth() - nHealthCurrent))
				end
			else
				if self.setShowHealthPercent then
					healthPlate:FindChild("HP"):SetText(tostring(math.floor(nHealthPercent)).."%")
				else
					healthPlate:FindChild("HP"):SetText(self:HelperFormatBigNumber(nHealthCurrent))
				end
			end
		end
		
		local hasShield = true
		-- Shield Points Text (hide if 0)
		if nShieldCurrent == nil or nShieldMax == nil or nShieldCurrent <= 0 or nShieldMax <= 0 then 
			if unitOwner:GetType() ~= "Player" then
				--self:Show(shieldPlate:FindChild("ShieldPlate"), false)
				self:Show(shieldPlate, false)
				hasShield = false
			end
			nShieldCurrent = 0
		elseif nShieldCurrent > 0 and nShieldMax > 0 then
			self:Show(shieldPlate, true)
			nShieldPercent = (unitOwner:GetShieldCapacity() / unitOwner:GetShieldCapacityMax()) * 100
			
			if self.setShowShieldDeficit then
				if self.setShowShieldPercent then
					shieldPlate:FindChild("SP"):SetText(tostring(100 - math.floor(nShieldPercent)).."%")
				else
					shieldPlate:FindChild("SP"):SetText(self:HelperFormatBigNumber(unitOwner:GetShieldCapacityMax() - nShieldCurrent))
				end
			else
				if self.setShowShieldPercent then
					shieldPlate:FindChild("SP"):SetText(tostring(math.floor(nShieldPercent)).."%")
				else
					shieldPlate:FindChild("SP"):SetText(self:HelperFormatBigNumber(nShieldCurrent))
				end
			end
		end
		
		-- Fill Health Bar
		healthPlate:FindChild("HealthBar"):SetMax(nHealthMax or 0)
		healthPlate:FindChild("HealthBar"):SetProgress(nHealthCurrent or 0)
		healthPlate:FindChild("HealthBarBack"):SetMax(nHealthMax or 0)
		healthPlate:FindChild("HealthBarBack"):SetProgress(nHealthCurrent or 0, (nHealthMax or 1) / 4 )
		
		-- Fill Absorb Bar
		healthPlate:FindChild("AbsorbBar"):SetMax(nHealthMax or 0)
		healthPlate:FindChild("AbsorbBar"):SetProgress(nAbsorbCurrent or 0)

		-- Fill Shield Bar
		shieldPlate:FindChild("ShieldBar"):SetMax(nShieldMax or 0)
		shieldPlate:FindChild("ShieldBar"):SetProgress(nShieldCurrent or 0)
		
		-- Fill Shield Timer Bar -- Not Possible yet?
		--shieldPlate:FindChild("ShieldTimerBar"):SetMax(8)
		--shieldPlate:FindChild("ShieldTimerBar"):SetProgress(nShieldReboot <= 5 and nShieldReboot > 0 and nShieldReboot or 0, 1)
		
		-- Disposition Color Changes (Bars)
		local tempBarColor = self.setColorNeutralBars
		if eDisposition == 1 then -- NEUTRAL
			tempBarColor = nHealthPercent > self.setHealthCutoff 
					and self.setColorNeutralBar
					or  self.setColorNeutralBarCutoff
		elseif eDisposition == 0 then -- HOSTILE
			if unitOwner:GetType() == "Player" then
				tempBarColor = nHealthPercent > self.setHealthCutoff 
					and self.setColorHostilePlayerBar
					or  self.setColorHostilePlayerBarCutoff
			else
				tempBarColor = nHealthPercent > self.setHealthCutoff 
					and self.setColorHostileBar
					or  self.setColorHostileBarCutoff
			end
		elseif eDisposition == 2 then -- FRIENDLY
			if unitOwner:GetType() == "Player" then
				tempBarColor = nHealthPercent > self.setHealthCutoff 
					and self.setColorFriendlyPlayerBar
					or  self.setColorFriendlyPlayerBarCutoff
			else
				tempBarColor = nHealthPercent > self.setHealthCutoff 
					and self.setColorFriendlyBar
					or  self.setColorFriendlyBarCutoff
			end
		end
		
		-- Class Colors
		if self.setShowClassColors and unitOwner:GetType() == "Player" and nHealthPercent > self.setHealthCutoff then
			if 	   unitOwner:GetClassId() == 1 then tempBarColor = self.setColorWarriorBar 
			elseif unitOwner:GetClassId() == 5 then tempBarColor = self.setColorStalkerBar 
			elseif unitOwner:GetClassId() == 2 then tempBarColor = self.setColorEngineerBar 
			
			elseif unitOwner:GetClassId() == 3 then tempBarColor = self.setColorEsperBar 
			elseif unitOwner:GetClassId() == 7 then tempBarColor = self.setColorSpellslingerBar 
			elseif unitOwner:GetClassId() == 4 then tempBarColor = self.setColorMedicBar 
			end
		end
	
		if nVulnerable ~= 0 then tempBarColor = self.setColorVulnerableBar end
		
		if tempBarColor ~= nil then tempBarColor = ApolloColor.new(self.setOpacity..tempBarColor) end
		
		healthPlate:FindChild("HealthBar"):SetBarColor(tempBarColor)
		shieldPlate:FindChild("ShieldBar"):SetBarColor(ApolloColor.new(self.setOpacity..self.setColorShieldBar))

		healthPlate:FindChild("VulnerableBar"):SetBarColor(ApolloColor.new(self.setOpacity..self.setColorVulnerableTimerBar))
		
		if nVulnerable == nil or nVulnerable == 0 then
			self:Show(healthPlate:FindChild("VulnerableBar"), false)
		elseif nVulnerable == 0 and nVulnerable ~= tNameplate.nVulnerableTime then
			tNameplate.nVulnerableTime = 0 -- casting done, set back to 0
			self:Show(healthPlate:FindChild("VulnerableBar"), false)
		elseif nVulnerable ~= 0 and nVulnerable > tNameplate.nVulnerableTime then
			tNameplate.nVulnerableTime = nVulnerable
			self:Show(healthPlate:FindChild("VulnerableBar"), true)
		elseif nVulnerable ~= 0 and nVulnerable < tNameplate.nVulnerableTime then
			healthPlate:FindChild("VulnerableBar"):SetMax(tNameplate.nVulnerableTime)
			healthPlate:FindChild("VulnerableBar"):SetProgress(nVulnerable)
		end
		
		if hasHealth and hasShield then
			totalHealthPercentage = (nHealthCurrent + nShieldCurrent)/(nHealthMax + nShieldMax)
		elseif hashealth then
			totalHealthPercentage = nHealthCurrent / nHealthMax
		end
		
		if self.setHideFullFriendlyBars == true and eDisposition == 2 and unitOwner:IsThePlayer() == false and tNameplate.bIsTarget == false then
			self:Show(healthPlate, totalHealthPercentage < 0.95 and hasHealth)
			self:Show(shieldPlate, totalHealthPercentage < 0.95 and hasShield)
		else 
			self:Show(healthPlate, hasHealth)
			self:Show(shieldPlate, hasShield)
		end
		
	else
		self:Show(healthPlate, false)
		self:Show(shieldPlate, false)
	end
	
	
	-- Set Plate Bars: Cast bar.
	---------------------------------------------------
	--if tNameplate.bShowCastBar and unitOwner:ShouldShowCastBar() and not bHiddenUnit then
	if tNameplate.bShowCastBar and unitOwner:ShouldShowCastBar() then
		namePlate:FindChild("CastBar"):SetMax(unitOwner:GetCastDuration())
		namePlate:FindChild("CastBar"):SetProgress(unitOwner:GetCastElapsed(), unitOwner:GetCastDuration())
		namePlate:FindChild("CastBar"):SetBarColor(ApolloColor.new(self.setOpacity..self.setColorCastBar))
		
		namePlate:FindChild("CastBarLabel"):SetText(unitOwner:GetCastName())
		if self.setUnitNameFont == "Nameplates" then
			namePlate:FindChild("CastBarLabel"):SetFont(self.setUnitNameFont .. "")
		else
			namePlate:FindChild("CastBarLabel"):SetFont(self.setUnitNameFont .. self.setUnitNameFontType)
		end
		
		self:Show(namePlate:FindChild("Cast"), true)
	else
		namePlate:FindChild("CastBar"):SetProgress(0)
		self:Show(namePlate:FindChild("Cast"), false)
	end
	

	-- Update Buff Related Info. (timer)
	---------------------------------------------------
	local buffSetting = "set" .. self:UnitSettingLookup(tNameplate) .. "_D"
	if tNameplate.unitOwner:IsInCombat() then
		buffSetting = buffSetting .. "_C"
	end
	if updateBuffsThisFrame and self[buffSetting] then
		-- Buff Info
		---------------------------------------------------
		local myBuffs = unitOwner:GetBuffs() 
		local debuffs = myBuffs["arHarmful"]
		local buffs   = myBuffs["arBeneficial"]
			
		if bDebug and bCheckBuffs == false then --Set bDebug to true to send to rover
			Event_FireGenericEvent("SendVarToRover", "myBuffs", myBuffs); 
			Event_FireGenericEvent("SendVarToRover", "buffs", buffs);
			if tablelength(buffs) > 0 then bCheckBuffs = true; end
		end
			
		-- Cleanse Icon: colored borders/icon for cleansing
		---------------------------------------------------
		self:Show(healthPlate:FindChild("CleanseIcon"), false) -- SAO
		
		if self.setShowCleanseAlert == true and eDisposition == 2 then 
			for key, value in pairs(debuffs) do
				if value["splEffect"]:GetClass() == 38 then -- 38 = debuff dispellable
					self:Show(healthPlate:FindChild("CleanseIcon"), true)
					break;
				end
			end
		end
		
		
		-- Debuff / buff display
		---------------------------------------------------
		local tempBuffs = (eDisposition == 2 and buffs) or debuffs

		if namePlate:FindChild("Debuffs"):IsShown() and tempBuffs ~= nil then
			local indexBuffs = {}
			-- the buff identifiers are numeric, so when we iterate over indexBuffs, we will need to use ipairs
			for k,v in pairs(tempBuffs) do
				local buffId = "" .. v["idBuff"]
				indexBuffs[buffId] = v
			end

			local buffsPerRow = 6;
			local maxBuffRows = 2;
			
			local buffWidth = 24;
			local buffCount = 0;
			local buffChange = false

			-- update/remove any buffs that have fallen off
			local row = nil
			local wnd = nil
			local activeIcons = {}
			local rows = 0;
			for _, r in pairs(namePlate:FindChild("Debuffs"):GetChildren()) do
				row = r
				rows = rows + 1
				buffCount = 0
				for _, wnd in pairs(row:GetChildren()) do
					local buffId = "" .. wnd:GetName()
					local value = indexBuffs[buffId]
					-- destroy any buffs that have fallen off
					if value == nil or (value ~= nil and not (value["fTimeRemaining"] and value["fTimeRemaining"] > 0 and value["fTimeRemaining"] <= self.setBuffCutoff)) then
						wnd:Destroy()
						buffChange = true
					else
					-- update any buffs that are still valid
						buffCount = buffCount + 1
						activeIcons[buffId] = wnd
						wnd:FindChild("Time"):SetText(self:HelperFormatTime(value["fTimeRemaining"]))
						if (value["nCount"] > 1) then wnd:FindChild("DebuffCount"):SetText(value["nCount"]) end
					end
				end
			end

			-- add any NEW buffs 
			-- row will have the current row, rows will have the current Row count, and buffCount will have the current number of buffs
			for buffId, value in pairs(indexBuffs) do
				if rows > maxBuffRows then break; end
				if activeIcons[buffId] == nil then
					-- this is a new buff!
					if value["fTimeRemaining"] and value["fTimeRemaining"] > 0 and value["fTimeRemaining"] <= self.setBuffCutoff then

						if row == nil then
							row = Apollo.LoadForm("BijiPlates.xml", "DebuffRow",  namePlate:FindChild("Debuffs"), self)
							rows = rows + 1;
						elseif buffCount == buffsPerRow then
							row:ArrangeChildrenHorz(1)
							row = Apollo.LoadForm("BijiPlates.xml", "DebuffRow",  namePlate:FindChild("Debuffs"), self)
							rows = rows + 1;
							buffCount = 0;
						end

						buffCount = buffCount + 1;
						wnd = Apollo.LoadForm("BijiPlates.xml", "DebuffFrame",  row, self)	
						wnd:SetName(buffId)
						buffWidth = wnd:GetWidth();

						wnd:FindChild("Time"):SetText(self:HelperFormatTime(value["fTimeRemaining"]))
						if (value["splEffect"]:GetIcon()) then wnd:FindChild("DebuffIcon"):SetSprite(value["splEffect"]:GetIcon()) end
						if (value["nCount"] > 1) then wnd:FindChild("DebuffCount"):SetText(value["nCount"]) end
						buffChange = true
					end
				end
			end			

			if buffChange then
				row:ArrangeChildrenHorz(1)
				local hOffset = (buffsPerRow * buffWidth) / 2;
				namePlate:FindChild("Debuffs"):SetAnchorOffsets(-hOffset, 0, hOffset, buffCount == 0 and 0 or rows * row:GetHeight())
				namePlate:FindChild("Debuffs"):ArrangeChildrenVert(2)
			end
--			Print("-------------------------------------------")
		end
		
	end -- Buff/Debuff Updating
	
	
	-- Resource Bar
	self:Show(
		namePlate:FindChild("ClassResource"), 
		unitOwner:IsThePlayer() and ((unitOwner:IsInCombat() and self.setM_R_C) or (self.setM_R and not unitOwner:IsInCombat())))
	
	if unitOwner:IsThePlayer() then

		local resID = 1
		if unitOwner:GetClassId() == GameLib.CodeEnumClass.Stalker then resID = 3 end
		
		local nResourceMax = unitOwner:GetMaxResource(resID) or 0
		local nResourceCurrent = unitOwner:GetResource(resID) or 0
		namePlate:FindChild("ClassResourceBar"):SetMax(nResourceMax )
		namePlate:FindChild("ClassResourceBar"):SetProgress(nResourceCurrent )
		
		namePlate:FindChild("ClassResourceText"):SetText(nResourceCurrent )
	end
	
	
	--Speech bubble: set opacity down a bit.
	---------------------------------------------------
	if tNameplate.bSpeechBubble and eDisposition == 2 then
		namePlate:FindChild("TestPlateContainer"):SetOpacity(0.3)
    else
		namePlate:FindChild("TestPlateContainer"):SetOpacity(1)
    end


	-- No Threat: Chech to see if non-player unit is targeting the player
	---------------------------------------------------
	local noThreat = false;	
	if self.setShowThreatAlert == true 
			and eDisposition ~= 2 
			and unitOwner:GetTarget() 
			and unitOwner:GetTarget() ~= nil 
			and unitOwner:GetTarget():IsThePlayer() == false 
			and unitOwner:GetType() == "NonPlayer" then
		noThreat = true
	end
	self:Show(healthPlate:FindChild("NotTargeting"), noThreat)
	self:Show(healthPlate:FindChild("NotTargetingIcon"), noThreat)
	
	
	-- Arrange Nameplate
	---------------------------------------------------
	namePlate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)
	healthPlate:FindChild("InfoPlate"):ArrangeChildrenHorz( self.setStyle == "sao" and 2 or 0)
	
	self:Show(namePlate, bShowNameplate)
	--self:Show(tNameplate.wndNameplate, true)
	--self:Show(tNameplate.wndNameplate, unitOwner:ShouldShowNamePlate())
	
	return bShowNameplate
end

function tablelength(T)
	local count = 0
	for _ in pairs(T) do count = count + 1 end
	return count
end

function round(val, decimal)
	if (decimal) then
		return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
	else
		return math.floor(val+0.5)
	end
end

-----------------------------------------------------------------------------------------------
-- GAME STATE UPDATE FUNCTIONS
-----------------------------------------------------------------------------------------------

-- Called from the nameplate window. 
function BijiPlates:OnWorldLocationOnScreen(wndHandler, wndControl, bOnScreen)
	if self.arDisplayedNameplates[wndHandler:GetId()] ~= nil then
		self.arDisplayedNameplates[wndHandler:GetId()].bOnScreen = bOnScreen
	end
end

-- Called from the nameplate window.
function BijiPlates:OnUnitOcclusionChanged(wndHandler, wndControl, bOccluded)
	--if self.setEnableOcclusion and self.arDisplayedNameplates[wndHandler:GetId()] ~= nil then
	if self.arDisplayedNameplates[wndHandler:GetId()] ~= nil then
		self.arDisplayedNameplates[wndHandler:GetId()].bOccluded = bOccluded
	end
end


function BijiPlates:OnEnteredCombat(unitChecked, bInCombat)
	if unitChecked == GameLib.GetPlayerUnit() then
		self.bPlayerInCombat = bInCombat
	end
	if unitChecked ~= nil then 
		tNameplate = self.arUnit2Nameplate[unitChecked:GetId()]
		if tNameplate ~= nil then 
			--Print("Combat: " .. unitChecked:GetName() .. " (" .. tostring(bInCombat) .. ")")
			tNameplate.bInCombat = bInCombat
			self:SetNormalNameplate(tNameplate)
		end
	end
	-- Might need to do this for combat plates. Or just do it all in the draw function.
	if(self.setCombatSelf) then self:OptionsChanged() end
	--Print("Entered Combat")
end

function BijiPlates:OnUnitTextBubbleToggled(tUnitArg, strText)
	local idUnit = tUnitArg:GetId()

	if not self.arUnit2Nameplate or not self.arUnit2Nameplate[idUnit] then
		return
	end

	if strText and strText ~= "" then
		self.arUnit2Nameplate[idUnit].bSpeechBubble = true
	else
		self.arUnit2Nameplate[idUnit].bSpeechBubble = false
	end
end

-- build targeted options here; we get this event when a creature attacks, too
function BijiPlates:OnTargetUnitChanged(unitOwner) 
	local tNameplate = nil
	if unitOwner ~= nil then
		tNameplate = self.arUnit2Nameplate[unitOwner:GetId()]
	end
	if tNameplate ~= nil then
		if tNameplate.bIsTarget then
			return
		end
	elseif unitOwner ~= nil then
		self:CreateNameplateObject(unitOwner)
	end

	for idx, tNameplate in pairs(self.arUnit2Nameplate) do
		if tNameplate.bIsTarget == true or tNameplate.bIsCluster == true then
			tNameplate.bIsTarget = false
			tNameplate.bIsCluster = false
			self:ParseRewards(tNameplate)
			local unitCurr = tNameplate.unitOwner

			local bHideMine = unitCurr:IsThePlayer() 
				and not self.setShowMyName
				and not self.setShowMyGuild
				and not self.setShowMyBars

			if bHideMine or unitCurr:IsDead() or not unitCurr:ShouldShowNamePlate() then
				self:UnattachNameplateWindow(tNameplate)
			else
				self:SetNormalNameplate(tNameplate)
			end
			if tNameplate.wndNameplate ~= nil then
				tNameplate.wndNameplate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)
			end
		end
	end
	
	if unitOwner == nil then return end

	local tCluster = unitOwner:GetClusterUnits()
	local tAdjustedNameplates = {} -- built a temp table for the nameplates that need adjustment

	for idx, tNameplate in pairs(self.arUnit2Nameplate) do  -- identify targets and cluster members
		local unitCurr = tNameplate.unitOwner
		if unitOwner == unitCurr then
			tNameplate.bIsTarget = true -- set target
			table.insert(tAdjustedNameplates, tNameplate) -- add that unit's nameplate
		end

		if tCluster ~= nil then
			for idx = 1, #tCluster do
				if tCluster[idx] == unitCurr then
					if tNameplate.bIsTarget ~= true then -- don't re-add the primary target
						tNameplate.bIsCluster = true -- set cluster
						table.insert(tAdjustedNameplates, tNameplate) -- add that nameplate
					end
				end
			end
		end
	end

	for idx = 1, #tAdjustedNameplates do -- format the nameplates that need adjusting
		local unitCurr = tAdjustedNameplates[idx].unitOwner
		self:ParseRewards(tAdjustedNameplates[idx])
		local bHideMine = unitCurr:IsThePlayer() 
				and not self.setShowMyName
				and not self.setShowMyGuild
				and not self.setShowMyBars
		if bHideMine or unitCurr:IsDead() or not unitCurr:ShouldShowNamePlate() then
			if tAdjustedNameplates[idx].bIsTarget then
				self:UnattachNameplateWindow(tAdjustedNameplates[idx])
				tAdjustedNameplates[idx].bIsTarget = true -- reset (clearing the nameplate makes this false)
			else -- has to be the cluster to get on the table
				self:UnattachNameplateWindow(tAdjustedNameplates[idx])
				tAdjustedNameplates[idx].bIsCluster = true -- reset (clearing the nameplate makes this false)
			end
		else
			if tAdjustedNameplates[idx].wndNameplate == nil then
				self:CreateNameplateWindow(tAdjustedNameplates[idx])
			end
			self:SetNormalNameplate(tAdjustedNameplates[idx])
		end
		if tAdjustedNameplates[idx].wndNameplate ~= nil then
			--tAdjustedNameplates[idx].wndNameplate:FindChild("Targeted"):Show(self.bShowMarkerTarget)
			--tAdjustedNameplates[idx].wndNameplate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)
		end
	end

	tAdjustedNameplates = nil
end


function BijiPlates:OnUnitPvpFlagsChanged(unitUpdated, tNameplate)
	if tNameplate == nil then
		tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
		if tNameplate == nil then
			return
		end
	end
	self:SetNormalNameplate(tNameplate)
end

function BijiPlates:OnUnitNameChanged(unitUpdated, strNewName)
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then return end

	self:SetNormalNameplate(tNameplate)
end

function BijiPlates:OnUnitTitleChanged(unitUpdated)
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then return end
	local bHideMine = unitUpdated :IsThePlayer() 
		and not self.setShowMyName
		and not self.setShowMyGuild
		and not self.setShowMyBars
	
	
	if bHideMine or unitUpdated:IsDead() or not unitUpdated:ShouldShowNamePlate() then
		self:UnattachNameplateWindow(tNameplate)
	else
		self:SetNormalNameplate(tNameplate)
	end
end

function BijiPlates:OnPlayerTitleChanged()
	local unitUpdated = GameLib.GetPlayerUnit()
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then return end
	
	local bHideMine = unitUpdated :IsThePlayer() 
		and not self.setShowMyName
		and not self.setShowMyGuild
		and not self.setShowMyBars
		
	if bHideMine or unitUpdated:IsDead() or not unitUpdated:ShouldShowNamePlate() then
		self:UnattachNameplateWindow(tNameplate)
	else
		self:SetNormalNameplate(tNameplate)
	end
end

function BijiPlates:OnUnitGuildNameplateChanged(unitUpdated)
	local tNameplate = self.arUnit2Nameplate[unitUpdated:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then return end
	
	local bHideMine = unitUpdated :IsThePlayer() 
		and not self.setShowMyName
		and not self.setShowMyGuild
		and not self.setShowMyBars
		
	if bHideMine or unitUpdated:IsDead() or not unitUpdated:ShouldShowNamePlate() then
		self:UnattachNameplateWindow(tNameplate)
	else
		self:SetNormalNameplate(tNameplate)
	end
end

function BijiPlates:OnGuildDirty(unitOwner, tNameplate)
	if self.guildDisplayed then
		tNameplate.bIsGuildMember = self.guildDisplayed:IsUnitMember(unitOwner)
	else
		tNameplate.bIsGuildMember = false
	end

	if self.guildWarParty then
		tNameplate.bIsWarPartyMember = self.guildWarParty:IsUnitMember(unitOwner)
	else
		tNameplate.bIsWarPartyMember = false
	end
end

function BijiPlates:OnUnitMemberOfGuildChange(unitOwner)
	if unitOwner == nil then
		return
	end

	local tNameplate = self.arUnit2Nameplate[unitOwner:GetId()]
	if tNameplate == nil or tNameplate.wndNameplate == nil then
		return
	end

	self:OnGuildDirty(unitOwner, tNameplate)

	self:OnUnitPvpFlagsChanged(unitOwner, tNameplate)
end

function BijiPlates:OnGuildChange()
	self.guildDisplayed = nil
	self.guildWarParty = nil
	for key, guildCurr in pairs(GuildLib.GetGuilds()) do
		if guildCurr:GetType() == GuildLib.GuildType_Guild then
			self.guildDisplayed = guildCurr
		end
		if guildCurr:GetType() == GuildLib.GuildType_WarParty then
			self.guildWarParty = guildCurr
		end
	end

	for key, tNameplate in pairs(self.arUnit2Nameplate) do
		local unitOwner = tNameplate.unitOwner
		self:OnGuildDirty(unitOwner, tNameplate)
		self:OnUnitPvpFlagsChanged(unitOwner, tNameplate)
	end
end

function BijiPlates:OnKeyBindingUpdated(strKeybind)
	if strKeybind ~= "Path Action" and strKeybind ~= "Cast Objective Ability" then
		return
	end

	self.strPathActionKeybind = GameLib.GetKeyBinding("PathAction")
	self.bPathActionUsesIcon = false
	if self.strPathActionKeybind == Apollo.GetString("HUDAlert_Unbound") or #self.strPathActionKeybind > 1 then -- Don't show interact
		self.bPathActionUsesIcon = true
	end

	self.strQuestActionKeybind = GameLib.GetKeyBinding("CastObjectiveAbility")
	self.bQuestActionUsesIcon = false
	if self.strQuestActionKeybind == Apollo.GetString("HUDAlert_Unbound") or #self.strQuestActionKeybind > 1 then -- Don't show interact
		self.bQuestActionUsesIcon = true
	end

	self:OptionsChanged()
end


function BijiPlates:OnQuestStateChanged()
	self:OnRewardInfoUpdated()
end

function BijiPlates:OnQuestObjectiveUpdated()
	self:OnRewardInfoUpdated()
end

function BijiPlates:OnUnitActivationTypeChanged()
	self:OnRewardInfoUpdated()
end

function BijiPlates:OnPublicEventStart()
	if self.bShowRewardTypePublicEvent then
		self:OnRewardInfoUpdated()
	end
end

function BijiPlates:OnPublicEventObjectiveUpdate()
	if self.bShowRewardTypePublicEvent then
		self:OnRewardInfoUpdated()
	end
end

function BijiPlates:OnPublicEventEnd()
	if self.bShowRewardTypePublicEvent then
		self:OnRewardInfoUpdated()
	end
end

function BijiPlates:OnChallengeUpdate()
	self:OnRewardInfoUpdated()
end

--[[ Deprecated
function BijiPlates:OnChallengeCompleted() -- TODO: Hack because network traffic seems to delay the update to "completed"
	if self.bShowRewardTypeChallenge then
		Apollo.RegisterTimerHandler("ChallengeCompletedTimer", "OnRewardInfoUpdated", self)
		Apollo.CreateTimer("ChallengeCompletedTimer", 0.2, false)
		--self:OnRewardInfoUpdated()
	end
end
]]

function BijiPlates:OnPlayerPathMissionChange()
	if self.bShowRewardTypeMission then
		self:OnRewardInfoUpdated()
	end
end


-----------------------------------------------------------------------------------------------
function BijiPlates:OnRewardInfoUpdated() -- we've recieved an external signal that reward stuff has been changed
	self.bRewardInfoDirty = true
end

function BijiPlates:UpdateRewardInfo()
	if self.bInitialLoadAllClear == false then
		return
	end

	self.bRewardInfoDirty = false

	-- Quest backers first
	local tAdjustObjectives = {}
	for idx, tNameplate in pairs(self.arUnit2Nameplate) do
		local bObjective = self:ParseRewards(tNameplate) -- get the new value
		if tNameplate.bIsObjective ~= bObjective then -- compare to old
			table.insert(tAdjustObjectives, tNameplate) -- add to list if they're not the same
		end
	end

	if tAdjustObjectives ~= nil then
		for idx, tNameplate in pairs(tAdjustObjectives) do
			local unitOwner = tNameplate.unitOwner
			local bHideMine = unitOwner:IsThePlayer() 
				and not self.setShowMyName
				and not self.setShowMyGuild
				and not self.setShowMyBars
			
			if bHideMine or unitOwner:IsDead() or not unitOwner:ShouldShowNamePlate() then
				self:UnattachNameplateWindow(tNameplate)
			else
				self:SetNormalNameplate(tNameplate)
			end
			if tNameplate.wndNameplate ~= nil then
				tNameplate.wndNameplate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)
			end
		end
	end

	if self.bShowRewardsMain == false and self.bShowRewardsTarget == false then -- don't process rewards if they're not shown
		return
	end

	--There's no real efficient way to do this since the target may have the same number of rewards but have different info for them
	for idx, tNameplate in pairs(self.arUnit2Nameplate) do -- run the list
		local unitOwner = tNameplate.unitOwner
		local bHideMine = unitOwner:IsThePlayer() 
				and not self.setShowMyName
				and not self.setShowMyGuild
				and not self.setShowMyBars
		if bHideMine or unitOwner:IsDead() or not unitOwner:ShouldShowNamePlate() then -- the format functions update reward icons
			self:UnattachNameplateWindow(tNameplate)
		else
			self:SetNormalNameplate(tNameplate)
		end
		if tNameplate.wndNameplate ~= nil then
			tNameplate.wndNameplate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)
		end
	end
end


function BijiPlates:ParseRewards(tNameplate)
	local unitOwner = tNameplate.unitOwner
	if unitOwner == nil then return end

	local tRewardInfo = {}
	tRewardInfo = unitOwner:GetRewardInfo()
	if tRewardInfo == nil or type(tRewardInfo) ~= "table" then
		tNameplate.bIsObjective = false
		return
	end

	local iRewards = 0
	local nRewardCount = #tRewardInfo
	if nRewardCount > 0 then
		for idx = 1, nRewardCount do
			local ePathId = PlayerPathLib.GetPlayerPathType()
			local strType = tRewardInfo[idx].strType
			if strType == "Quest" then
				iRewards = iRewards + 1
			--[[elseif strType == "Challenge" then -- NOTE: Challenges read as true even if you're not on the challenge
				iRewards = iRewards + 1]]
			elseif strType == "Explorer" and ePathId == PlayerPathLib.PlayerPathType_Explorer then
				iRewards = iRewards + 1
			elseif strType == "Scientist" and ePathId == PlayerPathLib.PlayerPathType_Scientist then
				iRewards = iRewards + 1
			elseif strType == "Soldier" and ePathId == PlayerPathLib.PlayerPathType_Soldier then
				iRewards = iRewards + 1
			elseif strType == "Settler" and ePathId == PlayerPathLib.PlayerPathType_Settler then
				iRewards = iRewards + 1
			end
		end
	end

	--now do questgivers, etc

	local tActivation = unitOwner:GetActivationState()
	if tActivation.QuestTarget ~= nil then
		iRewards = iRewards + 1
	end
	if tActivation.QuestReward ~= nil then
		iRewards = iRewards + 1
	end
	if tActivation.QuestNew ~= nil or tActivation.QuestNewMain ~= nil then
		iRewards = iRewards + 1
	end
	if tActivation.QuestReceiving ~= nil then
		iRewards = iRewards + 1
	end
	if tActivation.TalkTo ~= nil then
		iRewards = iRewards + 1
	end

	tNameplate.bIsObjective = iRewards > 0
end




-----------------------------------------------------------------------------------------------
-- Reward Icon Helper Methods
-----------------------------------------------------------------------------------------------

function BijiPlates:HelperDrawRewardTooltip(tRewardInfo, wndRewardIcon, strBracketText, strUnitName, tRewardString)
	-- TODO: Delete this code.
	if not tRewardInfo or not wndRewardIcon then return end
	-- TODO: set icon paths too

	local strMessage = tRewardInfo.strTitle
	if tRewardInfo.pmMission and tRewardInfo.pmMission:GetName() then
		local pmMission = tRewardInfo.pmMission
		if tRewardInfo.bIsActivate and PlayerPathLib.GetPlayerPathType() ~= PlayerPathLib.PlayerPathType_Explorer then -- todo: see if we can remove this requirement
			strMessage = String_GetWeaselString(Apollo.GetString("Nameplates_ActivateForMission"), pmMission:GetName())
		else
			strMessage = string.format("%s %s/%s", pmMission:GetName(), pmMission:GetNumCompleted(), pmMission:GetNumNeeded()) -- TODO Need string weasel (code will be deleted)
		end
	end

	local strProgress = ""
	local strNeeded = tRewardInfo.nNeeded
	local strCompleted = tRewardInfo.nCompleted
	local bShowCount = tRewardInfo.bShowCount
	
	if tRewardInfo.strType == "PublicEvent" and tRewardInfo.peoObjective ~= nil then
		strCompleted = tRewardInfo.peoObjective:ShowPercent()
	end
	
	if strCompleted and strCompleted ~= "" and strNeeded and strNeeded ~= "" then
		if tRewardInfo.bShowCount then
			strProgress = string.format(": %s/%s", strCompleted, strNeeded)
		else
			strProgress = string.format(": %s%%", strCompleted)
		end
	end

	if wndRewardIcon:IsShown() then -- TODO Need string weasel (code will be deleted)
		tRewardString = string.format("%s<P Font=\"CRB_InterfaceMedium\" TextColor=\"ffffffff\">%s: %s%s</P>", tRewardString, strBracketText, strMessage, strProgress)
	else
		tRewardString = string.format("%s<P Font=\"CRB_InterfaceMedium\" TextColor=\"Yellow\">%s (%s)</P><P Font=\"CRB_InterfaceMedium\">%s%s</P>",
										tRewardString, strUnitName, strBracketText, strMessage, strProgress)
		wndRewardIcon:SetTooltip(tRewardString)
	end

	return tRewardString
end

function BijiPlates:HelperLoadRewardIcon(wndRewardPanel, idx)
	if wndRewardPanel:FindChild(idx) then
		return wndRewardPanel:FindChild(idx)
	end

	local wndCurr = Apollo.LoadForm(self.xmlDoc, "RewardIcon", wndRewardPanel, self)
	wndCurr:SetName(idx)
	wndCurr:Show(false) -- Visibility is important

	local tRewardIcons =
	{
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_ActiveQuest",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_Challenge",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_Achievement",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_Reputation",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSol",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSet",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSci",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathExp",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PublicEvent",
		"CRB_TargetFrameRewardPanelSprites:sprTargetFrame_PathSciSpell",
	}

	local strSingle = tRewardIcons[idx] or ""
	wndCurr:FindChild("Single"):SetSprite(strSingle)

	if wndCurr:FindChild("Multi") then -- Note #4 doesn't have this child
		wndCurr:FindChild("Multi"):SetSprite(strSingle.."Multi") -- This is risky. It requires specific sprite naming.
	end

	return wndCurr
end

function BijiPlates:HelperDrawRewardIcon(wndRewardIcon)
	if not wndRewardIcon then
		return 0
	end

	local nResult = 0
	if wndRewardIcon:FindChild("Multi") then -- Show multi if the Single icon if the window is already visible
		wndRewardIcon:FindChild("Multi"):Show(wndRewardIcon:IsShown())
		wndRewardIcon:FindChild("Multi"):ToFront()
	end

	if not wndRewardIcon:IsShown() then -- Plus one to the counter if this is the first instance
		nResult = 1
	end

	wndRewardIcon:Show(true) -- At the very end
	return nResult
end


function BijiPlates:HelperDrawSpellBind(wndIcon, idx)
	if idx ~= 1 then -- paths, not quest
		if self.bPathActionUsesIcon then
			wndIcon:FindChild("TargetMark"):Show(true)
			wndIcon:FindChild("Bind"):SetText("")
		else
			wndIcon:FindChild("TargetMark"):Show(false)
			wndIcon:FindChild("Bind"):SetText(self.strPathActionKeybind)
		end
	else -- quest
		if self.bQuestActionUsesIcon then
			wndIcon:FindChild("TargetMark"):Show(true)
			wndIcon:FindChild("Bind"):SetText("")
		else
			wndIcon:FindChild("TargetMark"):Show(false)
			wndIcon:FindChild("Bind"):SetText(self.strQuestActionKeybind)
		end
	end
end


function BijiPlates:ShowRewardIcons(tNameplate)
	local unitOwner = tNameplate.unitOwner

	if unitOwner == nil then
		return 0
	end

	if tNameplate.wndNameplate == nil then
		return
	end

	local bIsFriend = unitOwner:IsFriend()
	local bIsRival = unitOwner:IsRival()
	local bIsAccountFriend = unitOwner:IsAccountFriend()
	local nFriendshipCount = (bIsFriend and 1 or 0) + (bIsRival and 1 or 0) + (bIsAccountFriend and 1 or 0)

	local tRewardInfo = {}
	tRewardInfo = unitOwner:GetRewardInfo()
	if (tRewardInfo == nil or type(tRewardInfo) ~= "table") and nFriendshipCount == 0 then
		return 0
	end

	local wndRewardPanel = tNameplate.wndNameplate:FindChild("QuestRewards")
	wndRewardPanel:DestroyChildren()
	--wndRewardPanel:SetAnchorOffsets(0, 0, 0, 0)

	local tRewardString = {} -- temp table to store quest descriptions (builds multi-objective tooltips)
	for idx = 1, 9 do
		tRewardString[idx] = ""
	end

	local nRewardInfoListCount = tRewardInfo ~= nil and #tRewardInfo or 0
	if nRewardInfoListCount <= 0 and nFriendshipCount == 0 then
		return 0
	end

	local iRewardCount = 0
	for idx = 1, nRewardInfoListCount do
		local strType = tRewardInfo[idx].strType

		-- TODO Refactor: Replace this with a loop. There's a lot of copy pasted code.
		if strType == "Quest" and self.setIconQuest then
			local wndCurr = self:HelperLoadRewardIcon(wndRewardPanel, 1)
			iRewardCount = iRewardCount + self:HelperDrawRewardIcon(wndCurr)
			tRewardString[1] = self:HelperDrawRewardTooltip(tRewardInfo[idx], wndCurr, Apollo.GetString("CRB_Quest"), unitOwner:GetName(), tRewardString[1])
			wndCurr:SetTooltip(tRewardString[1])
			wndCurr:ToFront()

			if tRewardInfo[idx].splAbility then
				self:HelperDrawSpellBind(wndCurr, 1)
			end
		elseif strType == "Challenge" and self.setIconChallenge then
			local bActiveChallenge = false
			local tAllChallenges = ChallengesLib.GetActiveChallengeList()
			
			for index, clgCurr in pairs(tAllChallenges) do
				if clgCurr ~= nil and tRewardInfo[idx].idChallenge == clgCurr:GetId() and clgCurr:IsActivated() and not clgCurr:IsInCooldown() and not clgCurr:ShouldCollectReward() then
					bActiveChallenge = true
					break
				end
			end

			if bActiveChallenge then
				local wndCurr = self:HelperLoadRewardIcon(wndRewardPanel, 2)
				iRewardCount = iRewardCount + self:HelperDrawRewardIcon(wndCurr)
				tRewardString[2] = self:HelperDrawRewardTooltip(tRewardInfo[idx], wndCurr, Apollo.GetString("CBCrafting_Challenge"), unitOwner:GetName(), tRewardString[2])
				wndCurr:SetTooltip(tRewardString[2])
				wndCurr:ToFront()

				if tRewardInfo[idx].splAbility then
					self:HelperDrawSpellBind(wndCurr, 2)
				end
			end
		elseif strType == "Soldier" and PlayerPathLib.GetPlayerPathType() == PlayerPathLib.PlayerPathType_Soldier and self.setIconMission then
			local wndCurr = self:HelperLoadRewardIcon(wndRewardPanel, 5)
			iRewardCount = iRewardCount + self:HelperDrawRewardIcon(wndCurr)
			tRewardString[5] = self:HelperDrawRewardTooltip(tRewardInfo[idx], wndCurr, Apollo.GetString("Nameplates_Mission"), unitOwner:GetName(), tRewardString[5])
			wndCurr:SetTooltip(tRewardString[5])

			if tRewardInfo[idx].splReward then
				self:HelperDrawSpellBind(wndCurr, 5)
			end
		elseif strType == "Settler" and PlayerPathLib.GetPlayerPathType() == PlayerPathLib.PlayerPathType_Settler and self.setIconMission then
			local wndCurr = self:HelperLoadRewardIcon(wndRewardPanel, 6)
			iRewardCount = iRewardCount + self:HelperDrawRewardIcon(wndCurr)
			tRewardString[6] = self:HelperDrawRewardTooltip(tRewardInfo[idx], wndCurr, Apollo.GetString("Nameplates_Mission"), unitOwner:GetName(), tRewardString[6])
			wndCurr:SetTooltip(tRewardString[6])

			if tRewardInfo[idx].splReward then
				self:HelperDrawSpellBind(wndCurr, 6)
			end
		elseif strType == "Scientist" and PlayerPathLib.GetPlayerPathType() == PlayerPathLib.PlayerPathType_Scientist and self.setIconMission then
			if tRewardInfo[idx].splReward == nil then
				local wndCurr = self:HelperLoadRewardIcon(wndRewardPanel, 7)

				local pmMission = tRewardInfo[idx].pmMission
				local strMission = ""
				if pmMission then
					if pmMission:GetMissionState() >= PathMission.PathMissionState_Unlocked then
						if pmMission:GetType() == PathMission.PathMissionType_Scientist_FieldStudy then
						strMission = string.format("%s %s", pmMission:GetName(), String_GetWeaselString(Apollo.GetString("CRB_ProgressSimple"), pmMission:GetNumCompleted(), pmMission:GetNumNeeded()))
							local tActions = pmMission:GetScientistFieldStudy()
							if tActions then
								for idx, tEntry in ipairs(tActions) do
									if not tEntry.bIsCompleted then
										strMission = string.format("%s ... %s", strMission , tEntry.strName)
									end
								end
							end
						else
							strMission = string.format("%s %s", pmMission:GetName(), String_GetWeaselString(Apollo.GetString("CRB_ProgressSimple"), pmMission:GetNumCompleted(), pmMission:GetNumNeeded()))
						end
					else
						strMission = "???"
					end
				end

				iRewardCount = iRewardCount + self:HelperDrawRewardIcon(wndCurr)

				local strProgress = "" -- specific to #7
				local strUnitName = unitOwner:GetName() -- specific to #7
				local strBracketText = Apollo.GetString("Nameplates_Missions") -- specific to #7
				if wndCurr:IsShown() then -- already have a tooltip
					tRewardString[7] = string.format("%s<P Font=\"CRB_InterfaceMedium\" TextColor=\"ffffffff\">%s%s</P>", tRewardString[7], strMission, strProgress)
				else
					tRewardString[7] = string.format("%s<P Font=\"CRB_InterfaceMedium\" TextColor=\"Yellow\">%s (%s)</P>"..
													 "<P Font=\"CRB_InterfaceMedium\">%s%s</P>", tRewardString[7], strUnitName, strBracketText, strMessage, strProgress)
				end
				-- ALL scientist stuff uses spells so this become redundant
				--[[if rewardInfoList[ix]["spell"] then
					self:HelperDrawSpellBind(wndCurr, 7)
				end--]]

				wndCurr:SetTooltip(tRewardString[7])
			end

			local splSpell = tRewardInfo[idx].splReward
			if splSpell then
				local wndCurr = self:HelperLoadRewardIcon(wndRewardPanel, 10)
				iRewardCount = iRewardCount + self:HelperDrawRewardIcon(wndCurr)
				--Tooltip.GetSpellTooltipForm(self, wndCurr, splSpell)
			end

		elseif strType == "Explorer" and PlayerPathLib.GetPlayerPathType() == PlayerPathLib.PlayerPathType_Explorer and self.setIconMission then
			local wndCurr = self:HelperLoadRewardIcon(wndRewardPanel, 8)
			iRewardCount = iRewardCount + self:HelperDrawRewardIcon(wndCurr)
			tRewardString[8] = self:HelperDrawRewardTooltip(tRewardInfo[idx], wndCurr, "Mission", unitOwner:GetName(), tRewardString[8])
			wndCurr:SetTooltip(tRewardString[8])

			if tRewardInfo[idx].splReward then
				self:HelperDrawSpellBind(wndCurr, 8)
			end
		elseif strType == "PublicEvent" and self.setIconEvent then
			local wndCurr = self:HelperLoadRewardIcon(wndRewardPanel, 9)

			local peEvent = tRewardInfo[idx].peoObjective
			local strTitle = peEvent:GetEvent():GetName()
			local nCompleted = peEvent:GetCount()
			local nNeeded = peEvent:GetRequiredCount()

			iRewardCount = iRewardCount + self:HelperDrawRewardIcon(wndCurr)

			if wndCurr:IsShown() then -- already have a tooltip
				-- Do nothing. It has been cut below
			else
				local strPublicEventMarker = String_GetWeaselString(Apollo.GetString("Nameplates_PublicEvents"), unitOwner:GetName())
				tRewardString[9] = string.format("<P Font=\"CRB_InterfaceMedium\" TextColor=\"Yellow\">%s</P>", strPublicEventMarker)
			end

			if peEvent:GetObjectiveType() == PublicEventObjective.PublicEventObjectiveType_Exterminate then
				strNumRemaining = String_GetWeaselString(Apollo.GetString("Nameplates_NumRemaining"), strTitle, nCompleted)
				tRewardString[9] = string.format("%s<P Font=\"CRB_InterfaceMedium\">%s</P>", tRewardString[9], strNumRemaining)
			elseif peEvent:ShowPercent() then
				strPercentCompleted = String_GetWeaselString(Apollo.GetString("Nameplates_PercentCompleted"), strTitle, nCompleted / nNeeded * 100)
				tRewardString[9] = string.format("%s<P Font=\"CRB_InterfaceMedium\">%s</P>", tRewardString[9], strPercentCompleted)
			else
				tRewardString[9] = string.format("%s<P Font=\"CRB_InterfaceMedium\">%s: %s/%s</P>", tRewardString[9], strTitle, nCompleted, nNeeded)
			end

			wndCurr:ToFront()
			wndCurr:SetTooltip(tRewardString[9])
		end
	end

	if bIsRival and self.setIconRival then
		local wndCurr = Apollo.LoadForm(self.xmlDoc, "RewardIcon", wndRewardPanel, self)
		wndCurr:FindChild("Single"):SetSprite("ClientSprites:Icon_Windows_UI_CRB_Rival")
		wndCurr:SetTooltip("<P Font=\"CRB_InterfaceMedium\" TextColor=\"Yellow\">" .. Apollo.GetString("TargetFrame_Rival") .. "</P>")
		wndCurr:Show(false) -- Visibility is important
		wndCurr:ToFront()

		--if self.bShowRivals then
			iRewardCount = iRewardCount + 1
			wndCurr:Show(true)
		--end
	end
	
	
	local accountFriend = false
	if bIsAccountFriend and self.setIconFriend then
		local wndCurr = Apollo.LoadForm(self.xmlDoc, "RewardIcon", wndRewardPanel, self)
		wndCurr:FindChild("Single"):SetSprite("ClientSprites:Icon_Windows_UI_CRB_Friend")
		wndCurr:SetTooltip("<P Font=\"CRB_InterfaceMedium\" TextColor=\"Yellow\">" .. Apollo.GetString("TargetFrame_AccountFriend") .. "</P>")
		wndCurr:Show(false) -- Visibility is important
		wndCurr:ToFront()
		
		--if self.bShowFriends then
			iRewardCount = iRewardCount + 1
			wndCurr:Show(true)
			accountFriend = true
		--end
	end
	
	if bIsFriend and not accountFriend and self.setIconFriend then
		local wndCurr = Apollo.LoadForm(self.xmlDoc, "RewardIcon", wndRewardPanel, self)
		wndCurr:FindChild("Single"):SetSprite("ClientSprites:Icon_Windows_UI_CRB_Friend")
		wndCurr:SetTooltip("<P Font=\"CRB_InterfaceMedium\" TextColor=\"Yellow\">" .. Apollo.GetString("TargetFrame_Friend") .. "</P>")
		wndCurr:Show(false) -- Visibility is important
		wndCurr:ToFront()
		
		--if self.bShowFriends then
			iRewardCount = iRewardCount + 1
			wndCurr:Show(true)
		--end
	end
	

	if iRewardCount > 0 then
		--wndRewardPanel:SetAnchorOffsets(0, 0, knRewardWidth * iRewardCount, knNameRewardHeight) -- set it (first number is a negative offset)
		wndRewardPanel:ArrangeChildrenHorz(0)
	end

	return iRewardCount
end



--------------------------------------------------------------------------------------
-- Make sure game is loaded. Call when options change.
--------------------------------------------------------------------------------------

function BijiPlates:OptionsChanged()
	--Print("Options Changed")
	local unitPlayer = GameLib.GetPlayerUnit()
	--if unitPlayer == nil or self.settingsLoaded ~= true then
	if unitPlayer == nil then
		Apollo.StartTimer("InitialParseTimer", 1.0, false) -- ensures the player is fully loaded
		return
	end

	self.unitPlayerDisposComparisonTEMP = unitPlayer
	self.bBlinded = unitPlayer:IsInCCState(Unit.CodeEnumCCState.Blind)

	self.bInitialLoadAllClear = true

	for idx, tNameplate in pairs(self.arDisplayedNameplates) do
		local unitOwner = tNameplate.unitOwner
		self:ParseRewards(tNameplate)

		-- reward icons get updated in the formatting functions below
		local bHideMine = unitOwner:IsThePlayer() 
			and not self.setShowMyName
			and not self.setShowMyGuild
			and not self.setShowMyBars
			
		if bHideMine or unitOwner:IsDead() or not unitOwner:ShouldShowNamePlate() then
			self:UnattachNameplateWindow(tNameplate)
		else
			self:SetNormalNameplate(tNameplate)
		end
		if tNameplate.wndNameplate ~= nil then
			tNameplate.wndNameplate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)
		end
	end
	self:OnSecondaryParseTimer()
end

function BijiPlates:OnSecondaryParseTimer() -- keeps everything clean
	if self.bInitialLoadAllClear == false then
		return
	end

	local nCount = 0
	local nWindows = 0
	local nVisible = 0
	for idx, tNameplate in pairs(self.arUnit2Nameplate) do
		nCount = nCount + 1
		local unitOwner = tNameplate.unitOwner
		if tNameplate.wndNameplate ~= nil then
			nWindows = nWindows + 1
			self:ParseRewards(tNameplate)
			if tNameplate.wndNameplate:IsVisible() then
				nVisible = nVisible + 1

				-- reward icons get updated in the formatting functions below
				local bHideMine = unitOwner:IsThePlayer() 
					and not self.setShowMyName
					and not self.setShowMyGuild
					and not self.setShowMyBars
					
				if bHideMine or unitOwner:IsDead() or not unitOwner:ShouldShowNamePlate() then
					self:UnattachNameplateWindow(tNameplate)
				else
					self:SetNormalNameplate(tNameplate)
				end
				if tNameplate.wndNameplate ~= nil then
					tNameplate.wndNameplate:FindChild("TestPlateContainer"):ArrangeChildrenVert(2)
				end
			end
		end
	end
end

-- See if a nameplate should be displayed
function BijiPlates:HelperVerifyVisibilityOptions(tNameplate)
	local unitPlayer = GameLib.GetPlayerUnit()
	local unitOwner = tNameplate.unitOwner
	local eDisposition = unitOwner:GetDispositionTo(unitPlayer)

	local bHiddenUnit = not unitOwner:ShouldShowNamePlate() 
		or unitOwner:GetHealth() == nil
		or unitOwner:GetType() == "Collectible"
		or unitOwner:GetType() == "PinataLoot" 
		or unitOwner:IsDead()
		
	if unitOwner:GetType() == "Pickup" then bHiddenUnit = false end
	
	-- PET PLATES
	if unitOwner:GetType() == "Pet" or unitOwner:GetType() == "Scanner" then 
		if not unitOwner:GetUnitOwner() or unitOwner:GetUnitOwner() == nil then
			if eDisposition == 2 then
				bHiddenUnit = not self.setShowFriendlyPets
			else
				bHiddenUnit = not self.setShowHostilePets
			end
		elseif unitOwner:GetUnitOwner():IsThePlayer() == true then
			bHiddenUnit = not self.setShowMyPets
		else
			if eDisposition == 2 then
				bHiddenUnit = not self.setShowFriendlyPets
			else
				bHiddenUnit = not self.setShowHostilePets
			end
		end
	end
	
	if bHiddenUnit and not tNameplate.bIsTarget then
		tNameplate.bBrandNew = false
		return false
	end
	
	if tNameplate.bGibbed then
		return false
	end
	
	local bShowNameplate = false
	local bWndMain = not tNameplate.bIsTarget and not tNameplate.bIsCluster
	
	if bWndMain then -- onDraw
		if self.bShowMainAlways == false then
			if self.bShowMainObjectiveOnly and tNameplate.bIsObjective then
				bShowNameplate = true
			end

			if self.bShowMainGroupOnly and unitOwner:IsInYourGroup() then
				bShowNameplate = true
			end

			for idx = 1, 3 do
				if self.tShowDispositionOnly[idx] and eDisposition + 1 == idx then -- 0-indexed
					bShowNameplate = true
				end
			end

			if not self.setNeverShow then -- things we always want drawn unless "Never" is on
				local tActivation = unitOwner:GetActivationState()
				if tActivation.Vendor ~= nil or tActivation.FlightPathSettler ~= nil or tActivation.FlightPath ~= nil or tActivation.FlightPathNew then
					bShowNameplate = true
				end

			-- QuestGivers too
				if tActivation.QuestReward ~= nil then
					bShowNameplate = true
				end
				if tActivation.QuestNew ~= nil or tActivation.QuestNewMain ~= nil then
					bShowNameplate = true
				end
				if tActivation.QuestReceiving ~= nil then
					bShowNameplate = true
				end
				if tActivation.TalkTo ~= nil then
					bShowNameplate = true
				end
			end

			if bShowNameplate == true then
				bShowNameplate = not (self.bPlayerInCombat and self.bHideInCombat)
			end
		else
			bShowNameplate = true
		end
	else
		--bShowNameplate = not self.bBlinded
		bShowNameplate = true
	end

	if unitOwner:IsThePlayer() then
		if self.bShowMyNameplate and not unitOwner:IsDead() then
			bShowNameplate = true
		else
			bShowNameplate = true
		end
	end

	tNameplate.bBrandNew = false
	return bShowNameplate
end


function BijiPlates:IsImportantNPC(unitOwner)
	local isImportant = false	
	local tActivation = unitOwner:GetActivationState()
	
	if tActivation.Vendor ~= nil or tActivation.FlightPathSettler ~= nil or tActivation.FlightPath ~= nil or tActivation.FlightPathNew then
		isImportant = true
	end
	
	-- QuestGivers too
	if tActivation.QuestReward ~= nil then
		isImportant = true
	end
	if tActivation.QuestNew ~= nil or tActivation.QuestNewMain ~= nil then
		isImportant = true
	end
	if tActivation.QuestReceiving ~= nil then
		isImportant = true
	end
	if tActivation.TalkTo ~= nil then
		isImportant = true
	end

	return isImportant	
end

-- Check Draw Distance of player, return if in range.
-- TODO: Going to switch things up, maybe just return the range, give 
--       option to display names then display bars at a closer range?
function BijiPlates:CheckDrawDistance(tNameplate)
	local unitPlayer = GameLib.GetPlayerUnit()
	local unitOwner = tNameplate.unitOwner

	if not unitOwner or not unitPlayer or self.setDrawDistance == nil then
	    return false
	end

	tPosTarget = unitOwner:GetPosition()
	tPosPlayer = unitPlayer:GetPosition()

	if tPosTarget == nil then
		return
	end

	local nDeltaX = tPosTarget.x - tPosPlayer.x
	local nDeltaY = tPosTarget.y - tPosPlayer.y
	local nDeltaZ = tPosTarget.z - tPosPlayer.z

	local nDistance = (nDeltaX * nDeltaX) + (nDeltaY * nDeltaY) + (nDeltaZ * nDeltaZ)

	if tNameplate.bIsTarget or tNameplate.bIsCluster then
		bInRange = nDistance < knTargetRange
		return bInRange
	else
		bInRange = nDistance < (self.setDrawDistance * self.setDrawDistance) -- squaring for quick maths
		return bInRange
	end
end



-----------------------------------------------------------------------------------------------
-- HELPER FUNCTIONS
-----------------------------------------------------------------------------------------------

-- Format numbers into shorter readable strings
-- Turns 99999 into 99.9k and 90000 into 90k
function BijiPlates:HelperFormatBigNumber(nArg)
	local strResult
	if nArg >= 1000000 then
		if math.floor(nArg%1000000/100000) == 0 then
			strResult = string.format("%sm", math.floor(nArg / 1000000))
		else
			strResult = string.format("%s.%sm", math.floor(nArg / 1000000), math.floor(nArg % 1000000 / 100000))
		end
	elseif nArg >= 1000 then
		if math.floor(nArg%1000/100) == 0 then
			strResult = string.format("%sk", math.floor(nArg / 1000))
		else
			strResult = string.format("%s.%sk", math.floor(nArg / 1000), math.floor(nArg % 1000 / 100))
		end
	else
		strResult = nArg
	end
	
	return strResult
end

function BijiPlates:HelperFormatTime(nArg)
	local strResult
	if nArg >= 3600 then
		strResult = string.format("%sh", math.floor(nArg / 3600))
	elseif nArg >= 60 then
		strResult = string.format("%sm", math.floor(nArg / 60))
	else
		strResult = string.format("%ss", math.floor(nArg))
	end
	
	return strResult
end


-- Testing this to see if it affects performance.
function BijiPlates:Show(myWindow, myBool)
	myWindow:Show(myBool)
	--[[
	if not myWindow or myWindow == nil then return end
	if myWindow:IsShown() == false and myBool == true then
		myWindow:Show(true)
	elseif myWindow:IsShown() == true and myBool == false then
		myWindow:Show(false)
	end
	]]--
end



-----------------------------------------------------------------------------------------------
-- UI Calls: Settings Page
-----------------------------------------------------------------------------------------------

-- Click on a name
-------------------------------------
function BijiPlates:OnNameClick(wndHandler, wndCtrl, nClick)
	local unitOwner = wndCtrl:GetData()

	if unitOwner ~= nil and GameLib.GetTargetUnit() ~= unitOwner and nClick == 0 then
		GameLib.SetTargetUnit(unitOwner)
		return true
	end
end


-- FORM BUTTONS
-------------------------------------
function BijiPlates:Button_OK()
	self:Show(self.wndMain, false)
end

function BijiPlates:Button_Settings()
	self:Show(self.wndSettingsList , true)
	self:Show(self.wndSettingsColors , false)
	self:Show(self.wndSettingsStyle , false)
	self.wndMain:FindChild("Window_MainSettings"):SetVScrollPos(0)
end

function BijiPlates:Button_Colors()
	self:Show(self.wndSettingsList , false)
	self:Show(self.wndSettingsColors , true)
	self:Show(self.wndSettingsStyle , false)
	
	self.wndMain:FindChild("Window_MainSettings"):SetVScrollPos(0)
end

function BijiPlates:Button_Style()
	self:Show(self.wndSettingsList , false)
	self:Show(self.wndSettingsColors , false)
	self:Show(self.wndSettingsStyle , true)
	
	self.wndMain:FindChild("Window_MainSettings"):SetVScrollPos(0)
end

-- General Settings
-------------------------------------
function BijiPlates:Button_NeverShow(wndHandler, wndCtrl)
	self.setNeverShow = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_EnableOcclusion(wndHandler, wndCtrl)
	self.setEnableOcclusion = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_WotWThrottle(wndHandler, wndCtrl)
	self.setWotWThrottle = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Slider_DrawDistance(wndNameplate, wndHandler, nValue, nOldvalue)
	if math.floor(nValue) == math.floor(nOldvalue) then return end
	self.wndMain:FindChild("Label_DrawDistanceDisplay"):SetText(string.format("%sm",  math.floor(nValue)))
	self.setDrawDistance = math.floor(nValue)
	self:OptionsChanged()
end

function BijiPlates:EditBox_BuffCutoffChanged( wndHandler, wndControl, strText )
	self.setBuffCutoff = tonumber(strText)
	self:OptionsChanged()
end

function BijiPlates:Button_ShowTitles(wndHandler, wndCtrl)
	self.setShowTitles = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowIcons(wndHandler, wndCtrl)
	self.setShowIcons = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Slider_HealthCutoff(wndNameplate, wndHandler, nValue, nOldvalue)
	if math.floor(nValue) == math.floor(nOldvalue) then return end
	self.wndMain:FindChild("Label_HealthCutoffDisplay"):SetText(string.format("%s%%",  math.floor(nValue)))
	self.setHealthCutoff = math.floor(nValue)
	self:OptionsChanged()
end

function BijiPlates:Button_CombatSelf(wndHandler, wndCtrl)
	self.setCombatSelf = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowHealthNumber(wndHandler, wndCtrl)
	self.setShowHealth = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowHealthPercent(wndHandler, wndCtrl)
	self.setShowHealthPercent = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowShieldNumber(wndHandler, wndCtrl)
	self.setShowShield = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowShieldPercent(wndHandler, wndCtrl)
	self.setShowShieldPercent = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowLevelNumber(wndHandler, wndCtrl)
	self.setShowLevel = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowArmorCount(wndHandler, wndCtrl)
	self.setShowArmor = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_IconQuest(wndHandler, wndCtrl)
	self.setIconQuest = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_IconMission(wndHandler, wndCtrl)
	self.setIconMission = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_IconFriend(wndHandler, wndCtrl)
	self.setIconFriend = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_IconEvent(wndHandler, wndCtrl)
	self.setIconEvent = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_IconChallenge(wndHandler, wndCtrl)
	self.setIconChallenge = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_IconRival(wndHandler, wndCtrl)
	self.setIconRival = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowThreatAlert(wndHandler, wndCtrl)
	self.setShowThreatAlert = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_ShowCleanseAlert(wndHandler, wndCtrl)
	self.setShowCleanseAlert = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Button_HideFullFriendlyBars(wndHandler, wndCtrl)
	self.setHideFullFriendlyBars = wndCtrl:IsChecked()
	self:OptionsChanged()
end

function BijiPlates:Slider_PlateScale(wndNameplate, wndHandler, nValue, nOldvalue)
	if math.floor(nValue) == math.floor(nOldvalue) then return end
	self.wndMain:FindChild("Label_PlateScaleDisplay"):SetText(math.floor(nValue) / 100)
	self.setPlateScale = math.floor(nValue)
	self:OptionsChanged()
end


-- PETS
function BijiPlates:Button_setShowMyPets(wndHandler, wndCtrl)
	self.setShowMyPets = wndCtrl:IsChecked();
	self:OptionsChanged();
end
function BijiPlates:Button_setShowFriendlyPets(wndHandler, wndCtrl)
	self.setShowFriendlyPets = wndCtrl:IsChecked();
	self:OptionsChanged();
end
function BijiPlates:Button_setShowHostilePets(wndHandler, wndCtrl)
	self.setShowHostilePets = wndCtrl:IsChecked();
	self:OptionsChanged();
end


-- On Colors Page.
function BijiPlates:Button_ShowClassColors(wndHandler, wndCtrl)
	self.setShowClassColors = wndCtrl:IsChecked();
	self:OptionsChanged();
end


-- My Target Settings
function BijiPlates:Button_setT_M(wndHandler, wndCtrl)		self.setT_M = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setT_N(wndHandler, wndCtrl)		self.setT_N = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setT_G(wndHandler, wndCtrl)		self.setT_G = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setT_B(wndHandler, wndCtrl)		self.setT_B = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setT_C(wndHandler, wndCtrl)		self.setT_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setT_D(wndHandler, wndCtrl)		self.setT_D = wndCtrl:IsChecked(); self:OptionsChanged() end
-- My Nameplate Settings
function BijiPlates:Button_setM_N(wndHandler, wndCtrl)		self.setM_N = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_N_C(wndHandler, wndCtrl)	self.setM_N_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_G(wndHandler, wndCtrl)		self.setM_G = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_G_C(wndHandler, wndCtrl)	self.setM_G_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_B(wndHandler, wndCtrl)		self.setM_B = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_B_C(wndHandler, wndCtrl)	self.setM_B_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_C(wndHandler, wndCtrl)		self.setM_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_C_C(wndHandler, wndCtrl)	self.setM_C_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_D(wndHandler, wndCtrl)		self.setM_D = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_D_C(wndHandler, wndCtrl)	self.setM_D_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_R(wndHandler, wndCtrl)		self.setM_R = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setM_R_C(wndHandler, wndCtrl)	self.setM_R_C = wndCtrl:IsChecked(); self:OptionsChanged() end
-- Neutral Settings
function BijiPlates:Button_setN_N(wndHandler, wndCtrl)		self.setN_N = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_N_C(wndHandler, wndCtrl)	self.setN_N_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_G(wndHandler, wndCtrl)		self.setN_G = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_G_C(wndHandler, wndCtrl)	self.setN_G_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_B(wndHandler, wndCtrl)		self.setN_B = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_B_C(wndHandler, wndCtrl)	self.setN_B_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_C(wndHandler, wndCtrl)		self.setN_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_C_C(wndHandler, wndCtrl)	self.setN_C_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_D(wndHandler, wndCtrl)		self.setN_D = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setN_D_C(wndHandler, wndCtrl)	self.setN_D_C = wndCtrl:IsChecked(); self:OptionsChanged() end
-- Friendly Settings
function BijiPlates:Button_setF_N(wndHandler, wndCtrl)		self.setF_N = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_N_C(wndHandler, wndCtrl)	self.setF_N_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_G(wndHandler, wndCtrl)		self.setF_G = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_G_C(wndHandler, wndCtrl)	self.setF_G_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_B(wndHandler, wndCtrl)		self.setF_B = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_B_C(wndHandler, wndCtrl)	self.setF_B_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_C(wndHandler, wndCtrl)		self.setF_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_C_C(wndHandler, wndCtrl)	self.setF_C_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_D(wndHandler, wndCtrl)		self.setF_D = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_D_C(wndHandler, wndCtrl)	self.setF_D_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setF_Important(wndHandler, wndCtrl)	self.setF_Important = wndCtrl:IsChecked(); self:OptionsChanged() end
	-- Friendly Player Settings
	function BijiPlates:Button_setFP_N(wndHandler, wndCtrl)		self.setFP_N = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_N_C(wndHandler, wndCtrl)	self.setFP_N_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_G(wndHandler, wndCtrl)		self.setFP_G = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_G_C(wndHandler, wndCtrl)	self.setFP_G_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_B(wndHandler, wndCtrl)		self.setFP_B = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_B_C(wndHandler, wndCtrl)	self.setFP_B_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_C(wndHandler, wndCtrl)		self.setFP_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_C_C(wndHandler, wndCtrl)	self.setFP_C_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_D(wndHandler, wndCtrl)		self.setFP_D = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_D_C(wndHandler, wndCtrl)	self.setFP_D_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_CN(wndHandler, wndCtrl)	self.setFP_CN = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setFP_CN_C(wndHandler, wndCtrl)	self.setFP_CN_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	
	-- PARTY Player Settings
	function BijiPlates:Button_setPP_N(wndHandler, wndCtrl)		self.setPP_N = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_N_C(wndHandler, wndCtrl)	self.setPP_N_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_G(wndHandler, wndCtrl)		self.setPP_G = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_G_C(wndHandler, wndCtrl)	self.setPP_G_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_B(wndHandler, wndCtrl)		self.setPP_B = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_B_C(wndHandler, wndCtrl)	self.setPP_B_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_C(wndHandler, wndCtrl)		self.setPP_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_C_C(wndHandler, wndCtrl)	self.setPP_C_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_D(wndHandler, wndCtrl)		self.setPP_D = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_D_C(wndHandler, wndCtrl)	self.setPP_D_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_CN(wndHandler, wndCtrl)	self.setPP_CN = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setPP_CN_C(wndHandler, wndCtrl)	self.setPP_CN_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	
-- Hostile Settings
function BijiPlates:Button_setH_N(wndHandler, wndCtrl)		self.setH_N = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_N_C(wndHandler, wndCtrl)	self.setH_N_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_G(wndHandler, wndCtrl)		self.setH_G = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_G_C(wndHandler, wndCtrl)	self.setH_G_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_B(wndHandler, wndCtrl)		self.setH_B = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_B_C(wndHandler, wndCtrl)	self.setH_B_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_C(wndHandler, wndCtrl)		self.setH_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_C_C(wndHandler, wndCtrl)	self.setH_C_C = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_D(wndHandler, wndCtrl)		self.setH_D = wndCtrl:IsChecked(); self:OptionsChanged() end
function BijiPlates:Button_setH_D_C(wndHandler, wndCtrl)	self.setH_D_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	-- Hostile Player Settings
	function BijiPlates:Button_setHP_N(wndHandler, wndCtrl)		self.setHP_N = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_N_C(wndHandler, wndCtrl)	self.setHP_N_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_G(wndHandler, wndCtrl)		self.setHP_G = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_G_C(wndHandler, wndCtrl)	self.setHP_G_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_B(wndHandler, wndCtrl)		self.setHP_B = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_B_C(wndHandler, wndCtrl)	self.setHP_B_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_C(wndHandler, wndCtrl)		self.setHP_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_C_C(wndHandler, wndCtrl)	self.setHP_C_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_D(wndHandler, wndCtrl)		self.setHP_D = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_D_C(wndHandler, wndCtrl)	self.setHP_D_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_CN(wndHandler, wndCtrl)	self.setHP_CN = wndCtrl:IsChecked(); self:OptionsChanged() end
	function BijiPlates:Button_setHP_CN_C(wndHandler, wndCtrl)	self.setHP_CN_C = wndCtrl:IsChecked(); self:OptionsChanged() end
	
-- COLORS
-------------------------------------
function BijiPlates:Button_DefaultColors(wndHandler, wndCtrl)
	self:DefaultColors()	
	self:RefreshSettings()
	self:OptionsChanged()
end

-- General Color Settings
function BijiPlates:Edit_BackgroundBar()
	local colorString = self.wndMain:FindChild("Edit_BackgroundBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_BackgroundBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_BackgroundBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorBackgroundBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_BackdropBar()
	local colorString = self.wndMain:FindChild("Edit_BackdropBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_BackdropBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_BackdropBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorBackdropBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_ShieldBar()
	local colorString = self.wndMain:FindChild("Edit_ShieldBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_ShieldBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_ShieldBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorShieldBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_AbsorbBar()
	local colorString = self.wndMain:FindChild("Edit_AbsorbBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_AbsorbBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_AbsorbBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorAbsorbBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_VulnerableBar()
	local colorString = self.wndMain:FindChild("Edit_VulnerableBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_VulnerableBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_VulnerableBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorVulnerableBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_VulnerableTimerBar()
	local colorString = self.wndMain:FindChild("Edit_VulnerableTimerBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_VulnerableTimerBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_VulnerableTimerBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorVulnerableTimerBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_CastBar()
	local colorString = self.wndMain:FindChild("Edit_CastBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_CastBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_CastBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorCastBar = colorString; self:OptionsChanged()
end

-- Neutral Settings
function BijiPlates:Edit_NeutralName()
	local colorString = self.wndMain:FindChild("Edit_NeutralName"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_NeutralName"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_NeutralName"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorNeutralName = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_NeutralBar()
	local colorString = self.wndMain:FindChild("Edit_NeutralBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_NeutralBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_NeutralBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorNeutralBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_NeutralBarCutoff()
	local colorString = self.wndMain:FindChild("Edit_NeutralBarCutoff"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_NeutralBarCutoff"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_NeutralBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorNeutralBarCutoff = colorString; self:OptionsChanged()
end

-- Friendly Settings
function BijiPlates:Edit_FriendlyName()
	local colorString = self.wndMain:FindChild("Edit_FriendlyName"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_FriendlyName"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_FriendlyName"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorFriendlyName = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_FriendlyBar()
	local colorString = self.wndMain:FindChild("Edit_FriendlyBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_FriendlyBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_FriendlyBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorFriendlyBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_FriendlyBarCutoff()
	local colorString = self.wndMain:FindChild("Edit_FriendlyBarCutoff"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_FriendlyBarCutoff"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_FriendlyBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorFriendlyBarCutoff = colorString; self:OptionsChanged()
end

-- Friendly Player Settings
function BijiPlates:Edit_FriendlyPlayerName()
	local colorString = self.wndMain:FindChild("Edit_FriendlyPlayerName"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_FriendlyPlayerName"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_FriendlyPlayerName"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorFriendlyPlayerName = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_FriendlyPlayerNameUnflagged()
	local colorString = self.wndMain:FindChild("Edit_FriendlyPlayerNameUnflagged"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_FriendlyPlayerNameUnflagged"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_FriendlyPlayerNameUnflagged"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorFriendlyPlayerNameUnflagged = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_FriendlyPlayerBar()
	local colorString = self.wndMain:FindChild("Edit_FriendlyPlayerBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_FriendlyPlayerBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_FriendlyPlayerBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorFriendlyPlayerBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_FriendlyPlayerBarCutoff()
	local colorString = self.wndMain:FindChild("Edit_FriendlyPlayerBarCutoff"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_FriendlyPlayerBarCutoff"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_FriendlyPlayerBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorFriendlyPlayerBarCutoff = colorString; self:OptionsChanged()
end

-- Hostile Settings
function BijiPlates:Edit_HostileName()
	local colorString = self.wndMain:FindChild("Edit_HostileName"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_HostileName"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_HostileName"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorHostileName = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_HostileBar()
	local colorString = self.wndMain:FindChild("Edit_HostileBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_HostileBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_HostileBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorHostileBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_HostileBarCutoff()
	local colorString = self.wndMain:FindChild("Edit_HostileBarCutoff"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_HostileBarCutoff"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_HostileBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorHostileBarCutoff = colorString; self:OptionsChanged()
end

-- Hostile Player Settings
function BijiPlates:Edit_HostilePlayerName()
	local colorString = self.wndMain:FindChild("Edit_HostilePlayerName"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_HostilePlayerName"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_HostilePlayerName"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorHostilePlayerName = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_HostilePlayerNameUnflagged()
	local colorString = self.wndMain:FindChild("Edit_HostilePlayerNameUnflagged"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_HostilePlayerNameUnflagged"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_HostilePlayerNameUnflagged"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorHostilePlayerNameUnflagged = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_HostilePlayerBar()
	local colorString = self.wndMain:FindChild("Edit_HostilePlayerBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_HostilePlayerBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_HostilePlayerBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorHostilePlayerBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_HostilePlayerBarCutoff()
	local colorString = self.wndMain:FindChild("Edit_HostilePlayerBarCutoff"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_HostilePlayerBarCutoff"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_HostilePlayerBarCutoff"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorHostilePlayerBarCutoff = colorString; self:OptionsChanged()
end


function BijiPlates:Edit_PartyName()
	local colorString = self.wndMain:FindChild("Edit_PartyName"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_PartyName"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_PartyName"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorPartyName = colorString; self:OptionsChanged()
end

-- CLASS COLORS

function BijiPlates:Edit_WarriorBar()
	local colorString = self.wndMain:FindChild("Edit_WarriorBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_WarriorBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_WarriorBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorWarriorBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_StalkerBar()
	local colorString = self.wndMain:FindChild("Edit_StalkerBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_StalkerBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_StalkerBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorStalkerBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_EngineerBar()
	local colorString = self.wndMain:FindChild("Edit_EngineerBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_EngineerBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_EngineerBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorEngineerBar = colorString; self:OptionsChanged()
end

function BijiPlates:Edit_EsperBar()
	local colorString = self.wndMain:FindChild("Edit_EsperBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_EsperBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_EsperBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorEsperBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_SpellslingerBar()
	local colorString = self.wndMain:FindChild("Edit_SpellslingerBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_SpellslingerBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_SpellslingerBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorSpellslingerBar = colorString; self:OptionsChanged()
end
function BijiPlates:Edit_MedicBar()
	local colorString = self.wndMain:FindChild("Edit_MedicBar"):GetText()
	if string.len(colorString) > 6 then self.wndMain:FindChild("Edit_MedicBar"):SetText(string.sub(colorString, 0, 6)) end	
	self.wndMain:FindChild("Label_MedicBar"):SetTextColor(ApolloColor.new(self.setOpacity..colorString))
	self.setColorMedicBar = colorString; self:OptionsChanged()
end


-- STYLE | sao, flat
-------------------------------------
function BijiPlates:Button_StyleSAO( wndHandler, wndControl, eMouseButton )
	self.setStyle = "sao";
	self:OptionsChanged();
end

	function BijiPlates:Slider_SAOSize(wndNameplate, wndHandler, nValue, nOldvalue)
		if math.floor(nValue) == math.floor(nOldvalue) then return end
		self.wndMain:FindChild("Label_SAOSizeDisplay"):SetText(string.format("%s",  math.floor(nValue)))
		self.setSAOSize = math.floor(nValue)
		self:OptionsChanged()
	end

function BijiPlates:Button_StyleFlat( wndHandler, wndControl, eMouseButton )
	self.setStyle = "flat";
	self:OptionsChanged();
end

	function BijiPlates:Slider_FlatWidth(wndNameplate, wndHandler, nValue, nOldvalue)
		if math.floor(nValue) == math.floor(nOldvalue) then return end
		self.wndMain:FindChild("Label_FlatWidthDisplay"):SetText(string.format("%s",  math.floor(nValue)))
		self.setFlatWidth = math.floor(nValue)
		self:OptionsChanged()
	end
	
	function BijiPlates:Slider_FlatShieldHeight(wndNameplate, wndHandler, nValue, nOldvalue)
		if math.floor(nValue) == math.floor(nOldvalue) then return end
		self.wndMain:FindChild("Label_FlatShieldHeightDisplay"):SetText(string.format("%s",  math.floor(nValue)))
		self.setFlatShieldHeight = math.floor(nValue)
		self:OptionsChanged()
	end
	
	function BijiPlates:Slider_FlatHealthHeight(wndNameplate, wndHandler, nValue, nOldvalue)
		if math.floor(nValue) == math.floor(nOldvalue) then return end
		self.wndMain:FindChild("Label_FlatHealthHeightDisplay"):SetText(string.format("%s",  math.floor(nValue)))
		self.setFlatHealthHeight = math.floor(nValue)
		self:OptionsChanged()
	end
	
	function BijiPlates:Slider_FlatShieldTexture(wndNameplate, wndHandler, nValue, nOldvalue)
		if math.floor(nValue) == math.floor(nOldvalue) then return end
		self.wndMain:FindChild("Label_FlatShieldTextureDisplay"):SetText(string.format("%s",  math.floor(nValue)))
		self.setFlatShieldTexture = math.floor(nValue)
		self:OptionsChanged()
	end
	
	function BijiPlates:Slider_FlatHealthTexture(wndNameplate, wndHandler, nValue, nOldvalue)
		if math.floor(nValue) == math.floor(nOldvalue) then return end
		self.wndMain:FindChild("Label_FlatHealthTextureDisplay"):SetText(string.format("%s",  math.floor(nValue)))
		self.setFlatHealthTexture = math.floor(nValue)
		self:OptionsChanged()
	end



-- Unit Name Font Type (Shadow / Outline)
function BijiPlates:Button_setUnitNameTypeShadow( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFontType = ""; self:OptionsChanged(); end
function BijiPlates:Button_setUnitNameTypeOutline( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFontType = "_O"; self:OptionsChanged(); end

--Unit Name Font Style/Size
function BijiPlates:Button_setUnitNameFontChoad( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFont = "CRB_Pixel"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitNameFontInterface9( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFont = "CRB_Interface9"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitNameFontInterface10( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFont = "CRB_Interface10"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitNameFontInterface11( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFont = "CRB_Interface11"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitNameFontInterface12( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFont = "CRB_Interface12"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitNameFontInterface14( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFont = "CRB_Interface14"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitNameFontNameplates( wndHandler, wndControl, eMouseButton )
	self.setUnitNameFont = "Nameplates"; self:OptionsChanged(); end

-- Unit Guild Font Type (Shadow / Outline)
function BijiPlates:Button_setUnitGuildTypeShadow( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFontType = ""; self:OptionsChanged(); end
function BijiPlates:Button_setUnitGuildTypeOutline( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFontType = "_O"; self:OptionsChanged(); end

--Unit Guild Font Style/Size
function BijiPlates:Button_setUnitGuildFontChoad( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFont = "CRB_Pixel"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitGuildFontInterface9( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFont = "CRB_Interface9"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitGuildFontInterface10( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFont = "CRB_Interface10"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitGuildFontInterface11( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFont = "CRB_Interface11"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitGuildFontInterface12( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFont = "CRB_Interface12"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitGuildFontInterface14( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFont = "CRB_Interface14"; self:OptionsChanged(); end
function BijiPlates:Button_setUnitGuildFontNameplates( wndHandler, wndControl, eMouseButton )
	self.setUnitGuildFont = "Nameplates"; self:OptionsChanged(); end
	
-----------------------------------------------------------------------------------------------
-- BijiPlates Instance
-----------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-- SettingsStyle Functions
---------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
-- SettingsList Functions
---------------------------------------------------------------------------------------------------

local BijiPlatesInst = BijiPlates:new()
BijiPlatesInst:Init()

