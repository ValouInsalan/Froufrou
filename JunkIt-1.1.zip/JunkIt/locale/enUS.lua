--Localization.enUS.lua
local L = Apollo.GetPackage("Gemini:Locale-1.0").tPackage:NewLocale("JunkIt", "enUS", true)
if not L then return end

L["JunkIt Options"] = true
L["Automatic Settings"] = true
L["Filter Settings"] = true
L["Keep Salvagables"] = true
L["Item Types to Sell"] = true
L["Quality Threshold"] = true
L["Button"] = true