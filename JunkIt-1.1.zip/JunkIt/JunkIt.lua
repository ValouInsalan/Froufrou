require "Window"
require "string"
require "math"
require "Sound"
require "Item"
require "Money"
require "GameLib"

-- Sorted Pairs function, pass in the sort function
local function spairs(t, order)
	-- Collect keys
	local keys = {}
	for k in pairs(t) do keys[#keys + 1] = k end

	-- If order function given, sort by passing the table and keys a, b,
	-- otherwise just sort keys
	if order then
		table.sort(keys, function(a,b) return order(t, a, b) end)
	else
		table.sort(keys)
	end
	
	-- Return the iterator function
	local i = 0
	return function()
		i = i + 1
		if keys[i] then
			return keys[i], t[keys[i]]
		end
	end
end


local function TableMerge(t1, t2)
  for k,v in pairs(t2) do
    if type(v) == "table" then
      if type(t1[k] or false) == "table" then
        TableMerge(t1[k] or {}, t2[k] or {})
      else
        t1[k] = v
      end
    else
      t1[k] = v
    end
  end
  return t1
end

local JunkIt = {}
local GeminiLocale, L

-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
-- Considered using ItemFamilyName and ItemCategoryName but unsure if localization would affect

local ItemFamily = {
	Armor = 1,
	Weapon = 2,
	Bag = 5,
	Ornamental = 15, -- Shield
	Consumable = 16,
	Reagent = 18, -- Crafting Reagents
	Housing = 20, -- Housing according to inventory
	--Housing = 22, -- What
	QuestItem = 24,
	Costume = 26,
	Crafting = 27,
}

local ItemCategory = {
	Junk = 94,
}
local ktReverseQualityLookup = {}

function JunkIt:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self

	o.config = {}
	o.config.sellArmor = true
	o.config.sellWeapons = true
	o.config.sellCostumes = true
	o.config.sellShields = true
	o.config.keepSalvage = false
	o.config.autoSell = false
	o.config.sellHousing = false
	o.config.autoRepair = false
	o.config.showButton = true

	o.config.minSellQuality = Item.CodeEnumItemQuality.Average
	
	return o
end

function JunkIt:Init()
	Apollo.RegisterAddon(self, false, "", {"Vendor","Gemini:Locale-1.0"})
end

---------------------------------------------------------------------------------------------------
-- JunkIt Load Functions
---------------------------------------------------------------------------------------------------
function JunkIt:OnLoad()
	-- Read in the file only once, presumably file IO is more costly
	self.Xml = XmlDoc.CreateFromFile("JunkIt.xml")
	self.Xml:RegisterCallback("OnDocLoaded", self)
	GeminiLocale = Apollo.GetPackage("Gemini:Locale-1.0").tPackage
	L = GeminiLocale:GetLocale("JunkIt", false)
end

function JunkIt:OnDocLoaded()
	-- Store reference to the Vendor addon
	self.vendorAddon = Apollo.GetAddon("Vendor")

	-- Event thrown by opening the a Vendor window
	Apollo.RegisterEventHandler("InvokeVendorWindow",	"OnInvokeVendorWindow", self)
	-- Event thrown by closing the a Vendor window
	Apollo.RegisterEventHandler("CloseVendorWindow",	"OnVendorClosed", self)

	-- Boolean to indicate options need configured
	self.bConfigOptions = true
	
	-- Init ReverseLookup
	for k,v in pairs(Item.CodeEnumItemQuality) do
		ktReverseQualityLookup[v] = k
	end
end

function JunkIt:OnDependencyError(strDep, strError)
    return false
end

---------------------------------------------------------------------------------------------------
-- JunkIt EventHandlers
---------------------------------------------------------------------------------------------------


-- Sets the selected options on the Options Frame, this is delayed to ensure both new users
--	and people who have used the addon before see options as configured in the options pane.
--	uses bool to indicate has already been done.
function JunkIt:SetupJunkIt()
	-- Load forms, parent to vendor addon
	self.wndJunkOpts = Apollo.LoadForm(self.Xml, "OptionsContainer", self.vendorAddon.wndVendor:FindChild("BGFrame"), self)
	GeminiLocale:TranslateWindow(L, self.wndJunkOpts)
	self.wndOpt = Apollo.LoadForm(self.Xml, "VendorWindowOverlay", self.vendorAddon.wndVendor:FindChild("BGFrame"), self)
	self.wndJunkButton = Apollo.LoadForm(self.Xml, "JunkButtonOverlay", self.vendorAddon.wndVendor, self)

	-- Show the Options button all the time
	self.wndOpt:Show(true)
	
	-- Hide the Options Frame by default
	self.wndJunkOpts:Show(false, true)

	-- Iterate through config options
	for k,v in pairs(self.config) do
		-- Boolean options are the checkboxes, so set the check appropriately
		if (type(v) == "boolean") then
			if self.wndJunkOpts:FindChild(k) ~= nil then
				self.wndJunkOpts:FindChild(k):SetCheck(v)
			end
		else -- Item Quality Type, set the ComboBox selected and the right color
			self.wndJunkOpts:FindChild("QualityDropDown"):SetText(Apollo.GetString("CRB_" .. ktReverseQualityLookup[v]))
			self.wndJunkOpts:FindChild("QualityDropDown"):SetNormalTextColor("ItemQuality_" .. ktReverseQualityLookup[v])
		end
	end
	-- Show/Hide Sell button based on autosell config
	self:SetButtonState()
	-- Set boolean to indicate options have been set
	self.bConfigOptions = false
end

-- Event Handler for Vendor Window closing
function JunkIt:OnVendorClosed()
	-- If the button is not set unchecked it appears checked next time window is opened
	self.wndOpt:FindChild("OptionsBtn"):SetCheck(false)
	-- Hide Options window when vendor is closed, prevents options from being open next time vendor is opened
	self.wndJunkOpts:Show(false)
	-- If we are showing a submenu get rid of it
	if self.wndSubMenu then
		local wndPopout = self.wndSubMenu:GetData():GetParent():FindChild("QualityPopoutBtn")
		if wndPopout ~= nil then
			wndPopout:SetCheck(false)
		end
		self.wndSubMenu:Destroy()
	end
end

-- Event handler for Vendor window opening.
function JunkIt:OnInvokeVendorWindow(unitArg)
	-- Check and see if options pane needs to be synced, if so sync it
	if self.bConfigOptions then
		self:SetupJunkIt()
	end

	local nItemsSold = nil
	if self.config.autoSell then
		nItemsSold = self:SellItems(true)
	end

	local nItemsRepaired = nil
	if self.config.autoRepair and IsRepairVendor(unitArg) then
		nItemsRepaired = self:RepairItems(unitArg)
	end

	-- Didn't do anything interesting, exit out.
	if not nItemsSold and not nItemsRepaired then return end

	local strAlertMsg = "JunkIt"

	if nItemsSold then
		strAlertMsg = string.format("%s: Sold %d Items", strAlertMsg, nItemsSold)
	end

	if nItemsRepaired then
		strAlertMsg = string.format("%s: Repaired %d Items", strAlertMsg, nItemsRepaired)
	end
	self.vendorAddon:ShowAlertMessageContainer(strAlertMsg, false)
end

----------------------------------------------------------------------------------------------- 
-- Selling Functions
-----------------------------------------------------------------------------------------------
function JunkIt:SellItems(bAuto)
	local tItemsToSell, itemCount = self:GetSellItems()
	if tItemsToSell ~= nil and itemCount > 0 then
		for _, v in ipairs(tItemsToSell) do 
			SellItemToVendorById(v:GetInventoryId(), v:GetStackCount())
		end

		if not bAuto then
			self.vendorAddon:ShowAlertMessageContainer("JunkIt: Sold " .. itemCount .. " items", false)
		else
			return itemCount
		end
	end
end

function JunkIt:GetSellItems()
	local invItems = GameLib.GetPlayerUnit():GetInventoryItems()
	local sellItems = {}
	local itemCount = 0
	for _, v in ipairs(invItems) do
		if self:IsSellable(v.itemInBag) then
			table.insert(sellItems, v.itemInBag)
			itemCount = itemCount + 1
		end
	end
	
	return sellItems, itemCount
end

function JunkIt:IsSellable(item)
	-- You can't sell items that don't exist or have no price
	if not item or not item:GetSellPrice() then return false end

	-- Determine if the item is junk, if it is, vend it!
	if item:GetItemCategory() == ItemCategory.Junk then return true end

	-- If item quality is set to inferior, keep all items
	if self.config.minSellQuality == Item.CodeEnumItemQuality.Inferior then return false end

	-- If we are keeping salvagable items and this one is salvageable, then this isn't for sale
	if self.config.keepSalvage and item:CanSalvage() then return false end

	-- Pull the itemFamily to reduce # of function calls
	local itemFamily = item:GetItemFamily()
	
	--  Are we selling this type of item?
	if ((itemFamily == ItemFamily.Armor and self.config.sellArmor) or 
		(itemFamily == ItemFamily.Weapon and self.config.sellWeapons) or 
		(itemFamily == ItemFamily.Ornamental and self.config.sellShields) or
		(itemFamily == ItemFamily.Housing and self.config.sellHousing) or		
		(itemFamily == ItemFamily.Costume and self.config.sellCostumes)) then
		
		-- Is it under our threshold?
		if item:GetItemQuality() == Item.CodeEnumItemQuality.Inferior or self.config.minSellQuality > item:GetItemQuality() then return true end
	end

	-- Default is no, it is not sellable
	return false
end

---------------------------------------------------------------------------------------------------
-- Save/Restore Settings Functions
---------------------------------------------------------------------------------------------------
function JunkIt:OnSave(eLevel)
	if eLevel ~= GameLib.CodeEnumAddonSaveLevel.Character then return nil end
	return self.config
end

function JunkIt:OnRestore(eLevel, tData)
	TableMerge(self.config, tData)
end

-----------------------------------------------------------------------------------------------
-- Repair Functions
-----------------------------------------------------------------------------------------------
function JunkIt:RepairItems(unitArg)
	local nRepairedItems = self:CanRepair(unitArg)
	if not nRepairedItems then return nil end
	-- Perform Repair
	RepairAllItemsVendor()
	-- Reset Repair Tab information
	self.vendorAddon:RefreshRepairTab()
	-- return the number of items repaired
	return nRepairedItems
end

function JunkIt:CanRepair(unitArg)
	local repairableItems = unitArg:GetRepairableItems()
	local nCount = 0
	if repairableItems ~= nil then
		nCount = #repairableItems
	end
	if nCount == 0 then
		return false
	end
	return nCount
end

---------------------------------------------------------------------------------------------------
-- VendorWindow Functions
---------------------------------------------------------------------------------------------------

-- Handle the Options button, both show and hide
function JunkIt:OnOptionsMenuToggle( wndHandler, wndControl, eMouseButton )
	self.wndJunkOpts:FindChild("OptionsContainer"):Show(self.wndOpt:FindChild("OptionsBtn"):IsChecked())
end

---------------------------------------------------------------------------------------------------
-- VendorWindowOverlay Functions
---------------------------------------------------------------------------------------------------

-- Handler for Options Close button
function JunkIt:OnOptionsCloseClick( wndHandler, wndControl, eMouseButton )
	self.wndOpt:FindChild("OptionsBtn"):SetCheck(false)
	self:OnOptionsMenuToggle()
end

-- Handler for Junk Button
function JunkIt:OnJunkButtonClick( wndHandler, wndControl, eMouseButton )
	self:SellItems()
end

---------------------------------------------------------------------------------------------------
-- OptionsContainer Functions
---------------------------------------------------------------------------------------------------

function JunkIt:SetButtonState()
	local showButton
	if self.config.autoSell then
		showButton = self.config.showButton
	else
		showButton = true
	end

	self.wndJunkButton:Show(showButton)
	self.wndJunkOpts:FindChild("showButton"):Show(self.config.autoSell)
end

-- Handler for all of the checkboxes in the Options window
function JunkIt:OnCheckboxChange( wndHandler, wndControl, eMouseButton )
	local wndControlName = wndControl:GetName()
	self.config[wndControlName] = wndControl:IsChecked()
	-- Special cases, aren't they special?
	-- If we turn on AutoSell, or change the showButton setting, honor it.
	if wndControlName == "autoSell" then
		wndControl:FindChild("showButton"):Show(self.config.autoSell)
		self:SetButtonState()
	elseif wndControlName == "showButton" then
		self:SetButtonState()
	end
end

function JunkIt:OnQualityPopoutToggle( wndHandler, wndControl, eMouseButton )
	if self.wndSubMenu and self.wndSubMenu:GetParent() == wndControl then
		if not wndControl:IsChecked() and self.wndSubMenu then
			self.wndSubMenu:Destroy()
		end
		return
	end
	if self.wndSubMenu then
		self.wndSubMenu:GetData():GetParent():FindChild("QualityPopoutBtn"):SetCheck(false)
		self.wndSubMenu:Destroy()
	end
	self.wndSubMenu = Apollo.LoadForm(self.Xml, "QualityMenu", wndControl, self)
	local strBtnName = "sell" .. string.match(self.wndSubMenu:GetData():GetName(),"(.-)Container")
	self.wndSubMenu:SetData(wndControl:GetParent():FindChild(strBtnName))
end

function JunkIt:OnQualityDropdownToggle( wndHandler, wndControl, eMouseButton )
	if self.wndSubMenu then
		local wndPopout = self.wndSubMenu:GetData():GetParent():FindChild("QualityPopoutBtn")
		if wndPopout ~= nil then
			wndPopout:SetCheck(false)
		end
		self.wndSubMenu:Destroy()
		if not wndControl:IsChecked() then
			return
		end
	end
	self.wndSubMenu = Apollo.LoadForm(self.Xml, "QualityMenu", wndControl, self)
	self.wndSubMenu:SetData(wndControl)
	self.wndSubMenu:SetAnchorPoints(0,1,1,0)
	self.wndSubMenu:SetAnchorOffsets(-21, -26, 21, 246)
end

---------------------------------------------------------------------------------------------------
-- QualityMenu Functions
---------------------------------------------------------------------------------------------------

function JunkIt:OnQualityBtnClicked( wndHandler, wndControl, eMouseButton )
	self.wndSubMenu:GetData():SetText(wndControl:FindChild("QualityBtnTxt"):GetText())
	self.wndSubMenu:GetData():SetNormalTextColor("ItemQuality_"..wndControl:GetName())
	local wndPopout = self.wndSubMenu:GetData():GetParent():FindChild("QualityPopoutBtn")
	if wndPopout ~= nil then
		wndPopout:SetCheck(false)
	else
		self.wndSubMenu:GetData():SetCheck(false)
	end

	local strWndName = wndControl:GetName()
	for k,v in pairs(ktReverseQualityLookup) do
		if v == strWndName then
			self.config.minSellQuality = k
			break
		end
	end

	self.wndSubMenu:Destroy()
	if self.config.autoSell then
		self:SellItems()
	end
end

---------------------------------------------------------------------------------------------------
-- JunkIt instance
---------------------------------------------------------------------------------------------------
local JunkItInst = JunkIt:new()
JunkItInst:Init()