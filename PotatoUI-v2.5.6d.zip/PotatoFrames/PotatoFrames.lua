-----------------------------------------------------------------------------------------------
-- Client Lua Script for PotatoFrames
-- Copyright (c) Tyler T. Hardy. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
 
-----------------------------------------------------------------------------------------------
-- PotatoFrames Module Definition
-----------------------------------------------------------------------------------------------
local PotatoFrames = {} 
 
-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
-- e.g. local kiExampleVariableMax = 999

local editorMode = false
--local showPortrait = true
--local showIcons = true
local bHovering = false
local daCColor =  CColor.new(0, 0, 1, 1)

-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function PotatoFrames:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function PotatoFrames:Init()
    local bHasConfigureFunction = false
    local strConfigureButtonText = ""
    local tDependencies = {  "PotatoLib" }
    Apollo.RegisterAddon(self, bHasConfigureFunction, strConfigureButtonText, tDependencies)
end

local ActionBarFrame = Apollo.GetAddon("ActionBarFrame")

if ActionBarFrame then
	function ActionBarFrame:RedrawStances()
		if self.unitPlayer == nil then
			return
		end
	
		local wndStancePopout = self.wndStancePopoutFrame:FindChild("StancePopoutList")
		wndStancePopout:DestroyChildren()
		
		local nCountSkippingTwo = 0
		for idx, spellObject in pairs(GameLib.GetClassInnateAbilitySpells().tSpells) do
			if idx % 2 == 1 then
				nCountSkippingTwo = nCountSkippingTwo + 1
				local strKeyBinding = GameLib.GetKeyBinding("SetStance"..nCountSkippingTwo) -- hardcoded formatting
				local wndCurr = Apollo.LoadForm(self.xmlDoc, "StanceBtn", wndStancePopout, self)
				wndCurr:FindChild("StanceBtnKeyBind"):SetText(strKeyBinding == "<Unbound>" and "" or strKeyBinding)
				wndCurr:FindChild("StanceBtnIcon"):SetSprite(spellObject:GetIcon())
				wndCurr:SetData(nCountSkippingTwo)
	
				if Tooltip and Tooltip.GetSpellTooltipForm then
					wndCurr:SetTooltipDoc(nil)
					Tooltip.GetSpellTooltipForm(self, wndCurr, spellObject)
				end
			end
		end
		
		--local nHeight = wndStancePopout:ArrangeChildrenVert(0)
		local nWidth = wndStancePopout:ArrangeChildrenHorz(0)
		local nLeft, nTop, nRight, nBottom = self.wndStancePopoutFrame:GetAnchorOffsets()
		self.wndStancePopoutFrame:SetStyle("IgnoreMouse",false)
		self.wndStancePopoutFrame:SetStyle("NewWindowDepth",true)
		self.wndStancePopoutFrame:ToFront()
		
		--self.wndStancePopoutFrame:SetAnchorOffsets(nLeft, nBottom - nHeight - 98, nRight, nBottom)
		self.wndStancePopoutFrame:SetAnchorOffsets(nRight-nWidth-98, -31, nRight, 121)
		self.wndMain:FindChild("StancePopoutBtn"):Show(#wndStancePopout:GetChildren() > 0)
	end
end

local kstrRaidMarkerToSprite =
{
	"Bomb",
	"Ghost",
	"Mask",	
	"Octopus",
	"Pig",
	"Chicken",
	"Toaster",
	"UFO",
}

local ktDefaultFrames =
{
	{ name = "Player Frame", anchors = {0.5, 1, 0.5, 1}, offsets = {-370, -202,  -10, -128}, portraitType = 1, showIcons = true},
	{ name = "Target Frame", anchors = {0.5, 1, 0.5, 1}, offsets = {  10, -202,  370, -128}, portraitType = 1, showIcons = true},
	{ name = "ToT Frame", anchors = {0.5, 1, 0.5, 1}, offsets =    { 270, -300,  500, -240}, portraitType = 1, showIcons = true},
	{ name = "Focus Frame", anchors = {0.5, 0, 0.5, 0}, offsets =  {-100,  90,  100,  150}, portraitType = 1, showIcons = true},
	{ name = "Pet Frame 1", anchors = {0.5, 1, 0.5, 1}, offsets =  {-320, -300, -190, -250}, portraitType = 3, showIcons = false},
	{ name = "Pet Frame 2", anchors = {0.5, 1, 0.5, 1}, offsets =  {-190, -300, -60, -250}, portraitType = 3, showIcons = false},
}

local ktDefaultCastbars =
{
	{ name = "Player Castbar", anchors = {0.5, 1, 0.5, 1}, offsets = {-370, -128,  -10, -108}},
	{ name = "Target Castbar", anchors = {0.5, 1, 0.5, 1}, offsets = {  10, -128,  370, -108}},
	{ name = "ToT Castbar", anchors = {0.5, 1, 0.5, 1}, offsets =    { 270, -240,  500, -225}},
	{ name = "Focus Castbar", anchors = {0.5, 0, 0.5, 0}, offsets =  {-100,  150,  100,  160}},
	{ name = "Pet 1 Castbar", anchors = {0.5, 1, 0.5, 1}, offsets =  {-300, -150, -200, -100}},
	{ name = "Pet 2 Castbar", anchors = {0.5, 1, 0.5, 1}, offsets =  {-300, -150, -200, -100}},
}

local ktDefaultIcons = {
	{npcType="level", playerType="level"},
	{npcType="faction", playerType="faction"},
	{npcType="class", playerType="class"},
	{npcType="difficulty", playerType="path"}
}

local ktDifficultySprites = {
	[Unit.CodeEnumRank.Elite] = "Elite",
	[Unit.CodeEnumRank.Superior] = "Superior",
	[Unit.CodeEnumRank.Champion] = "Challenger",
	[Unit.CodeEnumRank.Standard] = "Grunt",
	[Unit.CodeEnumRank.Minion] = "Minion",
	[Unit.CodeEnumRank.Fodder] = "Fodder"
}		

local ktDefaultBorder = {
	show = true,
	color = "000000",
	transparency = "67",
	size = 2
}
		
local ktDefaultBackground = {
	show = true,
	color = "000000",
	transparency = "47"
}

local tTextType = {
	[0] = "None",
	[1] = "Name",
	[2] = "Detailed",
	[3] = "Shortened",
	[4] = "Percent",
	[5] = "Super Short",
	[6] = "Class"
}

local tWindowTypeKey = {
	frame = "window",
	buff = "buffs",
	debuff = "debuffs",
	castbar = "castbar"
}

local karConInfo =
{
	{-4, "ConTrivial", 	Apollo.GetString("TargetFrame_Trivial"), 	Apollo.GetString("TargetFrame_NoXP"), 				"ff7d7d7d"},
	{-3, "ConInferior", 	Apollo.GetString("TargetFrame_Inferior"), 	Apollo.GetString("TargetFrame_VeryReducedXP"), 		"ff01ff07"},
	{-2, "ConMinor", 		Apollo.GetString("TargetFrame_Minor"), 		Apollo.GetString("TargetFrame_ReducedXP"), 			"ff01fcff"},
	{-1, "ConEasy", 		Apollo.GetString("TargetFrame_Easy"), 		Apollo.GetString("TargetFrame_SlightlyReducedXP"), 	"ff597cff"},
	{ 0, "ConAverage", 	Apollo.GetString("TargetFrame_Average"), 	Apollo.GetString("TargetFrame_StandardXP"), 		"ffffffff"},
	{ 1, "ConModerate", 	Apollo.GetString("TargetFrame_Moderate"), 	Apollo.GetString("TargetFrame_SlightlyMoreXP"), 	"ffffff00"},
	{ 2, "ConTough", 		Apollo.GetString("TargetFrame_Tough"), 		Apollo.GetString("TargetFrame_IncreasedXP"), 		"ffff8000"},
	{ 3, "ConHard", 		Apollo.GetString("TargetFrame_Hard"), 		Apollo.GetString("TargetFrame_HighlyIncreasedXP"), 	"ffff0000"},
	{ 4, "ConImpossible", 	Apollo.GetString("TargetFrame_Impossible"), Apollo.GetString("TargetFrame_GreatlyIncreasedXP"),	"ffff00ff"}
}	

function PotatoFrames:HelperCalculateConValue(unitTarget)
	local nUnitCon = GameLib.GetPlayerUnit():GetLevelDifferential(unitTarget)
	local nCon = 1 --default setting

	if nUnitCon <= karConInfo[1][1] then -- lower bound
		nCon = 1
	elseif nUnitCon >= karConInfo[#karConInfo][1] then -- upper bound
		nCon = #karConInfo
	else
		for idx = 2, (#karConInfo-1) do -- everything in between
			if nUnitCon == karConInfo[idx][1] then
				nCon = idx
			end
		end
	end
	
	return nCon
end

local ktRankDescriptions =
{
	[Unit.CodeEnumRank.Fodder] 		= 	{Apollo.GetString("TargetFrame_Fodder"), 		Apollo.GetString("TargetFrame_VeryWeak")},
	[Unit.CodeEnumRank.Minion] 		= 	{Apollo.GetString("TargetFrame_Minion"), 		Apollo.GetString("TargetFrame_Weak")},
	[Unit.CodeEnumRank.Standard]	= 	{Apollo.GetString("TargetFrame_Grunt"), 		Apollo.GetString("TargetFrame_EasyAppend")},
	[Unit.CodeEnumRank.Champion] 	=	{Apollo.GetString("TargetFrame_Challenger"), 	Apollo.GetString("TargetFrame_AlmostEqual")},
	[Unit.CodeEnumRank.Superior] 	=  	{Apollo.GetString("TargetFrame_Superior"), 		Apollo.GetString("TargetFrame_Strong")},
	[Unit.CodeEnumRank.Elite] 		= 	{Apollo.GetString("TargetFrame_Prime"), 		Apollo.GetString("TargetFrame_VeryStrong")},
}

function PotatoFrames:HelperBuildTooltip(strBody, strTitle, crTitleColor)
	if strBody == nil then return end
	local strTooltip = string.format("<T Font=\"CRB_InterfaceMedium\" TextColor=\"%s\">%s</T>", "ffc0c0c0", strBody)
	if strTitle ~= nil then -- if a title has been passed, add it (optional)
		strTooltip = string.format("<P>%s</P>", strTooltip)
		local strTitle = string.format("<P Font=\"CRB_InterfaceMedium_B\" TextColor=\"%s\">%s</P>", crTitleColor or "ffdadada", strTitle)
		strTooltip = strTitle .. strTooltip
	end
	return strTooltip
end

-- Convert a color object into a hex-encoded string using format "rrggbb"
function PotatoFrames:Convert_CColor_To_String(c)
	return string.format("%02X%02X%02X", math.floor(c.r * 255 + 0.5), math.floor(c.g * 255 + 0.5), math.floor(c.b * 255 + 0.5))
end

function PotatoFrames:Convert_String_To_CColor(hex)
	local r, g, b = 0, 0, 0 -- invalid strings will result in these values being returned
	local n = tonumber(hex, 16)
	if n then r = math.floor(n / 65536); g = math.floor(n / 256) % 256; b = n % 256 end
	return CColor.new(r / 255, g / 255, b / 255, 1)
end

-----------------------------------------------------------------------------------------------
-- PotatoFrames OnLoad
-----------------------------------------------------------------------------------------------

function PotatoFrames:OnLoad()
    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)
	
	Apollo.RegisterTimerHandler("FrameUpdate", 					"CheckVariables", self)
	
	Apollo.CreateTimer("FrameUpdate", 0.013, true)
	
	Apollo.RegisterSlashCommand("focus", "OnFocusSlashCommand", self)

	--Apollo.RegisterEventHandler("UI_HealthChanged", 		"OnFrame", self)
	--Apollo.RegisterEventHandler("UI_EnergyChanged", 		"OnFrame", self)
	--Apollo.RegisterEventHandler("UI_LevelChanged", 		"OnFrame", self)

	Apollo.RegisterEventHandler("VarChange_FrameCount", 		"OnFrame", self)
	Apollo.RegisterEventHandler("UnitCreated",					"OnUnitCreated", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", 			"OnEnteredCombat", self)
	Apollo.RegisterEventHandler("SystemKeyDown",				"OnSystemKeyDown", self)
	
	Apollo.RegisterEventHandler("PotatoEditor",					"EditorModeToggle", self)
	Apollo.RegisterEventHandler("PotatoReset",					"ResetFrames", self)
	Apollo.RegisterEventHandler("PotatoOptions",				"OptionsChosen", self)
	
	self.tFrames = {}
	self.tAccountData = {}
	self.maxVuln = {0,0,0,0,0,0}
	
	--Build Frames
	for idx=1, #ktDefaultFrames do
		local tBuiltFrame = TableUtil:Copy(PotatoLib.frame)
		local tBuiltCastbar = {}
		local tBuiltBuffs = {}
		local tBuiltDebuffs = {}
		
		--Build default frame attributes	
		tBuiltFrame.name = ktDefaultFrames[idx].name
		tBuiltFrame.anchors = ktDefaultFrames[idx].anchors
		tBuiltFrame.offsets = ktDefaultFrames[idx].offsets
		tBuiltFrame.showFrame = 1
		tBuiltFrame.portraitType = ktDefaultFrames[idx].portraitType
		tBuiltFrame.showIcons = ktDefaultFrames[idx].showIcons
		tBuiltFrame.icons = TableUtil:Copy(ktDefaultIcons)
		tBuiltFrame.barStyles = TableUtil:Copy(PotatoLib.ktDefaultFramesMess)
		tBuiltFrame.border = TableUtil:Copy(ktDefaultBorder)
		tBuiltFrame.background = TableUtil:Copy(ktDefaultBackground)
		
		--Build default castbar attributes
		tBuiltCastbar.name = ktDefaultCastbars[idx].name
		tBuiltCastbar.anchors = ktDefaultCastbars[idx].anchors
		tBuiltCastbar.offsets = ktDefaultCastbars[idx].offsets
		tBuiltCastbar.showFrame = 1
		
		--Build default buff attributes
		tBuiltBuffs.name = string.gsub(ktDefaultFrames[idx].name, "Frame", "Buffs")
		tBuiltBuffs.anchors = TableUtil:Copy(ktDefaultFrames[idx].anchors)
		tBuiltBuffs.offsets = TableUtil:Copy(ktDefaultFrames[idx].offsets)
		local buffOffset = 0
		if idx == 1 then
			buffOffset = 30
		end
		tBuiltBuffs.offsets[1] = ktDefaultFrames[idx].offsets[1]
		tBuiltBuffs.offsets[3] = ktDefaultFrames[idx].offsets[3]
		tBuiltBuffs.offsets[2] = ktDefaultFrames[idx].offsets[2] - 30 - buffOffset
		tBuiltBuffs.offsets[4] = ktDefaultFrames[idx].offsets[2] - buffOffset
		tBuiltBuffs.showFrame = 1
		tBuiltBuffs.align = 1
		
		tBuiltDebuffs =	TableUtil:Copy(tBuiltBuffs)
		tBuiltDebuffs.name = string.gsub(ktDefaultFrames[idx].name, "Frame", "Debuffs")
		tBuiltDebuffs.offsets[2] = ktDefaultFrames[idx].offsets[2] - 60 - buffOffset
		tBuiltDebuffs.offsets[4] = ktDefaultFrames[idx].offsets[2] - 30 - buffOffset
		
		--Load frame/castbar forms
		self.tFrames[idx] = {
			window = Apollo.LoadForm("PotatoFrames.xml", "Unitframe", nil, self),
			castbar = Apollo.LoadForm("PotatoFrames.xml", "Castbar", nil, self),
			buffs = Apollo.LoadForm("PotatoFrames.xml", "BeneBuffFrame", nil, self),
			debuffs = Apollo.LoadForm("PotatoFrames.xml", "HarmBuffFrame", nil, self),
			frameData = tBuiltFrame,
			castbarData = tBuiltCastbar,
			buffData = tBuiltBuffs,
			debuffData = tBuiltDebuffs
		}
		
		self.tFrames[idx].window:SetData({id=idx,type="frame"})
		self.tFrames[idx].window:FindChild("EditorCover"):SetText(ktDefaultFrames[idx].name)
		self.tFrames[idx].window:SetAnchorPoints(unpack(ktDefaultFrames[idx].anchors)) --TODO: may be able to be removed? Probably not, initial set of position.
		self.tFrames[idx].window:SetAnchorOffsets(unpack(ktDefaultFrames[idx].offsets)) --TODO: may be able to be removed?
		
		self.tFrames[idx].castbar:SetData({id=idx,type="castbar"})
		self.tFrames[idx].castbar:FindChild("EditorCover"):SetText(ktDefaultCastbars[idx].name)
		self.tFrames[idx].castbar:SetAnchorPoints(unpack(ktDefaultCastbars[idx].anchors))
		self.tFrames[idx].castbar:SetAnchorOffsets(unpack(ktDefaultCastbars[idx].offsets))
		
		self.tFrames[idx].buffs:SetData({id=idx,type="buff"})
		self.tFrames[idx].buffs:FindChild("EditorCover"):SetText(tBuiltBuffs.name)
		self.tFrames[idx].buffs:SetAnchorPoints(unpack(tBuiltBuffs.anchors))
		self.tFrames[idx].buffs:SetAnchorOffsets(unpack(tBuiltBuffs.offsets))
		
		self.tFrames[idx].debuffs:SetData({id=idx,type="debuff"})
		self.tFrames[idx].debuffs:FindChild("EditorCover"):SetText(tBuiltDebuffs.name)
		self.tFrames[idx].debuffs:SetAnchorPoints(unpack(tBuiltDebuffs.anchors))
		self.tFrames[idx].debuffs:SetAnchorOffsets(unpack(tBuiltDebuffs.offsets))
	end

	self.tFrames[5].window:Show(true)
	self.tFrames[6].window:Show(true)
	
	-- Mount health
	self.wndMountHealth = Apollo.LoadForm("PotatoFrames.xml", "MountHealthFrame", nil, self)
	self.wndMountHealth:Show(false)

	self.wndMountHealth:SetAnchorPoints(0.5,0.5,0.5,0.5)
	self.wndMountHealth:SetAnchorOffsets(-100,-17,100,17)
	
	--Combat notice
	self.wndCombatNotice = Apollo.LoadForm("PotatoFrames.xml", "CombatNotice", nil, self)
	self.bShowCmbNote = true
	self.wndCombatNotice:SetAnchorPoints(0.5,1,0.5,1)
	self.wndCombatNotice:SetAnchorOffsets(-16,-292,16,-260)
	
	self.bInCombat = false
end

function PotatoFrames:OnFocusSlashCommand()
	local unitTarget = GameLib.GetTargetUnit()
	
	GameLib.GetPlayerUnit():SetAlternateTarget(unitTarget)
end

function PotatoFrames:OnSave(eLevel) -- TODO: Optimize this code
    -- create a table to hold our data
	local tSave = {}
	local tWndData = {}

	for idx=1, #ktDefaultFrames do
		self.tFrames[idx].frameData.anchors = {self.tFrames[idx].window:GetAnchorPoints()}
		self.tFrames[idx].frameData.offsets = {self.tFrames[idx].window:GetAnchorOffsets()}
		
		self.tFrames[idx].castbarData.anchors = {self.tFrames[idx].castbar:GetAnchorPoints()}
		self.tFrames[idx].castbarData.offsets = {self.tFrames[idx].castbar:GetAnchorOffsets()}
		
		self.tFrames[idx].buffData.anchors = {self.tFrames[idx].buffs:GetAnchorPoints()}
		self.tFrames[idx].buffData.offsets = {self.tFrames[idx].buffs:GetAnchorOffsets()}
		
		self.tFrames[idx].debuffData.anchors = {self.tFrames[idx].debuffs:GetAnchorPoints()}
		self.tFrames[idx].debuffData.offsets = {self.tFrames[idx].debuffs:GetAnchorOffsets()}
		
		tWndData[idx] = {
			frameData = self.tFrames[idx].frameData,
		 	castbarData = self.tFrames[idx].castbarData,
			buffData = self.tFrames[idx].buffData,
			debuffData = self.tFrames[idx].debuffData
		}
	end
	
	local mountHealth = {}
	
	mountHealth.anchors = {self.wndMountHealth:GetAnchorPoints()}
	mountHealth.offsets = {self.wndMountHealth:GetAnchorOffsets()}
	
	tSave = {
		frameData = tWndData,
		mountHealth = mountHealth,
		cmbNote = {
				anchors = {self.wndCombatNotice:GetAnchorPoints()},
				offsets={self.wndCombatNotice:GetAnchorOffsets()},
				show = self.bShowCmbNote
		}
	}
	
    if eLevel == GameLib.CodeEnumAddonSaveLevel.Character then
        return tSave
    elseif eLevel == GameLib.CodeEnumAddonSaveLevel.Account then
		self.tAccountData[self.strCharacterName] = tSave
		return self.tAccountData
	else
		return nil
	end
end

function PotatoFrames:OnRestore(eLevel, tData)
    if eLevel == GameLib.CodeEnumAddonSaveLevel.Character then
	    self.tSavedData = tData
		
		if self.tSavedData then	
			for idx=1, #ktDefaultFrames do
				if self.tSavedData.frameData[idx] then
					local tFrameData = self.tSavedData.frameData[idx].frameData
					local tCastbarData = self.tSavedData.frameData[idx].castbarData
					
					if tFrameData and tFrameData ~= nil then
						if tFrameData.background == nil then tFrameData.background = TableUtil:Copy(ktDefaultBackground) end --TODO: HACKY
						if tFrameData.border == nil then tFrameData.border = TableUtil:Copy(ktDefaultBorder) end --TODO: HACKY
						if tFrameData.barStyles[4].showResBar == nil then tFrameData.barStyles[4].showResBar = true end
						
						for idx2=1, #tFrameData.barStyles do --Force into new text data format TODO: HACKY
							for key, val in pairs(tFrameData.barStyles[idx2]) do
								if key == "textLeft" or key == "textRight" or key == "textMid" then
									if type(val) ~= "table" then --If not a table, it's in old format
										local nTypePlaceholder = val
										tFrameData.barStyles[idx2][key] = TableUtil:Copy(PotatoLib.ktDefaultFramesMess[idx2][key])
										tFrameData.barStyles[idx2][key].type = nTypePlaceholder
									end
								end
							end
						end
								
						self.tFrames[idx].frameData = tFrameData
						self.tFrames[idx].castbarData = tCastbarData
						
						self.tFrames[idx].window:SetAnchorPoints(unpack(tFrameData.anchors))
						self.tFrames[idx].window:SetAnchorOffsets(unpack(tFrameData.offsets))
						
						self:ShowBG(self.tFrames[idx].window:FindChild("Content"), tFrameData.background.show)
						self:ShowBG(self.tFrames[idx].window:FindChild("SimpleTarget"), tFrameData.background.show)						
						self:ShowBorder(self.tFrames[idx].window,self.tFrames[idx].window:FindChild("Content"), tFrameData.border, tFrameData.border.show)
						self.tFrames[idx].window:FindChild("Portrait"):SetAnimated(tFrameData.portraitType == 1)
		
						self.tFrames[idx].castbar:SetAnchorPoints(unpack(tCastbarData.anchors))
						self.tFrames[idx].castbar:SetAnchorOffsets(unpack(tCastbarData.offsets))
						
						local tBuffData = self.tSavedData.frameData[idx].buffData
						local tDebuffData = self.tSavedData.frameData[idx].debuffData
	
						if (tBuffData and tBuffData ~= nil) then
							self.tFrames[idx].buffData = tBuffData
							self.tFrames[idx].debuffData = tDebuffData
							self.tFrames[idx].buffs:SetAnchorPoints(unpack(tBuffData.anchors))
							self.tFrames[idx].buffs:SetAnchorOffsets(unpack(tBuffData.offsets))
							self:UpdateBuffPosition(self.tFrames[idx].buffs, tBuffData.align)
							
							self.tFrames[idx].debuffs:SetAnchorPoints(unpack(tDebuffData.anchors))
							self.tFrames[idx].debuffs:SetAnchorOffsets(unpack(tDebuffData.offsets))
							self:UpdateBuffPosition(self.tFrames[idx].debuffs, tDebuffData.align)
						end
					end
				end
			end
			
			if self.tSavedData.mountHealth then
				self.wndMountHealth:SetAnchorPoints(unpack(self.tSavedData.mountHealth.anchors))
				self.wndMountHealth:SetAnchorOffsets(unpack(self.tSavedData.mountHealth.offsets))
			end
			
			if self.tSavedData.cmbNote then
				self.bShowCmbNote = self.tSavedData.cmbNote.show
				self.wndCombatNotice:SetAnchorPoints(unpack(self.tSavedData.cmbNote.anchors))
				self.wndCombatNotice:SetAnchorOffsets(unpack(self.tSavedData.cmbNote.offsets))
			end
		end
	elseif eLevel == GameLib.CodeEnumAddonSaveLevel.Account then
		self.tAccountData = tData
	end
end

function PotatoFrames:OnEnteredCombat(unit, bInCombat)
	if unit:GetName() == GameLib.GetPlayerUnit():GetName() then
		self.bInCombat = bInCombat
	end
end

-----------------------------------------------------------------------------------------------
-- PotatoFrames Functions
-----------------------------------------------------------------------------------------------
-- Define general functions here=

function PotatoFrames:EditorModeToggle()
	editorMode = not editorMode
	local wndPlayer = self.tFrames[1].window
	local wndTarget = self.tFrames[2].window
	local wndToT = self.tFrames[3].window	
	
	--Change appearance of frames for ease of editing
	for idx=1, #self.tFrames do
		local wndCurrWnd = self.tFrames[idx].window

		wndCurrWnd:FindChild("EditorCover"):Show(editorMode)
		wndCurrWnd:SetStyle("Moveable", editorMode)
		wndCurrWnd:SetStyle("Sizable", editorMode)
		wndCurrWnd:FindChild("RaidMarker"):SetStyle("NewWindowDepth", not editorMode)
		
		if idx == 1 then
			wndCurrWnd:FindChild("Selection"):SetStyle("NewWindowDepth", not editorMode)
		else
			wndCurrWnd:FindChild("SimpleTarget"):Show(false)
		end
		
		local wndCurrBar = self.tFrames[idx].castbar
		wndCurrBar:FindChild("EditorCover"):Show(editorMode)
		wndCurrBar:SetStyle("Moveable", editorMode)
		wndCurrBar:SetStyle("Sizable", editorMode)	
		
		local wndCurrBuffs = self.tFrames[idx].buffs
		wndCurrBuffs:FindChild("EditorCover"):Show(editorMode)
		wndCurrBuffs:FindChild("Border"):Show(editorMode)
		wndCurrBuffs:SetStyle("Moveable", editorMode)
		wndCurrBuffs:SetStyle("Sizable", editorMode)
		wndCurrBuffs:SetStyle("IgnoreMouse", not editorMode)	

		local wndCurrDebuffs = self.tFrames[idx].debuffs
		wndCurrDebuffs:FindChild("EditorCover"):Show(editorMode)
		wndCurrDebuffs:FindChild("Border"):Show(editorMode)
		wndCurrDebuffs:SetStyle("Moveable", editorMode)
		wndCurrDebuffs:SetStyle("Sizable", editorMode)	
		wndCurrDebuffs:SetStyle("IgnoreMouse", not editorMode)			
	end
		
	--Show target + tot if they aren't visible so they can be edited
	if not wndTarget:IsVisible() then
		wndTarget:Show(true)
		if not wndToT:IsVisible() then
			wndToT:Show(true)
		end
	end
	
	--Destroy Customization window to save memory
	if not editorMode and self.wndCustomize ~= nil then
		self.wndCustomize:Destroy()
	end	
end

function PotatoFrames:ResetFrames()
	--Destroy Customization window to save memory
	if self.wndCustomize ~= nil then
		self.wndCustomize:Destroy()
		Apollo.GetAddon("PotatoLib").wndCustomize:Show(false)
	end	
	
	for idx=1, #ktDefaultFrames do
		self.tFrames[idx].window:SetAnchorPoints(unpack(ktDefaultFrames[idx].anchors))
		self.tFrames[idx].window:SetAnchorOffsets(unpack(ktDefaultFrames[idx].offsets))
		self.tFrames[idx].frameData.portraitType = ktDefaultFrames[idx].portraitType
		self.tFrames[idx].window:FindChild("Portrait"):SetAnimated(portraitType ~= 2 and true or false)
		self.tFrames[idx].frameData.showFrame = 1
		self.tFrames[idx].frameData.border = TableUtil:Copy(ktDefaultBorder)
		self:ShowBorder(self.tFrames[idx].window,self.tFrames[idx].window:FindChild("Content"),self.tFrames[idx].frameData.border,self.tFrames[idx].frameData.border.show)
		self.tFrames[idx].frameData.background = TableUtil:Copy(ktDefaultBackground)
		self:ShowBG(self.tFrames[idx].window:FindChild("Content"), self.tFrames[idx].frameData.background.show)
		self:ShowBG(self.tFrames[idx].window:FindChild("SimpleTarget"), self.tFrames[idx].frameData.background.show)
		self.tFrames[idx].frameData.showIcons = ktDefaultFrames[idx].showIcons
		
		self.tFrames[idx].castbar:SetAnchorPoints(unpack(ktDefaultCastbars[idx].anchors))
		self.tFrames[idx].castbar:SetAnchorOffsets(unpack(ktDefaultCastbars[idx].offsets))
		self.tFrames[idx].castbarData.showFrame = 1
		
		self.tFrames[idx].frameData.barStyles = TableUtil:Copy(PotatoLib.ktDefaultFramesMess)
		
		local buffOffset = 0
		if idx == 1 then	buffOffset = 30		end
		local tOffsets = TableUtil:Copy(ktDefaultFrames[idx].offsets)
		local tAnchors = TableUtil:Copy(ktDefaultFrames[idx].anchors)
		
		self.tFrames[idx].buffs:SetAnchorOffsets(tOffsets[1], tOffsets[2]-30-buffOffset, tOffsets[3], tOffsets[2]-buffOffset)
		self.tFrames[idx].buffData.offsets = {self.tFrames[idx].buffs:GetAnchorOffsets()}
		self.tFrames[idx].buffData.showFrame = 1
		self.tFrames[idx].buffData.align = 1
		self:UpdateBuffPosition(self.tFrames[idx].buffs, 1)	
		
		self.tFrames[idx].debuffs:SetAnchorOffsets(tOffsets[1], tOffsets[2]-60-buffOffset, tOffsets[3], tOffsets[2]-30-buffOffset)
		self.tFrames[idx].debuffData.offsets = {self.tFrames[idx].debuffs:GetAnchorOffsets()}
		self.tFrames[idx].debuffData.showFrame = 1
		self.tFrames[idx].debuffData.align = 1
		self:UpdateBuffPosition(self.tFrames[idx].debuffs, 1)
	end
	
	self.wndMountHealth:SetAnchorPoints(0.5,0.5,0.5,0.5)
	self.wndMountHealth:SetAnchorOffsets(-100,-17,100,17)
	
	self.wndCombatNotice:SetAnchorPoints(0.5,1,0.5,1)
	self.wndCombatNotice:SetAnchorOffsets(-16,-292,16,-260)
end

function PotatoFrames:CreateIcon(wnd, unit, tCurrIco)
	local bCharacter = unit:IsACharacter()
	local strSprite = ""
	local strText = ""
	local strColor = "FFFFFFFF"
	local nLeft, nTop, nRight, nBottom = 0, 0, 0, 0
	local strTooltip = ""
	
	local strType = bCharacter and tCurrIco.playerType or tCurrIco.npcType
	
	if strType == "class" then
		if bCharacter then
			strSprite = "ClientSprites:Icon_Windows_UI_CRB_" .. GameLib.GetClassName(unit:GetClassId())
		elseif unit:GetArchetype() ~= nil then
			strSprite = unit:GetArchetype().strIcon
		end
		
		--TODO: Figure out what is going on with Stalkers during Clone.
		if strSprite == nil then
			strSprite = ""
		end
		--strSprite = bCharacter and ("ClientSprites:Icon_Windows_UI_CRB_" .. GameLib.GetClassName(unit:GetClassId())) or unit:GetArchetype().strIcon
				
		if not bCharacter then nLeft, nTop, nRight, nBottom = -5, -5, 5, 5 end
	elseif strType == "faction" then
		strSprite = PotatoLib.factionNames[unit:GetFaction()] ~= nil and ("CRB_CharacterCreateSprites:sprCC_" .. PotatoLib.factionNames[unit:GetFaction()] .. "Icon") or ""	
		
		--Set group size sprite and value.	
		local nGroupSize = unit:GetGroupValue()
		if nGroupSize > 1 then
			strText = nGroupSize
			if PotatoLib.factionNames[unit:GetFaction()] == nil then --If it's not a factioned NPC, give it a group size background.
				strSprite = "CRB_TargetFrameSprites:sprTF_GroupRank_Base"
			end
		end
	elseif strType == "path" then
		strSprite = bCharacter and ("ClientSprites:Icon_Windows_UI_CRB_" .. PotatoLib.pathNames[unit:GetPlayerPathType()]) or ""
	elseif strType == "level" then
		strText = unit:GetLevel() ~= nil and (unit:GetLevel() .. "") or "??"
		local nCon = self:HelperCalculateConValue(unit)
		strColor = karConInfo[nCon][2]
		
		local strReward = String_GetWeaselString(Apollo.GetString("TargetFrame_TargetXPReward"), karConInfo[nCon][4])
		strTooltip = self:HelperBuildTooltip(strReward, karConInfo[nCon][3], karConInfo[nCon][5])
	end
		
	if strType == "difficulty" and unit:GetType() == "NonPlayer" and ktDifficultySprites[unit:GetRank()] then
		local nRank = unit:GetRank()
		PotatoLib:SetSprite(wnd, ktDifficultySprites[nRank])
		
		local strRank = String_GetWeaselString(Apollo.GetString("TargetFrame_CreatureRank"), ktRankDescriptions[nRank][2])
		strTooltip = self:HelperBuildTooltip(strRank, ktRankDescriptions[nRank][1])
	else
		wnd:SetSprite(strSprite)
	end
	wnd:SetAnchorOffsets(nLeft, nTop, nRight, nBottom)
	PotatoLib:TextSquish(strText, wnd:GetParent(), "_BO", 5)
	wnd:GetParent():SetTextColor(strColor)
	wnd:SetTooltip(strTooltip)
end

function PotatoFrames:CreateBar(wndBar, unit, tCurrBar)
	local ktBars = {
						HP = {unit:GetHealth(), unit:GetMaxHealth()},
						SP = {unit:GetShieldCapacity(), unit:GetShieldCapacityMax()},
						RP = {PotatoLib:GetClassResource(unit)},
						AP = {unit:GetAbsorptionValue(), unit:GetAbsorptionMax()}
					}
					
	local bCharacter = unit:IsACharacter()
	
	local nCurrVal, nMaxVal = unpack(ktBars[tCurrBar.name])
	local strColor = "FF0000"
	
	--Bar Growth
	local bBarGrowth = tCurrBar.barGrowth == 1
	wndBar:SetStyleEx("BRtoLT", bBarGrowth)
	
	--Bar Values
	PotatoLib:SetBarVars2(wndBar, nCurrVal, nMaxVal)
	
	--Bar Appearance
	if tCurrBar.colorType == "classcolor" then
		if bCharacter then
			strColor = PotatoLib.classColors[unit:GetClassId()]
		else
			local nDisposition = GameLib.GetPlayerUnit():GetDispositionTo(unit)
			if nDisposition == Unit.CodeEnumDisposition.Hostile then
				strColor = "CC0000"
			elseif nDisposition == Unit.CodeEnumDisposition.Neutral then
				strColor = "FFCC00"
			elseif nDisposition == Unit.CodeEnumDisposition.Friendly then
				strColor = "005C00"
			end
		end
		--strColor = bCharacter and PotatoLib.classColors[unit:GetClassId()] or "00FF00"
	elseif tCurrBar.colorType == "resourcecolor" then
		strColor = bCharacter and PotatoLib.resourceColors[unit:GetClassId()] or "AAAAAA"
	else
		strColor = tCurrBar.color
	end
	tCurrBar.color = strColor

	PotatoLib:SetBarAppearance2(wndBar, tCurrBar.texture, strColor, tCurrBar.transparency)
	
	--Bar Text
	for idx2=1, 3 do
		local ktPos = {"Left", "Mid", "Right"}
		local strTextLoc = "text"..ktPos[idx2]
		local strText = ""
									--ktPos == 0 is None
		if tCurrBar[strTextLoc].type == 1 then --Name
			strText = unit:GetName()
		elseif tCurrBar[strTextLoc].type == 2 then --Detailed Verbose
			strText = (nMaxVal ~= 0 and nMaxVal ~= nil) and (math.floor(nCurrVal) .. "/" .. math.floor(nMaxVal)) or ""
		elseif tCurrBar[strTextLoc].type == 3 then --Detailed Short
			strText = (nMaxVal ~= 0 and nMaxVal ~= nil) and (self:FormatNumber(nCurrVal) .. "/" .. self:FormatNumber(nMaxVal)) or ""
		elseif tCurrBar[strTextLoc].type == 4 then
			strText = (nMaxVal ~= 0 and nMaxVal ~= nil) and (math.floor(nCurrVal/nMaxVal*100).."%") or ""
		elseif tCurrBar[strTextLoc].type == 5 then
			strText = (nMaxVal ~= 0 and nMaxVal ~= nil) and (self:FormatNumber(nCurrVal)) or ""
		elseif tCurrBar[strTextLoc].type == 6 then
			local strClassName = GameLib.GetClassName(unit:GetClassId()) or "Unknown Class"
			strText = strClassName ~= "Unknown Class" and strClassName or ""
		end		
		
		wndBar:FindChild(tCurrBar.name.."text"..ktPos[idx2]):SetText(strText)
		
		wndBar:FindChild(tCurrBar.name.."text"..ktPos[idx2]):SetFont(PotatoLib:FontTableToString(tCurrBar[strTextLoc].font))
		
	end
	
	--Show Resource Bar
	if tCurrBar.name == "RP" and not tCurrBar.showResBar then
		wndBar:Show(false)
	else
		wndBar:Show(true) --wndBar:Show(nMaxVal ~= 0 and true or false)
	end
end

function PotatoFrames:OnFrame() --hacky target update -TODO: Separate out update events.
	--Stance fix.
	if ActionBarFrame then
		local wndEndurance = Apollo.GetAddon("HealthShieldBar").wndEndurance
		local wndInnate = ActionBarFrame.wndMain:FindChild("ActionBarInnate")
		if ActionBarFrame.wndStancePopoutFrame:IsVisible() then
			wndEndurance:Show(false)
			wndInnate:Show(false)
		else
			if not wndEndurance:IsVisible() then
				wndEndurance:Show(true)
			end
			if not wndInnate:IsVisible() then
				wndInnate:Show(true)
			end
		end
	end
	
	--Frame stuff.
	local targetUnit = GameLib.GetTargetUnit()--GameLib.GetTargetUnit() or GameLib.GetPlayerUnit()
	local playerUnit = GameLib.GetPlayerUnit()
	local focusUnit = playerUnit and playerUnit:GetAlternateTarget() or nil
	
	local tPlayerWnds = self.tFrames[1]
	local tTargetWnds = self.tFrames[2]
	local tToTWnds = self.tFrames[3]
	local tFocusWnds = self.tFrames[4]
		
	--if not editorMode then  TODO: OPTIMIZE THIS CODE.
		if not playerUnit or playerUnit == nil then
			self:CreateAndDisplay(tPlayerWnds, false)
			return
		else
			self:CreateAndDisplay(tPlayerWnds, true, playerUnit, "left")
			if self.strCharacterName == nil then		self.strCharacterName = playerUnit:GetName()	end
		end

		if not targetUnit or targetUnit == nil then
			if editorMode then
				self:CreateAndDisplay(tTargetWnds, true, playerUnit, "right")
				self:CreateAndDisplay(tToTWnds, true, playerUnit, "right")
			else
				self:CreateAndDisplay(tTargetWnds, false)
				self:CreateAndDisplay(tToTWnds, false)
			end
		else
			self:CreateAndDisplay(tTargetWnds, true, targetUnit, "right")
			
			local ToTUnit = targetUnit:GetTarget()	
			if ToTUnit == nil or ToTUnit == nil then
				if editorMode then
					self:CreateAndDisplay(tToTWnds, true, playerUnit, "right")
				else
					self:CreateAndDisplay(tToTWnds, false)
				end
			else
				self:CreateAndDisplay(tToTWnds, true, ToTUnit, "right")
			end
		end
		
		if not focusUnit or focusUnit == nil then
			if editorMode then
				self:CreateAndDisplay(tFocusWnds, true, playerUnit, "left")
			else
				self:CreateAndDisplay(tFocusWnds, false)
			end
		else
			self:CreateAndDisplay(tFocusWnds, true, focusUnit, "left")
		end
		
	-- Pets
	if playerUnit:GetClassId() == GameLib.CodeEnumClass.Engineer then
		local bShowLeftPet = false
		local bShowRightPet = false
		local wndLeft = self.tFrames[5].window
		local wndRight = self.tFrames[6].window
		
		local tPetData = GameLib.GetPlayerPets()
		local bHavePets = tPetData and #tPetData > 0
	
		local bFoundLeft = false
		local bFoundRight = false
		for idx, unitPet in pairs(tPetData) do
			if unitPet == self.unitLeftEngineerPet then
				bFoundLeft = true
			elseif unitPet == self.unitRightEngineerPet then
				bFoundRight = true
			end
		end
		--
		if not bFoundLeft then
			self.unitLeftEngineerPet = nil
		end
	
		if not bFoundRight then
			self.unitRightEngineerPet = nil
		end
	
		if bHavePets then
			-- Find the left vs right pet (Note an existing right pet stays right until destroyed, to prevent sliding around)
			local ePetStance = nil
			for key, unitPet in pairs(tPetData) do
				if unitPet:GetUnitRaceId() == 298 then -- 298 is the number for engineer pets
					if (not self.unitLeftEngineerPet or not self.unitLeftEngineerPet:IsValid()) and unitPet ~= self.unitRightEngineerPet then
						self.unitLeftEngineerPet = unitPet
					elseif unitPet ~= self.unitLeftEngineerPet and (not self.unitRightEngineerPet or not self.unitRightEngineerPet:IsValid()) then
						self.unitRightEngineerPet = unitPet
					end
				end
			end
	
			local bHasValidPet = false
	
			if self.unitLeftEngineerPet and self.unitLeftEngineerPet:IsValid() then
				--[[local eCurrStance = Pet_GetStance(self.unitLeftEngineerPet:GetId())
				if eCurrStance and eCurrStance > 0 then
					ePetStance = eCurrStance
				end]]--
				self:CreateFrame(wndLeft, self.unitLeftEngineerPet, "right")
				bHasValidPet = true
			end
	
			if self.unitRightEngineerPet and self.unitRightEngineerPet:IsValid() then
				--[[local eCurrStance = Pet_GetStance(self.unitRightEngineerPet:GetId())
				if eCurrStance and eCurrStance > 0 then
					ePetStance = eCurrStance
				end]]--
				
				self:CreateFrame(wndRight, self.unitRightEngineerPet, "right")
				bHasValidPet = true
			end
			

	
			--[[if bHasValidPet then
				self.wndMain:FindChild("StanceMenuOpenerText"):SetText(ktEngineerStanceToShortString[ePetStance or 0] or "")
			end]]-- FOR SETTING THE PET STANCE TEXT
		end
		
		if not self.unitRightEngineerPet then
			wndRight:Show(editorMode)
		end
		
		if not self.unitLeftEngineerPet then
			wndLeft:Show(editorMode)
		end
	else
		for idx=5, 6 do
			self.tFrames[idx].window:Show(false)
			self.tFrames[idx].buffs:Show(false)
			self.tFrames[idx].debuffs:Show(false)
			self.tFrames[idx].castbar:Show(false)
		end
	end
				
	--Mount Health TODO: MOVE THE EDITOR STUFF
	local bMounted = playerUnit:IsMounted()
	local nMountCurrHealth = playerUnit:GetMountHealth() or 0
	local nMountMaxHealth = playerUnit:GetMountMaxHealth() or 0

	if not editorMode then	
		self.wndMountHealth:Show(bMounted)
		if bMounted then
			self.wndMountHealth:FindChild("MountHealth"):SetMax(nMountMaxHealth)
			self.wndMountHealth:FindChild("MountHealth"):SetProgress(nMountCurrHealth)
			self.wndMountHealth:FindChild("MountHealthText"):SetText(String_GetWeaselString(Apollo.GetString("HealthBar_MountHealth"), nMountCurrHealth, nMountMaxHealth))
			
			self.wndMountHealth:FindChild("EditorCover"):Show(false)
			self.wndMountHealth:SetStyle("IgnoreMouse", true)
			self.wndMountHealth:SetStyle("Sizable", false)
			self.wndMountHealth:SetStyle("Moveable", false)
			return
		end
	else
		self.wndMountHealth:Show(true)
		self.wndMountHealth:FindChild("EditorCover"):Show(true)
		self.wndMountHealth:SetStyle("IgnoreMouse", false)
		self.wndMountHealth:SetStyle("Sizable", true)
		self.wndMountHealth:SetStyle("Moveable", true)
	end
	
	--Combat Notice TODO: MOVE THE EDITOR STUFF
	if not editorMode then
		self.wndCombatNotice:FindChild("Icon"):Show(self.bInCombat and self.bShowCmbNote)
		self.wndCombatNotice:FindChild("EditorCover"):Show(false)
		self.wndCombatNotice:SetStyle("IgnoreMouse", true)
		self.wndCombatNotice:SetStyle("Sizable", false)
		self.wndCombatNotice:SetStyle("Moveable", false)
		self.wndCombatNotice:FindChild("Border"):Show(false)
	else
		self.wndCombatNotice:Show(true)
		self.wndCombatNotice:FindChild("EditorCover"):Show(true)
		self.wndCombatNotice:SetStyle("IgnoreMouse", false)
		self.wndCombatNotice:SetStyle("Sizable", true)
		self.wndCombatNotice:SetStyle("Moveable", true)
		self.wndCombatNotice:FindChild("Border"):Show(true)
	end
end

function PotatoFrames:CreateAndDisplay(tWindows, bShow, unitUnit, strLeftOrRight)
	if bShow then
		self:CreateFrame(tWindows.window, unitUnit, strLeftOrRight, 2)
		self:CreateCastbar(tWindows.castbar, unitUnit)
		self:CreateBuffs(tWindows.buffs, unitUnit)
		self:CreateBuffs(tWindows.debuffs, unitUnit)
	else
		tWindows.window:Show(false)
		tWindows.castbar:Show(false)
		tWindows.buffs:Show(false)
		tWindows.debuffs:Show(false)
	end
end

function PotatoFrames:CreateFrame(mainWnd, targetUnit, leftOrRight)
	local wndSimple = mainWnd:FindChild("SimpleTarget")
	local wndContent = mainWnd:FindChild("Content")
	
	--wndContent:SetData(targetUnit)
	local nFrameId = mainWnd:GetData().id
	local tFrameData = self.tFrames[nFrameId].frameData
	local showPortrait  = tFrameData.portraitType < 4 and true or false
	local showIcons = tFrameData.showIcons	
	local wndRaidMarker = wndContent:FindChild("RaidMarker")
	
	mainWnd:SetData({id = mainWnd:GetData().id, type = mainWnd:GetData().type, unit = targetUnit})

	if tFrameData.showFrame == 1 or (tFrameData.showFrame == 2 and self.bInCombat) or editorMode then
		mainWnd:Show(true)
		mainWnd:SetStyle("IgnoreMouse", false)
	
		if wndRaidMarker then
			wndRaidMarker:SetSprite("")
			local nMarkerId = targetUnit and targetUnit:GetTargetMarker() or 0
			if targetUnit and nMarkerId ~= 0 then
				wndRaidMarker:SetSprite("Icon_Windows_UI_CRB_Marker_"..kstrRaidMarkerToSprite[nMarkerId])
			end
		end
				
		if targetUnit:GetHealth() == nil then
			wndSimple:Show(true)
			wndContent:Show(false)
			PotatoLib:TextSquish(targetUnit:GetName(), wndSimple)
			--wndSimple:FindChild("SimplePort"):SetCostume(targetUnit)
		else
			wndSimple:Show(false)
			wndContent:Show(true)
			
			local nPortraitContrib = showPortrait and 0.215 or 0
			local nIconsContrib = showIcons and 0.06 or 0
			local bIsLeft = leftOrRight == "left"
			local nPortIconOffset = bIsLeft and (nPortraitContrib+nIconsContrib) or (1-nPortraitContrib-nIconsContrib)
			
			wndContent:FindChild("Icons"):Show(showIcons)
			wndContent:FindChild("Icons"):SetAnchorPoints(bIsLeft and 0 or 1-nIconsContrib, 0, bIsLeft and nIconsContrib or 1, 1)
			wndContent:FindChild("Icons"):SetAnchorOffsets(bIsLeft and 0 or 3, 0, bIsLeft and 1 or 3, 0)
			
			--Set portait frame attributes		
			wndContent:FindChild("Portrait"):Show(showPortrait and tFrameData.portraitType ~= 3)
			wndContent:FindChild("Portrait"):SetCamera(bIsLeft and "Portrait" or "Target")
			wndContent:FindChild("Portrait"):SetAnchorPoints(bIsLeft and nIconsContrib or nPortIconOffset, 0, bIsLeft and nPortIconOffset or 1-nIconsContrib, 1)
			wndContent:FindChild("Portrait"):SetAnchorOffsets(0, 0, 0, 0)
			
			if wndContent:FindChild("ClassPort") ~= nil then
				wndContent:FindChild("ClassPort"):Show(tFrameData.portraitType == 3)
				if tFrameData.portraitType == 3 then
					local bCharacter = targetUnit:IsACharacter()
					
					if bCharacter then
						strSprite = "ClientSprites:Icon_Windows_UI_CRB_" .. GameLib.GetClassName(targetUnit:GetClassId())
					elseif targetUnit:GetArchetype() ~= nil then
						strSprite = targetUnit:GetArchetype().strIcon
					end
					
					--TODO: Figure out what is going on with Stalkers during Clone.
					if strSprite == nil then
						strSprite = ""
					end
					
					--strSprite = bCharacter and ("ClientSprites:Icon_Windows_UI_CRB_" .. GameLib.GetClassName(unit:GetClassId())) or unit:GetArchetype().strIcon
					wndContent:FindChild("ClassPort"):SetSprite(strSprite)
					wndContent:FindChild("ClassPort"):FindChild("Icon"):SetSprite(strSprite)
					wndContent:FindChild("ClassPort"):SetAnchorPoints(bIsLeft and nIconsContrib or nPortIconOffset, 0, bIsLeft and nPortIconOffset or 1-nIconsContrib, 1)
				end
			end
		
			mainWnd:FindChild("Portrait"):SetCostume(targetUnit)
			if tFrameData.portraitType == 2 then
				mainWnd:FindChild("Portrait"):SetQuality(1)
			else
				mainWnd:FindChild("Portrait"):SetQuality(Apollo.GetConsoleVariable("lod.renderTargetScale"))
			end				
			
			wndContent:FindChild("Bars"):SetAnchorPoints(bIsLeft and nPortIconOffset or 0, 0, bIsLeft and 1 or nPortIconOffset, 1)
			wndContent:FindChild("Bars"):SetAnchorOffsets(0, 0, bIsLeft and 0 or 2, 0)
			
			--Resize distorted Portrait + Bars
			local nPortHeight, nPortWidth = wndContent:FindChild("Portrait"):GetHeight(), wndContent:FindChild("Portrait"):GetWidth()
			if nPortWidth > nPortHeight then
				local tCurrPortAnchors = {wndContent:FindChild("Portrait"):GetAnchorPoints()}
				local tCurrBarsAnchors = {wndContent:FindChild("Bars"):GetAnchorPoints()}
				if bIsLeft then
					if wndContent:FindChild("ClassPort") ~= nil then wndContent:FindChild("ClassPort"):SetAnchorPoints(tCurrPortAnchors[1],tCurrPortAnchors[2],nPortHeight/wndContent:GetWidth()+nIconsContrib,tCurrPortAnchors[4]) end
					wndContent:FindChild("Portrait"):SetAnchorPoints(tCurrPortAnchors[1],tCurrPortAnchors[2],nPortHeight/wndContent:GetWidth()+nIconsContrib,tCurrPortAnchors[4])
					wndContent:FindChild("Bars"):SetAnchorPoints(nPortHeight/wndContent:GetWidth()+nIconsContrib,tCurrBarsAnchors[2],tCurrBarsAnchors[3],tCurrBarsAnchors[4])
				else
					if wndContent:FindChild("ClassPort") ~= nil then wndContent:FindChild("ClassPort"):SetAnchorPoints(1-nPortHeight/wndContent:GetWidth()-nIconsContrib,tCurrPortAnchors[2],tCurrPortAnchors[3],tCurrPortAnchors[4]) end
					wndContent:FindChild("Portrait"):SetAnchorPoints(1-nPortHeight/wndContent:GetWidth()-nIconsContrib,tCurrPortAnchors[2],tCurrPortAnchors[3],tCurrPortAnchors[4])
					wndContent:FindChild("Bars"):SetAnchorPoints(tCurrBarsAnchors[1],tCurrBarsAnchors[2],1-nPortHeight/wndContent:GetWidth()-nIconsContrib,tCurrBarsAnchors[4])
				end
			end
			
			local targetClassID = targetUnit:GetClassId() --**
			local targetFactionID = targetUnit:GetFaction() --**
			local targetPathID = targetUnit:GetPlayerPathType()
			local targetLevel = targetUnit:GetLevel() ~= nil and (targetUnit:GetLevel() .. "") or "??" --**
			local bCharacter = targetUnit:IsACharacter()
			
			--new code
			--Draw Icons from Frame's Data			
			for idx=1, 4 do
				local wndCurrIco = mainWnd:FindChild("Icons"):FindChild("PortIco"..idx):FindChild("Sprite")
				local tCurrIco = tFrameData.icons[idx]
				
				self:CreateIcon(wndCurrIco, targetUnit, tCurrIco)
			end
			--Draw Bars from Frame's Data
			for idx=1, #tFrameData.barStyles do
				local wndCurrBar = mainWnd:FindChild(tFrameData.barStyles[idx].name.."Bar")
				local tCurrBar = tFrameData.barStyles[idx]
				self:CreateBar(wndCurrBar, targetUnit, tCurrBar)
			end
			
			local bShowResBar = tFrameData.barStyles[4].showResBar
			local tHpAnchors = {wndContent:FindChild("HPBar"):GetAnchorPoints()}
			local nBottomAnchor = bShowResBar and 0.8 or 1
			
			if tHpAnchors ~= nBottomAnchor then
				wndContent:FindChild("HPBar"):SetAnchorPoints(tHpAnchors[1], tHpAnchors[2], tHpAnchors[3], nBottomAnchor)
			end
			
			if nFrameId == 1 then					
				mainWnd:FindChild("Selection"):Show(GameLib.GetTargetUnit() == GameLib.GetPlayerUnit() and true or false)
				mainWnd:BringChildToTop(mainWnd:FindChild("Selection"))
			end	
			--end new code--	
	
			---------------------------------------------------------------------------
			-- Interrupt Armor
			---------------------------------------------------------------------------
			local wndCCArmor = mainWnd:FindChild("CCArmorContainer")
			local nCCArmorValue = targetUnit:GetInterruptArmorValue()
			local nCCArmorMax = targetUnit:GetInterruptArmorMax()
			
			if nCCArmorMax == 0 or nCCArmorValue == nil or targetUnit == GameLib.GetPlayerUnit() then
				wndCCArmor:Show(false)
			else
				--OLD CC ARMOR
				--[[wndCCArmor:Show(true)
				if nCCArmorMax == -1 then -- impervious
					wndCCArmor:FindChild("CCArmorValue"):SetText("")
					wndCCArmor:FindChild("CCArmorSprite"):SetSprite("CRB_ActionBarSprites:sprAb_IntArm_Invulnerable")
				elseif nCCArmorValue == 0 and nCCArmorMax > 0 then -- broken
					wndCCArmor:FindChild("CCArmorValue"):SetText("")
					wndCCArmor:FindChild("CCArmorSprite"):SetSprite("CRB_ActionBarSprites:sprAb_IntArm_Broken")
				elseif nCCArmorMax > 0 then -- has armor, has value
					wndCCArmor:FindChild("CCArmorValue"):SetText(nCCArmorValue)
					wndCCArmor:FindChild("CCArmorSprite"):SetSprite("CRB_ActionBarSprites:sprAb_IntArm_Regular")
				end]]--
			
				--if nCCArmorValue < self.nLastCCArmorValue and nCCArmorValue ~= 0 and nCCArmorValue ~= -1 then
				--	wndCCArmor:FindChild("CCArmorFlash"):SetSprite("CRB_ActionBarSprites:sprAb_IntArm_Flash")
				--end
				
				if nCCArmorMax == -1 then -- impervious
					wndCCArmor:Show(true)
					wndCCArmor:FindChild("CCArmorValue"):SetText("")
					wndCCArmor:FindChild("CCArmorSprite"):SetSprite("PotatoSprites:IAInvuln")
				elseif nCCArmorMax > 0 then -- has armor, has value
					wndCCArmor:Show(true)
					wndCCArmor:FindChild("CCArmorValue"):SetText(nCCArmorValue)
					wndCCArmor:FindChild("CCArmorSprite"):SetSprite("PotatoSprites:IABacker")
				else
					wndCCArmor:Show(false)
				end
			end
			
			wndCCArmor:ToFront()
		end
	else
		mainWnd:Show(false)
		mainWnd:SetStyle("IgnoreMouse", true)
	end
end

function PotatoFrames:CreateCastbar(wndFrame, unitCaster)
	local nCastbarId = wndFrame:GetData().id
	local tCastBarData = self.tFrames[nCastbarId].castbarData

	local wndCastProgress = wndFrame:FindChild("CastProgress")
	local wndCastName = wndFrame:FindChild("CastName")
	local wndVulnerability = wndFrame:FindChild("Vulnerability")
		
	if editorMode then
		wndFrame:Show(true)
		wndCastProgress:Show(true)
		wndCastProgress:SetMax(10)
		wndCastProgress:SetProgress(10)
	else
		-- Casting Bar Update
		local nVulnerable = unitCaster:GetCCStateTimeRemaining(Unit.CodeEnumCCState.Vulnerability) 
		local bShowCasting = nVulnerable > 0
		local bEnableGlow = false
		local nZone = 0
		local nMaxZone = 0
		local nDuration = 0
		local nElapsed = 0
		local strSpellName = ""
		local nElapsed = 0
		local eType = Unit.CodeEnumCastBarType.None
		local strIcon = ""
		local strFillSprite = ""
		local strBaseSprite = ""
		local strGlowSprite = ""
	
		--local wndCastIcon = wndFrame:FindChild("CastingIcon")
		--local wndCastBase = wndFrame:FindChild("CastingBase")
	
		-- results for GetCastBarType can be:
		-- Unit.CodeEnumCastBarType.None
		-- Unit.CodeEnumCastBarType.Normal
		-- Unit.CodeEnumCastBarType.Telegraph_Backlash
		-- Unit.CodeEnumCastBarType.Telegraph_Evade
		if unitCaster:ShouldShowCastBar() and unitCaster:IsCasting() and (tCastBarData.showFrame == 1 or (tCastBarData.showFrame == 2 and self.bInCombat)) then
			eType = unitCaster:GetCastBarType()
	
			--[[if eType == Unit.CodeEnumCastBarType.Telegraph_Evade then
				strIcon = "CRB_TargetFramesprites:sprTF_CastIconEvade"
				strFillSprite = "sprTF_CastMeterRed"
				strBaseSprite = "CRB_TargetFramesprites:sprTF_CastBaseRed"
				strGlowSprite = "sprTF_CastMeterCapOrng"
			elseif eType == Unit.CodeEnumCastBarType.Telegraph_Backlash then
				strIcon = "CRB_TargetFramesprites:sprTF_CastIconInterrupt"
				strFillSprite = "sprTF_CastMeterRed"
				strBaseSprite = "CRB_TargetFramesprites:sprTF_CastBaseRed"
				strGlowSprite = "sprTF_CastMeterCapRed"
			else
				strIcon = ""
				strFillSprite = "sprTF_CastMeterRed"
				strBaseSprite = "CRB_TargetFramesprites:sprTF_CastBaseOrange"
				strGlowSprite = "sprTF_CastMeterCapRed"
			end]]--
	
			if eType ~= Unit.CodeEnumCastBarType.None then
	
				bShowCasting = true
				bEnableGlow = true
				nZone = 0
				nMaxZone = 1
				nDuration = unitCaster:GetCastDuration()
				nElapsed = unitCaster:GetCastElapsed()
				if wndCastProgress ~= nil then
					wndCastProgress:SetTickLocations(0, 100, 200, 300)
				end
	
				strSpellName = unitCaster:GetCastName()
			end
		end
		
		--MOO Moment of Opportunity
		if nVulnerable > 0 and (tCastBarData.showFrame == 1 or (tCastBarData.showFrame == 2 and self.bInCombat)) then
			wndVulnerability:Show(true)
			self.maxVuln[nCastbarId] = nVulnerable > self.maxVuln[nCastbarId] and nVulnerable or self.maxVuln[nCastbarId]
			wndVulnerability:SetMax(self.maxVuln[nCastbarId])
			wndVulnerability:SetProgress(nVulnerable)
		else
			wndVulnerability:Show(false)
			self.maxVuln[nCastbarId] = 0
		end
		
		wndFrame:Show(bShowCasting)
		if wndCastProgress ~= nil then
			wndCastProgress:Show(bShowCasting)
			wndCastName:Show(bShowCasting)
		end
	
		if bShowCasting and nDuration > 0 and nMaxZone > 0 then
			--wndCastIcon:SetSprite(nIcon)

			if wndCastProgress ~= nil then
				wndCastProgress:Show(bShowCasting)
				wndCastProgress:SetMax(nDuration)
				wndCastProgress:SetProgress(nElapsed)
				--wndCastProgress:EnableGlow(bEnableGlow)
				--wndCastProgress:SetFullSprite(strFillSprite)
				--wndCastProgress:SetGlowSprite(strGlowSprite)
				wndCastName:SetText(strSpellName)
				--wndCastBase:SetSprite(strBaseSprite)
			end
		end
	end
end
--function on gear change DO THIS; then it can be removed from PotatoFrames:OnFrame()
	--self.wndBars:FindChild("CostumeWindow"):SetCostume(GameLib.GetPlayerUnit())

function PotatoFrames:CreateBuffs(wndWindow, unit)
	if wndWindow:GetData() ~= nil then
		local nBuffId = wndWindow:GetData().id
		local tBuffData = self.tFrames[nBuffId][wndWindow:GetData().type .. "Data"]
		
		local strType = string.gsub(wndWindow:GetName(), "Frame", "Bar")
		
		if tBuffData.showFrame == 1 or (tBuffData.showFrame == 2 and self.bInCombat) or editorMode then
			wndWindow:FindChild(strType):SetUnit(unit)
			wndWindow:Show(true)
		else
			wndWindow:Show(false)
		end
	end
end

function PotatoFrames:OnGenerateTooltip(wndHandler, wndControl, eType, spl)
	if wndControl == wndHandler then
		return nil
	end
	Tooltip.GetBuffTooltipForm(self, wndControl, spl)
end	

function PotatoFrames:FormatNumber(nNumber)
	local strNum = "ERR"
	
	if nNumber / 1000000 >= 1 then
		strNum = string.format("%.1fm", nNumber/1000000)
	elseif nNumber / 1000 >= 1 then
		strNum = string.format("%.1fk",nNumber/1000)
	else
		strNum = math.floor(nNumber)
	end

	return string.gsub(strNum .. "", "%.0", "")
end
	
	
function PotatoFrames:MouseOverTest(wndHandler, wndControl, x, y)
	--Print("MouseOver: " .. wndHandler:GetName() .. ", " .. wndControl:GetName() .. ", " .. x .. ", " .. y)
end

function PotatoFrames:MouseDownTest(wndHandler, wndControl, eButton, x, y, bDouble)
	local elementName = wndControl:GetName()
	local frameId = wndHandler:GetData() ~= nil and wndHandler:GetData().id or nil
	local elementTarget = wndHandler:GetData() ~= nil and wndHandler:GetData().unit or nil
	local PLib = Apollo.GetAddon("PotatoLib")

	--[[if not wndHandler:FindChild("EditorCover"):IsVisible() and eButton == 1 then  --Rightclick TODO: For editor v3.0
		--Print(wndHandler:GetAnchorOffsets())
		--Print("MouseClick: " .. wndHandler:GetName() .. ", " .. wndControl:GetName() .. ", " .. eButton .. ", " .. x .. ", " .. y)
	end]]--
	
	if wndHandler:GetName() == "Unitframe" then
		if elementName == "SimpleTarget" or elementName == "Content" and eButton == 0 then --Left clicked on a frame
			if editorMode then
				--Do element selected stuff.
				self:PopulateEditor(wndHandler, wndControl)
			else
				if elementTarget or elementTarget ~= nil then
					--Target unit
					GameLib.SetTargetUnit(elementTarget)
				end
			end
		end	 
		
		if elementName == "Content" and eButton == 1 then -- Right clicked on a frame
			if not editorMode then
				if frameId < 5 then --Rightclicked on Portrait
					Event_FireGenericEvent("GenericEvent_NewContextMenuPlayerDetailed", wndHandler, elementTarget:GetName(), elementTarget)
				elseif frameId == 5 or frameId == 6 then --TODO: Make a 2nd rightclick close the BG frame
					if self.tFrames[frameId].window:FindChild("StanceMenuBG") then
						self.tFrames[frameId].window:FindChild("StanceMenuBG"):Destroy()
					end
					self.wndPetStance = Apollo.LoadForm("PotatoFrames.xml", "StanceMenuBG", self.tFrames[frameId].window, self)
					self.wndPetStance:SetData({id=frameId})
					for idx=1, 5 do
						local nCurrPetStance= Pet_GetStance(self.tFrames[frameId].window:GetData().unit:GetId())
	
						self.wndPetStance:FindChild("Stance"..idx):FindChild("StanceText"):SetTextColor(idx == nCurrPetStance and "FFFFFF00" or "FFFFFFFF")
						self.wndPetStance:FindChild("Stance"..idx):ChangeArt(idx == nCurrPetStance and "CRB_Basekit:kitBtn_List_HoloSort" or "CRB_Basekit:kitBtn_List_Holo")
					end
					self.wndPetStance:Show(true) 
				end			
			end
		end
	elseif wndHandler:GetName() == "Castbar" then	--CastBar
		if editorMode and wndControl:GetName() == "Content" then
			self:PopulateEditor(wndHandler, wndControl)
		end
	elseif editorMode and wndHandler:GetName():sub(5) == "BuffFrame" and wndControl:GetName():sub(5) == "BuffBar" then
		self:PopulateEditor(wndHandler, wndControl)
	elseif editorMode and wndHandler:GetName() == "CombatNotice" then
		self:PopulateEditor(wndHandler, wndControl)
	end
end

function PotatoFrames:OnEnterTextField(arg1, arg2, locX, locY)
	--[[if string.find(arg2:GetName(), "Txt") then
		--Print("arg1: "..arg1:GetName())
		--Print("arg2: "..arg2:GetName())
		self.tempData = arg1:GetData()
		bHovering = true
	end]]--
end

function PotatoFrames:OnExitTextField(arg1, arg2, locX, locY)
	--[[if string.find(arg2:GetName(), "Txt") then
		arg2:SetText("done")
		bHovering = false
	end]]--
end

function PotatoFrames:PopulateEditor(wndHandler)
	local PLib = Apollo.GetAddon("PotatoLib")
	PLib.wndCustomize:Show(true)
	PLib:ElementSelected(wndHandler, self)
	if #PLib.wndCustomize:FindChild("EditorContent"):GetChildren() > 0 then
		PLib.wndCustomize:FindChild("EditorContent"):DestroyChildren()
	end
	
	self.wndCustomize = Apollo.LoadForm("PotatoFrames.xml", "Castbar", PLib.wndCustomize:FindChild("EditorContent"), self) --Ghetto fix
	PLib.wndCustomize:FindChild("EditorContent"):DestroyChildren() --Oh well.

	if wndHandler:GetName() == "Unitframe" then
		local tFrameIdentifier = wndHandler:GetData() --only id for now --FAR future will be {frameType,frameName}
		local nFrameId = wndHandler:GetData().id
		local tFrameData = self.tFrames[nFrameId].frameData
		
		if nFrameId >= 1 and nFrameId <= 6 then
			--Populate PotatoLib editor frame; Set frame identifier; Set title
			self.wndCustomize = Apollo.LoadForm("PotatoFrames.xml", "UnitframeCustomize", PLib.wndCustomize:FindChild("EditorContent"), self)
			self.wndCustomize:SetData(tFrameIdentifier) -- only id for now
			PLib.wndCustomize:FindChild("Title"):SetText(ktDefaultFrames[nFrameId].name .. " Settings")
			
			--Set portrait type selected from tFrames[idx].frameData
			self.wndCustomize:FindChild("ShowPortrait"):FindChild("Options"):SetRadioSel("PortraitType", tFrameData.portraitType)
			--Set icon visibility selected from tFrames[idx].frameData
			self.wndCustomize:FindChild("ShowIcons"):FindChild("Options"):SetRadioSel("ShowIcons", tFrameData.showIcons and 1 or 2)
			--Set frame visibility selected from tFrames[idx].frameData
			self.wndCustomize:FindChild("ShowFrame"):FindChild("Options"):SetRadioSel("ShowFrame", tFrameData.showFrame)
			--Set background visibility and color selected from tFrames[idx].frameData
			self.wndCustomize:FindChild("Background"):FindChild("EnableBtn"):SetCheck(tFrameData.background.show)
			self.wndCustomize:FindChild("Background"):FindChild("Color"):SetBGColor("FF"..tFrameData.background.color)
			self.wndCustomize:FindChild("Background"):FindChild("HexText"):SetText(tFrameData.background.color)
			--Set border visibility and color selected from tFrames[idx].frameData
			self.wndCustomize:FindChild("Border"):FindChild("EnableBtn"):SetCheck(tFrameData.border.show)
			self.wndCustomize:FindChild("Border"):FindChild("Color"):SetBGColor("FF"..tFrameData.border.color)
			self.wndCustomize:FindChild("Border"):FindChild("HexText"):SetText(tFrameData.border.color)
									
			for idx=1, #tFrameData.barStyles do
				local wndCurrBar = self.wndCustomize:FindChild(tFrameData.barStyles[idx].name.."Bar")
				local tCurrBar = tFrameData.barStyles[idx]
				local bCustomColor = tCurrBar.colorType == "customcolor"
				local nBarGrowth = tCurrBar.barGrowth ~= nil and tCurrBar.barGrowth or 0
				
				if wndCurrBar ~= nil then
					wndCurrBar:SetData({frame=nFrameId,bar=idx})
					
					wndCurrBar:FindChild("Header1"):FindChild("Button"):ChangeArt("CRB_Basekit:kitBtn_ScrollHolo_UpLarge")
					wndCurrBar:SetAnchorOffsets(0, 0, 0, 30)
					
					PotatoLib:SetSprite(wndCurrBar:FindChild("BarTexture"):FindChild("CurrentVal"),tCurrBar.texture)
					wndCurrBar:FindChild("BarTexture"):FindChild("CurrentVal"):SetText(tCurrBar.texture == "WhiteFill" and "Flat" or tCurrBar.texture)
					wndCurrBar:FindChild("BarTexture"):FindChild("CurrentVal"):SetBGColor("FF"..tCurrBar.color)

					wndCurrBar:FindChild("BarGrowth"):FindChild("Options"):SetRadioSel("BarGrowth", nBarGrowth+1)
					
					wndCurrBar:FindChild("Color"):SetBGColor("FF"..tCurrBar.color)
					wndCurrBar:FindChild("Color"):Show(bCustomColor)
					wndCurrBar:FindChild("HexText"):SetText(tCurrBar.color)
					wndCurrBar:FindChild("ColorType"):SetRadioSel("ColorType", bCustomColor and 2 or 1)
					wndCurrBar:FindChild("ClassColorCover"):Show(not bCustomColor)
					wndCurrBar:FindChild("Transparency"):SetValue(tCurrBar.transparency)
					wndCurrBar:FindChild("TransAmt"):SetText(tCurrBar.transparency.."%")
					if wndCurrBar:GetName() == "RPBar" then
						wndCurrBar:FindChild("ShowBar"):FindChild("Options"):SetRadioSel("ShowResBar", tCurrBar.showResBar and 1 or 2)
					end
					for idx2=1, 3 do
						local ktPos = {"Left", "Mid", "Right"}
						local strTextLoc = "text"..ktPos[idx2]
						local tCurrText = tCurrBar[strTextLoc]
						
						wndCurrBar:FindChild(strTextLoc):SetData({nFrameId, idx})
						
						local nType = tCurrText.type
						local wndTypeOpts = wndCurrBar:FindChild(strTextLoc):FindChild("TxtType")
						wndTypeOpts:FindChild("CurrentVal"):SetText(tTextType[nType])
						wndTypeOpts:FindChild("LeftScroll"):SetBGColor(nType > 0 and "FFFFFFFF" or "FF555555")
						wndTypeOpts:FindChild("RightScroll"):SetBGColor(nType <= #tTextType and "FFFFFFFF" or "FF555555")

						local strBase = tCurrText.font.base
						local nBaseId = PotatoLib:GetFontKeyByBase(strBase)
						local ktFontData = PotatoLib:GetFontDataByBase(strBase)						
						local wndFontOpts = wndCurrBar:FindChild(strTextLoc):FindChild("TxtFont")
						wndFontOpts:FindChild("CurrentVal"):SetText(ktFontData.name)
						wndFontOpts:FindChild("CurrentVal"):SetFont(ktFontData.defaultStr)
						wndFontOpts:FindChild("LeftScroll"):SetBGColor(nBaseId > 1 and "FFFFFFFF" or "FF555555")
						wndFontOpts:FindChild("RightScroll"):SetBGColor(nBaseId < #PotatoLib.ktFonts and "FFFFFFFF" or "FF555555")
						
						local strSize = tCurrText.font.size
						local nSizeId = PotatoLib:GetSizeKeyByBaseSize(nBaseId,strSize)
						local wndSizeOpts = wndCurrBar:FindChild(strTextLoc):FindChild("TxtSize")
						wndSizeOpts:FindChild("TextValue"):SetText(strSize)
						wndSizeOpts:FindChild("TextValueDown"):SetBGColor(nSizeId > 1 and "FFFFFFFF" or "FF555555")
						wndSizeOpts:FindChild("TextValueUp"):SetBGColor(nSizeId < #PotatoLib.ktFonts[nBaseId].sizes and "FFFFFFFF" or "FF555555")
																	
						local strProps = tCurrText.font.props
						local wndPropOpts = wndCurrBar:FindChild(strTextLoc):FindChild("TxtProps")
						wndPropOpts:FindChild("Bold"):Enable(false)
						wndPropOpts:FindChild("BigBold"):Enable(false)
						wndPropOpts:FindChild("Italic"):Enable(false)
						wndPropOpts:FindChild("Outline"):Enable(false)
						wndPropOpts:SetRadioSel("TxtWeight", 0)
						wndPropOpts:FindChild("Outline"):SetCheck(false)

						for key,val in pairs(PotatoLib.ktFonts[nBaseId].sizeProp[strSize..""]) do
							if val == "B" then
								wndPropOpts:FindChild("Bold"):Enable(true)
							elseif val == "BB" then
								wndPropOpts:FindChild("BigBold"):Enable(true)
							elseif val == "BO" then
								wndPropOpts:FindChild("Bold"):Enable(true)
								wndPropOpts:FindChild("Outline"):Enable(true)
							elseif val == "BBO" then
								wndPropOpts:FindChild("BigBold"):Enable(true)
								wndPropOpts:FindChild("Outline"):Enable(true)
							elseif val == "I" then
								wndPropOpts:FindChild("Italic"):Enable(true)
							elseif val == "O" then
								wndPropOpts:FindChild("Outline"):Enable(true)
							end
						end
						local _, count = string.gsub(strProps, "I", "")
						if count == 1 then
							wndPropOpts:SetRadioSel("TxtWeight", 3)
							wndPropOpts:FindChild("Outline"):Enable(false)
						else
							_, count = string.gsub(strProps, "B", "")
							if count > 0 then
								wndPropOpts:SetRadioSel("TxtWeight", count)
							else
								wndPropOpts:SetRadioSel("TxtWeight", 0)
							end
						end
						_, count = string.gsub(strProps, "O", "")
						wndPropOpts:FindChild("Outline"):SetCheck(count == 1)
					end
				else
					local strTest = bCustomColor and "true" or "false"
					Print(tFrameData.barStyles[idx].name.."[PotatoUI] Bar not found. Custom color:" .. strTest .. " Please report this bug on Curse.")
				end
			end
			local nBottom = self.wndCustomize:ArrangeChildrenVert(0)
			self.wndCustomize:SetAnchorOffsets(0,0,0,nBottom)
			PLib.wndCustomize:FindChild("EditorContent"):ArrangeChildrenVert(0)
		end
		self.wndCustomize:Show(true)
	end
	
	if wndHandler:GetName() == "Castbar" then
		local nCastbarId = wndHandler:GetData().id
		local tCastbarIdentifier = wndHandler:GetData() --TODO: only id for now --FAR future will be {frameType,frameName} check other comments like this
		local tCastbarData = self.tFrames[nCastbarId].castbarData
		
		--Populate PotatoLib editor frame; Set frame identifier; Set title
		self.wndCustomize = Apollo.LoadForm("PotatoFrames.xml", "CastbarCustomize", PLib.wndCustomize:FindChild("EditorContent"), self)
		self.wndCustomize:SetData(tCastbarIdentifier) -- only id for now
		PLib.wndCustomize:FindChild("Title"):SetText(ktDefaultCastbars[nCastbarId].name .. " Settings")
		
		--Set frame visibility selected from tFrames[idx].frameData
		self.wndCustomize:FindChild("ShowFrame"):FindChild("Options"):SetRadioSel("ShowFrame", tCastbarData.showFrame)
	end
	
	if string.sub(wndHandler:GetName(), 5) == "BuffFrame" then
		local nBuffId = wndHandler:GetData().id
		local tBuffIdentifier = wndHandler:GetData()
		local tBuffData = wndHandler:GetName():sub(1, 4) == "Bene" and self.tFrames[nBuffId].buffData or self.tFrames[nBuffId].debuffData

		local strType = wndHandler:GetName():sub(1, 4) == "Bene" and "Buff" or "Debuff"
		
		--Populate PotatoLib editor frame; Set frame identifier; Set title
		self.wndCustomize = Apollo.LoadForm("PotatoFrames.xml", "BuffCustomize", PLib.wndCustomize:FindChild("EditorContent"), self)
		self.wndCustomize:SetData(tBuffIdentifier) -- only id for now
		PLib.wndCustomize:FindChild("Title"):SetText(ktDefaultFrames[nBuffId].name:gsub("Frame","") .. strType .. " Settings")
		
		--Set frame visibility selected from tFrames[idx].buffData
		self.wndCustomize:FindChild("ShowFrame"):FindChild("Options"):SetRadioSel("ShowFrame", tBuffData.showFrame)
		
		--Set buff alignment from tFrames[idx].buffData/debuffData
		self.wndCustomize:FindChild("FillDirection"):FindChild("Options"):SetRadioSel("BuffPos", tBuffData.align)
	end
	
	if wndHandler:GetName() == "CombatNotice" then
		--Populate PotatoLib editor frame; Set frame identifier
		self.wndCustomize = Apollo.LoadForm("PotatoFrames.xml", "CmbNoteCustomize", PLib.wndCustomize:FindChild("EditorContent"), self)
		self.wndCustomize:SetData({id=1,type="cmbnote"})
		PLib.wndCustomize:FindChild("Title"):SetText("Combat Indicator Settings")
		
		--Set frame visibility selected from tFrames[idx].frameData
		self.wndCustomize:FindChild("ShowFrame"):FindChild("Options"):SetRadioSel("ShowFrame", self.bShowCmbNote and 1 or 2)
	end
	
	local nX1, nY1, nX2, nY2 = wndHandler:GetAnchorOffsets()
	local nAX1, nAY1, nAX2, nAY2 = wndHandler:GetAnchorPoints()
	
	local nScreenX, nScreenY = Apollo.GetScreenSize()
	if self.wndCustomize then
		if self.wndCustomize:FindChild("XPos") ~= nil then
			self.wndCustomize:FindChild("XPos"):SetText((nAX1*nScreenX)+nX1)
			self.wndCustomize:FindChild("YPos"):SetText((nAY1*nScreenY)+nY1)
			self.wndCustomize:FindChild("Width"):SetText(nX2-nX1)
			self.wndCustomize:FindChild("Height"):SetText(nY2-nY1)
		end
	end
end

---------------------------------------------------------------------------------------------------
-- UnitframeCustomize Functions
---------------------------------------------------------------------------------------------------

----------------------SECTION OPTIONS----------------------

function PotatoFrames:ToggleSectionVisibility( wndHandler, wndControl, eMouseButton )
	local wndCurrBar = wndHandler:GetParent():GetParent()
	local nPossHeight = wndCurrBar:ArrangeChildrenVert(0)
	local PLib = Apollo.GetAddon("PotatoLib")
	
	local bShown = wndCurrBar:GetHeight() < nPossHeight
	
	local tOffsets = {wndCurrBar:GetAnchorOffsets()}
	
	if bShown then
		wndCurrBar:SetAnchorOffsets(tOffsets[1], tOffsets[2], tOffsets[3], tOffsets[2] + nPossHeight)
		wndHandler:ChangeArt("CRB_Basekit:kitBtn_ScrollHolo_DownLarge")
	else
		wndCurrBar:SetAnchorOffsets(tOffsets[1], tOffsets[2], tOffsets[3], tOffsets[2] + 30)
		wndHandler:ChangeArt("CRB_Basekit:kitBtn_ScrollHolo_UpLarge")
	end
	local nBottom = self.wndCustomize:ArrangeChildrenVert()
	self.wndCustomize:SetAnchorOffsets(0,0,0,nBottom)
	PLib.wndCustomize:FindChild("EditorContent"):ArrangeChildrenVert(0)
end

----------------------MAIN FRAME OPTIONS----------------------

function PotatoFrames:OnShowChange( wndHandler, wndControl, eMouseButton )
	local nFrameId = self.wndCustomize:GetData().id
	local strFrameType = self.wndCustomize:GetData().type
	local nShowFrame = wndHandler:GetParent():GetRadioSel("ShowFrame")

	self.tFrames[nFrameId][strFrameType.."Data"].showFrame = nShowFrame
end

function PotatoFrames:OnShowCmbNoteChange( wndHandler, wndControl, eMouseButton )
	self.bShowCmbNote = wndHandler:GetParent():GetRadioSel("ShowFrame") == 1 and true or false
end

function PotatoFrames:OnChangePortrait( wndHandler, wndControl, eMouseButton )
	local nFrameId = self.wndCustomize:GetData().id
	local nPortraitType = wndHandler:GetParent():GetRadioSel("PortraitType") --1 = 3D, 2 = 2D, 3 = Class, 4 = Disabled
	
	self.tFrames[nFrameId].frameData.portraitType = nPortraitType
	self.tFrames[nFrameId].window:FindChild("Portrait"):SetAnimated(nPortraitType == 1)
end

function PotatoFrames:OnChangeIcons( wndHandler, wndControl, eMouseButton )
	local nFrameId = self.wndCustomize:GetData().id
	self.tFrames[nFrameId].frameData.showIcons = wndHandler:GetParent():GetRadioSel("ShowIcons") == 1 and true or false --1 = Shown, 2 = Not Shown
end

function PotatoFrames:ShowBG(wnd, bShow)
	wnd:SetStyle("Picture", bShow)
end

function PotatoFrames:OnChangeBG( wndHandler, wndControl, eMouseButton )
	local nFrameId = self.wndCustomize:GetData().id
	local bCheck = wndHandler:IsChecked()
		
	self.tFrames[nFrameId].frameData.background.show = bCheck
	
	self:ShowBG(self.tFrames[nFrameId].window:FindChild("Content"), bCheck)
	self:ShowBG(self.tFrames[nFrameId].window:FindChild("SimpleTarget"), bCheck)
end

function PotatoFrames:ShowBorder(wnd, wndContent, tBorderData, bShow)
	local nTrans = tBorderData.transparency
	local strColor = tBorderData.color
	local tBorderColor = PotatoLib:HexStr2ColorTable(PotatoLib:PercentToHex(nTrans)..strColor)
	
	local tPointFormat = {{0,0,0,1},{0,0,1,0},{1,0,1,1},{0,1,1,1}}
	for idx=1,4 do
		local tPixie = wnd:GetPixieInfo(idx)
		tPixie.cr = bShow and tBorderColor or {a=0,r=0,g=0,b=0}
		wnd:UpdatePixie(idx, tPixie)
		--[[for idx2,val in pairs(tPixie.loc.fPoints) do
			tPixie.loc.fPoints[idx] = tPointFormat.fPoints[idx2]*nBorderSize
		end]]--
	end
end

function PotatoFrames:OnChangeBorder( wndHandler, wndControl, eMouseButton )
	local nFrameId = self.wndCustomize:GetData().id
	local bCheck = wndHandler:IsChecked()
	
	local wndMain = self.tFrames[nFrameId].window
	local wndContent = self.tFrames[nFrameId].window:FindChild("Content")
	local tBorderData = self.tFrames[nFrameId].frameData.border

	self.tFrames[nFrameId].frameData.border.show = bCheck

	self:ShowBorder(wndMain, wndContent, tBorderData, bCheck)
end

function PotatoFrames:TxtPositionChanged( wndHandler, wndControl, strPos )
	local strChange = wndHandler:GetName()
	local strFrameType = self.wndCustomize:GetData().type
	
	local wndTarget = nil
	
	if strFrameType == "cmbnote" then
		Print("IN HERE")
		wndTarget = self.wndCombatNotice
	else
		local nFrameId = self.wndCustomize:GetData().id
		wndTarget = self.tFrames[nFrameId][tWindowTypeKey[strFrameType]]
	end
	
	local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()
	local nAX1, nAY1, nAX2, nAY2 = wndTarget:GetAnchorPoints()

	local nWidth = nX2-nX1
	local nHeight = nY2-nY1
	local nScreenX, nScreenY = Apollo.GetScreenSize()

	strPos = string.gsub(strPos, "[^0-9.]", "")
	if #strPos > 1 and string.sub(strPos, 1, 1) == "0" then
		strPos = string.gsub(strPos, "0", "", 1)
	end
	
	if strPos == "" then
		strPos = "0"
	end

	if strChange == "XPos" then
		wndTarget:SetAnchorOffsets(strPos-(nAX1*nScreenX), nY1, strPos-(nAX2*nScreenX)+nWidth, nY2)
	elseif strChange == "YPos" then
		wndTarget:SetAnchorOffsets(nX1, strPos-(nAY1*nScreenY), nX2, strPos-(nAY2*nScreenY)+nHeight)
	end
	
	wndHandler:SetText(strPos)
	wndHandler:SetSel(#strPos,#strPos)
end

function PotatoFrames:TxtHWChanged( wndHandler, wndControl, strHW )
	local nFrameId = self.wndCustomize:GetData().id
	local strFrameType = self.wndCustomize:GetData().type
	local strChange = wndHandler:GetName()
	
	local wndTarget = self.tFrames[nFrameId][tWindowTypeKey[strFrameType]]
	
	local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()
	local nAX1, nAY1, nAX2, nAY2 = wndTarget:GetAnchorPoints()
	
	strHW = string.gsub(strHW, "[^0-9.]", "")
	if #strHW > 1 and string.sub(strHW, 1, 1) == "0" then
		strHW = string.gsub(strHW, "0", "", 1)
	end
	
	if strHW == "" then
		strHW = "0"
	end	
		
	if strChange == "Width" then
		wndTarget:SetAnchorOffsets(nX1, nY1, nX1+strHW, nY2)
	elseif strChange == "Height" then
		wndTarget:SetAnchorOffsets(nX1, nY1, nX2, nY1+strHW)
	end	
	
	wndHandler:SetText(strHW)
	wndHandler:SetSel(#strHW,#strHW)
end
----------------------BAR OPTIONS----------------------

function PotatoFrames:OnChangeGrowth( wndHandler, wndControl, eMouseButton )
	local tLocationData = wndHandler:GetParent():GetParent():GetParent():GetData()
	
	local nGrowth = wndHandler:GetParent():GetRadioSel("BarGrowth") - 1
	self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar].barGrowth = nGrowth
end

function PotatoFrames:OnChangeColorType( wndHandler, wndControl, eMouseButton )
	local tLocationData = wndHandler:GetParent():GetParent():GetParent():GetData()
	
	local nColorType = wndHandler:GetParent():GetRadioSel("ColorType") --1 = Class Color, 2 = Custom Color
	local strNonCustomType = tLocationData.bar == 4 and "resourcecolor" or "classcolor"
	
	local tCurrBar = self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar]
	
	wndHandler:GetParent():GetParent():FindChild("ClassColorCover"):Show(nColorType == 1)
	tCurrBar.colorType = nColorType == 1 and strNonCustomType or "customcolor"
	self.wndCustomize:FindChild(tCurrBar.name.."Bar"):FindChild("Color"):Show(nColorType ~= 1)
	self.wndCustomize:FindChild(tCurrBar.name.."Bar"):FindChild("Color"):SetBGColor("FF"..tCurrBar.color)
end

local function OnSetBarColorUpdate(tLocationData)
	local self = Apollo.GetAddon("PotatoFrames")
	local tCurrBar = self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar]
	
	tCurrBar.color = PotatoFrames:Convert_CColor_To_String(daCColor)
	self.wndCustomize:FindChild(tCurrBar.name.."Bar"):FindChild("Color"):SetBGColor("FF"..tCurrBar.color)
	self.wndCustomize:FindChild(tCurrBar.name.."Bar"):FindChild("HexText"):SetText(tCurrBar.color)
end

function PotatoFrames:OnSetBarColor( wndHandler, wndControl, eMouseButton )
	local tLocationData = wndHandler:GetParent():GetParent():GetParent():GetData()

	if ColorPicker then ColorPicker.AdjustCColor(daCColor, false, OnSetBarColorUpdate, tLocationData) else Print("[Potato UI] ColorPicker addon is not installed, please redownload/install PotatoUI") end
end

function PotatoFrames:BarTextureScroll( wndHandler, wndControl )
	local tLocationData = wndControl:GetParent():GetParent():GetParent():GetData()
	
	local tTextures = {
		[1] = "Aluminum", Aluminum = 1,
		[2] = "Bantobar", Bantobar = 2,
		[3] = "Charcoal", Charcoal = 3,
		[4] = "Striped", Striped = 4,
		[5] = "Minimalist", Minimalist = 5,
		[6] = "Smooth", Smooth = 6,
		[7] = "WhiteFill", WhiteFill = 7,
	}

	if wndControl:GetParent():GetName() == "BarType" then
		local nCurrBar = tTextures[self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar].texture]
		
		if wndHandler:GetName() == "RightScroll" then
			nCurrBar = nCurrBar == #tTextures and 1 or (nCurrBar + 1)
		elseif wndHandler:GetName() == "LeftScroll" then
			nCurrBar = nCurrBar == 1 and #tTextures or (nCurrBar - 1)
		end
		self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar].texture = tTextures[nCurrBar]
		PotatoLib:SetSprite(wndControl:GetParent():FindChild("CurrentVal"), tTextures[nCurrBar])
		wndControl:GetParent():FindChild("CurrentVal"):SetText(nCurrBar == tTextures["WhiteFill"] and "Flat" or tTextures[nCurrBar])
	end
end

function PotatoFrames:TextOptScroll( wndHandler, wndControl )
	local tLocationData = wndControl:GetParent():GetParent():GetParent():GetParent():GetData()
	local strTextLoc = wndControl:GetParent():GetParent():GetName()
	
	local nTextVal = self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar][strTextLoc].type
	
	if wndHandler:GetName() == "RightScroll" then
		if nTextVal  < #tTextType then
			self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar][strTextLoc].type = nTextVal + 1
			wndControl:GetParent():FindChild("CurrentVal"):SetText(tTextType[nTextVal + 1])
			if nTextVal + 1 == #tTextType then
				wndHandler:SetBGColor("FF555555")
			else
				wndHandler:GetParent():FindChild("LeftScroll"):SetBGColor("FFFFFFFF")
			end
		end
	elseif wndHandler:GetName() == "LeftScroll" then
		if nTextVal > 0 then
			self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar][strTextLoc].type = nTextVal - 1
			wndControl:GetParent():FindChild("CurrentVal"):SetText(tTextType[nTextVal - 1])
			if nTextVal - 1 == 0 then
				wndHandler:SetBGColor("FF555555")
			else
				wndHandler:GetParent():FindChild("RightScroll"):SetBGColor("FFFFFFFF")
			end
		end
	end
end

function PotatoFrames:FontScroll( wndHandler, wndControl )
	local tLocationData = wndControl:GetParent():GetParent():GetParent():GetParent():GetParent():GetData()
	local strTextLoc = wndControl:GetParent():GetParent():GetParent():GetName()
	local tCurrBar = self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar]
	local wndCurrBar = self.tFrames[tLocationData.frame].window
	
	local tFontData = tCurrBar[strTextLoc].font
	local nBaseKey = nil
	
	for key,val in pairs(PotatoLib.ktFonts) do
		if tFontData.base == val.base then
			nBaseKey = key
		end
	end
	
	if nBaseKey ~= nil then
		if wndHandler:GetName() == "RightScroll" and nBaseKey < #PotatoLib.ktFonts then	
			nBaseKey = nBaseKey + 1

			if nBaseKey == #PotatoLib.ktFonts then
				wndHandler:SetBGColor("FF555555")
			else
				wndHandler:GetParent():FindChild("LeftScroll"):SetBGColor("FFFFFFFF")
			end
		elseif wndHandler:GetName() == "LeftScroll" and nBaseKey > 1 then
			nBaseKey = nBaseKey - 1		
			
			if nBaseKey == 1 then
				wndHandler:SetBGColor("FF555555")
			else
				wndHandler:GetParent():FindChild("RightScroll"):SetBGColor("FFFFFFFF")
			end
		end
		
		wndControl:GetParent():FindChild("CurrentVal"):SetText(PotatoLib.ktFonts[nBaseKey].name)
		wndControl:GetParent():FindChild("CurrentVal"):SetFont(PotatoLib.ktFonts[nBaseKey].defaultStr)
		
		local wndSizeOpts = wndControl:GetParent():GetParent():FindChild("TxtSize")
		local strSize = PotatoLib.ktFonts[nBaseKey].defaultSettings.size
		local nSizeId = PotatoLib:GetSizeKeyByBaseSize(nBaseKey,strSize)		
		wndSizeOpts:FindChild("TextValue"):SetText(strSize)
		wndSizeOpts:FindChild("TextValueDown"):SetBGColor(nSizeId > 1 and "FFFFFFFF" or "FF555555")
		wndSizeOpts:FindChild("TextValueUp"):SetBGColor(nSizeId < #PotatoLib.ktFonts[nBaseKey].sizes and "FFFFFFFF" or "FF555555")
		
		local wndPropOpts = wndControl:GetParent():GetParent():GetParent():FindChild("TxtProps")
		wndPropOpts:FindChild("Bold"):Enable(false)
		wndPropOpts:FindChild("BigBold"):Enable(false)
		wndPropOpts:FindChild("Italic"):Enable(false)
		wndPropOpts:FindChild("Outline"):Enable(false)
		wndPropOpts:SetRadioSel("TxtWeight", 0)
		wndPropOpts:FindChild("Outline"):SetCheck(false)
		
		for key,val in pairs(PotatoLib.ktFonts[nBaseKey].sizeProp[strSize]) do
			if val == "B" then
				wndPropOpts:FindChild("Bold"):Enable(true)
			elseif val == "BB" then
				wndPropOpts:FindChild("BigBold"):Enable(true)
			elseif val == "BO" then
				wndPropOpts:FindChild("Bold"):Enable(true)
				wndPropOpts:FindChild("Outline"):Enable(true)
			elseif val == "BBO" then
				wndPropOpts:FindChild("BigBold"):Enable(true)
				wndPropOpts:FindChild("Outline"):Enable(true)
			elseif val == "I" then
				wndPropOpts:FindChild("Italic"):Enable(true)
			elseif val == "O" then
				wndPropOpts:FindChild("Outline"):Enable(true)
			end
		end		
		
		wndCurrBar:FindChild(tCurrBar.name..strTextLoc):SetFont(PotatoLib.ktFonts[nBaseKey].defaultStr)
		
		tCurrBar[strTextLoc].font = TableUtil:Copy(PotatoLib.ktFonts[nBaseKey].defaultSettings)
	else
		print("[PotatoUI] ERROR NBASEKEY")
	end
end

function PotatoFrames:IncrementFontSize( wndHandler, wndControl, eMouseButton )
	local tLocationData = wndControl:GetParent():GetParent():GetParent():GetParent():GetParent():GetData()
	local strTextLoc = wndControl:GetParent():GetParent():GetParent():GetName()
	local tCurrBar = self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar]
	local wndCurrBar = self.tFrames[tLocationData.frame].window
	
	local tFontData = tCurrBar[strTextLoc].font
	local nBaseKey = nil
	local nSizeKey = nil
	
	for key,val in pairs(PotatoLib.ktFonts) do
		if tFontData.base == val.base then
			nBaseKey = key
		end
	end
	
	if nBaseKey ~= nil and PotatoLib.ktFonts[nBaseKey] ~= nil then
		local tSizes = PotatoLib.ktFonts[nBaseKey].sizes
		for key,val in pairs(tSizes) do
			if tFontData.size.."" == val.."" then
				nSizeKey = key
			end
		end
		if nSizeKey ~= nil then
			if wndHandler:GetName() == "TextValueUp" and nSizeKey < #tSizes then	
				nSizeKey = nSizeKey + 1
				
				if nSizeKey == #tSizes then
					wndHandler:SetBGColor("FF555555")
				else
					wndHandler:GetParent():FindChild("TextValueDown"):SetBGColor("FFFFFFFF")
				end
			elseif wndHandler:GetName() == "TextValueDown" and nSizeKey > 1 then
				nSizeKey = nSizeKey - 1		
				
				if nSizeKey == 1 then
					wndHandler:SetBGColor("FF555555")
				else
					wndHandler:GetParent():FindChild("TextValueUp"):SetBGColor("FFFFFFFF")
				end
			end
			
			wndControl:GetParent():FindChild("TextValue"):SetText(PotatoLib.ktFonts[nBaseKey].sizes[nSizeKey])
			tCurrBar[strTextLoc].font.size = PotatoLib.ktFonts[nBaseKey].sizes[nSizeKey]	
					
			local wndPropOpts = wndControl:GetParent():GetParent():GetParent():FindChild("TxtProps")
			wndPropOpts:FindChild("Bold"):Enable(false)
			wndPropOpts:FindChild("BigBold"):Enable(false)
			wndPropOpts:FindChild("Italic"):Enable(false)
			wndPropOpts:FindChild("Outline"):Enable(false)
			wndPropOpts:SetRadioSel("TxtWeight", 0)
			
			for key,val in pairs(PotatoLib.ktFonts[nBaseKey].sizeProp[tFontData.size..""]) do
				if val == "B" then
					wndPropOpts:FindChild("Bold"):Enable(true)
				elseif val == "BB" then
					wndPropOpts:FindChild("BigBold"):Enable(true)
				elseif val == "BO" then
					wndPropOpts:FindChild("Bold"):Enable(true)
					wndPropOpts:FindChild("Outline"):Enable(true)
				elseif val == "BBO" then
					wndPropOpts:FindChild("BigBold"):Enable(true)
					wndPropOpts:FindChild("Outline"):Enable(true)
				elseif val == "I" then
					wndPropOpts:FindChild("Italic"):Enable(true)
				elseif val == "O" then
					wndPropOpts:FindChild("Outline"):Enable(true)
				end
			end
		else
			Print("[PotatoUI] ERROR NSIZEKEY")
		end
	else
		Print("[PotatoUI] ERROR NBASEKEY")
	end
end

function PotatoFrames:OnTxtWeight( wndHandler, wndControl, eMouseButton )
	local tLocationData = wndControl:GetParent():GetParent():GetParent():GetParent():GetData()
	local strTextLoc = wndControl:GetParent():GetParent():GetName()
	local tCurrBar = self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar]
	local wndCurrBar = self.tFrames[tLocationData.frame].window
	
	local tFontData = tCurrBar[strTextLoc].font
	local nBaseKey = nil
	local nSizeKey = nil
	local strProp = nil
	
	local tProps = {
		[0] = "",
		[1] = "B",
		[2] = "BB",
		[3] = "I"
	}
	
	local strWeight = wndHandler:GetName()
	local nWeight = wndHandler:GetParent():GetRadioSel("TxtWeight")
	strProp = tProps[nWeight]
	
	if nWeight == 3 then
		wndHandler:GetParent():FindChild("Outline"):Enable(false)
	else
		wndHandler:GetParent():FindChild("Outline"):Enable(true)
	end

	if wndHandler:GetParent():FindChild("Outline"):IsChecked() then
		strProp = strProp .. "O"
	end

	self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar][strTextLoc].font.props = strProp
end


function PotatoFrames:TransSliderChange( wndHandler, wndControl, fNewValue, fOldValue, bOkToChange )
	if wndHandler:GetParent():GetParent():GetName() == "BorderOptions" then
		local nFrameId = self.wndCustomize:GetData().id
		self.tFrames[nFrameId].window:SetBGColor(string.format("%x", (fNewValue/100)*255).."000000")

		wndControl:GetParent():FindChild("TransAmt"):SetText(math.floor(fNewValue).."%")
	else
		local tLocationData = wndControl:GetParent():GetParent():GetParent():GetData()
	
		self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar].transparency = math.floor(fNewValue)
		wndControl:GetParent():FindChild("TransAmt"):SetText(math.floor(fNewValue).."%")
	end
end

function PotatoFrames:OnChangeResBar( wndHandler, wndControl, eMouseButton )
	local tLocationData = wndHandler:GetParent():GetParent():GetParent():GetData()
	
	local nGrowth = wndHandler:GetParent():GetRadioSel("ShowResBar")
	self.tFrames[tLocationData.frame].frameData.barStyles[tLocationData.bar].showResBar = nGrowth == 1 and true or false
end

function PotatoFrames:WindowMove( wndHandler, wndControl, nOldLeft, nOldTop, nOldRight, nOldBottom )
	if editorMode and self.wndCustomize then
		local nFrameId = self.wndCustomize:GetData().id
		local strFrameType = self.wndCustomize:GetData().type
		local wndTarget = strFrameType ~= "nonframe" and self.tFrames[nFrameId][tWindowTypeKey[strFrameType]] or wndHandler
	
		local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()
		local nAX1, nAY1, nAX2, nAY2 = wndTarget:GetAnchorPoints()

		local nScreenX, nScreenY = Apollo.GetScreenSize()
		if self.wndCustomize:FindChild("XPos") ~= nil then
			self.wndCustomize:FindChild("XPos"):SetText(nX1+(nAX1*nScreenX))
			self.wndCustomize:FindChild("YPos"):SetText(nY1+(nAY1*nScreenY))
			self.wndCustomize:FindChild("Width"):SetText(nX2-nX1)
			self.wndCustomize:FindChild("Height"):SetText(nY2-nY1)
		end
	end
end

function PotatoFrames:OnSettingsBtn( wndHandler, wndControl, eMouseButton, nLastRelativeMouseX, nLastRelativeMouseY, bDoubleClick, bStopPropagation )
	Print("SETTINGS BTN")
end

function PotatoFrames:OnLockBtn( wndHandler, wndControl, eMouseButton, nLastRelativeMouseX, nLastRelativeMouseY, bDoubleClick, bStopPropagation )
	Print("LOCK BTN")
end


function PotatoFrames:OnResetBtn( wndHandler, wndControl, eMouseButton, nLastRelativeMouseX, nLastRelativeMouseY, bDoubleClick, bStopPropagation )
	Print("RESET BTN")
end

---------------------------------------------------------------------------------------------------
-- StanceMenuBG Functions
---------------------------------------------------------------------------------------------------

function PotatoFrames:OnDismissBtn( wndHandler, wndControl, eMouseButton )
	wndHandler:FindChild("YesNo"):Show(not wndHandler:FindChild("YesNo"):IsVisible())
	local frameId = wndHandler:GetParent():GetParent():GetParent():GetData().id --TODO: There has got be a better way
	
	if frameId == 5 then
		wndHandler:FindChild("DismissYes"):SetContentId(24)
	end
	if frameId == 6 then
		wndHandler:FindChild("DismissYes"):SetContentId(36)
	end
end

function PotatoFrames:OnStanceBtn( wndHandler, wndControl, eMouseButton )
	local frameId = wndHandler:GetParent():GetParent():GetData().id
	local nStance = string.gsub(wndHandler:GetName(), "Stance", "") + 0	
	
	Pet_SetStance(self.tFrames[frameId].window:GetData().unit:GetId(), nStance) -- 0 is for all pets. TODO: Make separate pet control
	self.wndPetStance:Show(false)
end

function PotatoFrames:OnDismissNoBtn( wndHandler, wndControl, eMouseButton )
	wndHandler:GetParent():Show(false)
end

function PotatoFrames:OnDismissYesCover( wndHandler, wndControl, eMouseButton )
	Sound.Play(2)
end

---------------------------------------------------------------------------------------------------
-- BuffCustomize Functions
---------------------------------------------------------------------------------------------------
function PotatoFrames:OnShowChange( wndHandler, wndControl, eMouseButton )
	local nFrameId = self.wndCustomize:GetData().id
	local strFrameType = self.wndCustomize:GetData().type
	local nShowFrame = wndHandler:GetParent():GetRadioSel("ShowFrame") --1 = 3D, 2 = 2D, 3 = Disabled

	self.tFrames[nFrameId][strFrameType.."Data"].showFrame = nShowFrame
end

function PotatoFrames:OnChangeBuffPos( wndHandler, wndControl, eMouseButton )
    local nFrameId = self.wndCustomize:GetData().id
	local strFrameType = self.wndCustomize:GetData().type --buff or debuff
	local strBeneHarm = strFrameType == "buff" and "Bene" or "Harm"
	local nBuffPos = wndHandler:GetParent():GetRadioSel("BuffPos") --1 = left, 2 = right
	local tBuffData = self.tFrames[nFrameId][strFrameType.."Data"]

	local xmlFramesXml = XmlDoc.CreateFromFile("PotatoFrames.xml")
	tTableData = xmlFramesXml:ToTable()
	
	for idx=1, #tTableData do
		if tTableData[idx].Name ~= nil then
			if tTableData[idx].Name == (strBeneHarm.."BuffFrame") then
				tTableData[idx][1][1].AlignBuffsRight = nBuffPos - 1
				self.tFrames[nFrameId][strFrameType.."Data"].align = nBuffPos
				local wndCurrBuffWnd = self.tFrames[nFrameId][strFrameType.."s"]
				local tTempPos = {
					anchors = {self.tFrames[nFrameId][strFrameType.."s"]:GetAnchorPoints()},
					offsets = {self.tFrames[nFrameId][strFrameType.."s"]:GetAnchorOffsets()}
				}
				
				self.tFrames[nFrameId][strFrameType.."s"]:DestroyChildren()
				self.tFrames[nFrameId][strFrameType.."s"] = Apollo.LoadForm(XmlDoc.CreateFromTable(tTableData), strBeneHarm.."BuffFrame", nil, self)
				self.tFrames[nFrameId][strFrameType.."s"]:FindChild("Border"):Show(true)
				self.tFrames[nFrameId][strFrameType.."s"]:FindChild("CustomizeBorder"):Show(true)
				self.tFrames[nFrameId][strFrameType.."s"]:SetData({id=nFrameId,type=strFrameType})
				self.tFrames[nFrameId][strFrameType.."s"]:FindChild("EditorCover"):SetText(tBuffData.name)
				self.tFrames[nFrameId][strFrameType.."s"]:SetAnchorPoints(unpack(tTempPos.anchors))
				self.tFrames[nFrameId][strFrameType.."s"]:SetAnchorOffsets(unpack(tTempPos.offsets))
				self.tFrames[nFrameId][strFrameType.."s"]:SetStyle("Sizable", true)
				self.tFrames[nFrameId][strFrameType.."s"]:SetStyle("Moveable", true)
				
				Apollo.GetAddon("PotatoLib").previousElement = self.tFrames[nFrameId][strFrameType.."s"]
				
				--self.newWnd = Apollo.LoadForm(XmlDoc.CreateFromTable(tTableData), strBeneHarm.."BuffFrame", nil, self)
				--self.newWnd = Apollo.LoadForm(XmlDoc.CreateFromTable(tTableData), "Unitframe", nil, self)
				--self.newWnd:Show(true)
			end
		end
	end
	xmlFramesXml = nil
end

function PotatoFrames:UpdateBuffPosition(wndWindow, nAlignment)
    local nFrameId = wndWindow:GetData().id
	local strFrameType = wndWindow:GetData().type --buff or debuff
	local tBuffData = self.tFrames[nFrameId][strFrameType.."Data"]
	
	local xmlFramesXml = XmlDoc.CreateFromFile("PotatoFrames.xml")
	if xmlFramesXml ~= nil then
		tTableData = xmlFramesXml:ToTable()
		
		for idx=1, #tTableData do
			if tTableData[idx].Name ~= nil then
				if tTableData[idx].Name == wndWindow:GetName() then
					tTableData[idx][1][1].AlignBuffsRight = nAlignment - 1
					self.tTableData = tTableData
					self.tFrames[nFrameId][strFrameType.."s"]:DestroyChildren()
					self.tFrames[nFrameId][strFrameType.."s"] = Apollo.LoadForm(XmlDoc.CreateFromTable(tTableData), wndWindow:GetName(), nil, self)
					self.tFrames[nFrameId][strFrameType.."s"]:SetData({id=nFrameId,type=strFrameType})
					self.tFrames[nFrameId][strFrameType.."s"]:FindChild("EditorCover"):SetText(tBuffData.name)
					self.tFrames[nFrameId][strFrameType.."s"]:SetAnchorPoints(unpack(tBuffData.anchors))
					self.tFrames[nFrameId][strFrameType.."s"]:SetAnchorOffsets(unpack(tBuffData.offsets))
					if editorMode then
						self.tFrames[nFrameId][strFrameType.."s"]:FindChild("EditorCover"):Show(true)
						self.tFrames[nFrameId][strFrameType.."s"]:FindChild("Border"):Show(true)
					end
					if Apollo.GetAddon("PotatoLib").previousElement ~= nil then
						local wndPrevElement = Apollo.GetAddon("PotatoLib").previousElement
						if string.match(wndPrevElement:GetName(), "BuffFrame") then
							if wndPrevElement:GetData().id == nFrameId and wndPrevElement:GetData().type == strFrameType then 
								Apollo.GetAddon("PotatoLib").previousElement = self.tFrames[nFrameId][strFrameType.."s"]
								self.tFrames[nFrameId][strFrameType.."s"]:FindChild("EditorCover"):Show(false)
								self.tFrames[nFrameId][strFrameType.."s"]:FindChild("CustomizeBorder"):Show(true)
							end
						end
					end
				end
			end
		end
		xmlFramesXml = nil
	end
end

-----------------------------------------------------------------------------------------------
-- PotatoFrames Instance
-----------------------------------------------------------------------------------------------
local PotatoFramesInst = PotatoFrames:new()
PotatoFramesInst:Init()