-----------------------------------------------------------------------------------------------
-- Client Lua Script for PotatoSprint
-- Copyright (c) Tyler T. Hardy. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
 
-----------------------------------------------------------------------------------------------
-- PotatoSprint Module Definition
-----------------------------------------------------------------------------------------------
local PotatoSprint = {} 

-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
-- e.g. local kiExampleVariableMax = 999
local eEnduranceFlash =
{
	EnduranceFlashZero = 1,
	EnduranceFlashOne = 2,
	EnduranceFlashTwo = 3,
	EnduranceFlashThree = 4,
}

local showFrame = 1
local showFull = 1
local editorMode = false
-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function PotatoSprint:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function PotatoSprint:Init()
    Apollo.RegisterAddon(self)
end
 
-----------------------------------------------------------------------------------------------
-- PotatoSprint OnLoad
-----------------------------------------------------------------------------------------------
function PotatoSprint:OnLoad()
    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)
    --Apollo.RegisterEventHandler("VarChange_FrameCount", 		"OnFrame", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", 			"OnEnteredCombat", self)
	Apollo.RegisterTimerHandler("FrameUpdate", 					"OnFrame", self)

	Apollo.CreateTimer("FrameUpdate", 0.013, true)

	Apollo.RegisterEventHandler("PotatoEditor",					"EditorModeToggle", self)
	Apollo.RegisterEventHandler("PotatoReset",					"ResetFrames", self)
	
    -- load our forms
    
	--[[self.wndMain  = Apollo.LoadForm("PotatoSprint.xml", "Form", nil, self)
	self.wndContent = self.wndMain:FindChild("Content")
	self.wndMain:Show(true)]]--
	
	self.wndTwo = Apollo.LoadForm("PotatoSprint.xml", "Form1", nil, self)
	self.wndTwo:Show(true)
	
	self.wndTwo:SetAnchorPoints(0.5, 0.7, 0.5, 0.7)
	self.wndTwo:SetAnchorOffsets(-100, -15, 100, 15)
	
	--self.wndEndurance = self.wndMain:FindChild("EnduranceContainer")
	self.bInCombat = false
	self.tAccountData = {}
end


-----------------------------------------------------------------------------------------------
-- PotatoSprint Functions
-----------------------------------------------------------------------------------------------
-- Define general functions here

function PotatoSprint:OnFrame()
	local unitPlayer = GameLib.GetPlayerUnit()
	if not unitPlayer or unitPlayer == nil then return end
	if self.strCharacterName == nil then self.strCharacterName = unitPlayer:GetName() end
	local nEvadeCurr = unitPlayer:GetResource(7)
	local nEvadeMax = unitPlayer:GetMaxResource(7)
	local nRunCurr = unitPlayer:GetResource(0)
	local nRunMax = unitPlayer:GetMaxResource(0)
	local bShowFull = showFull == 1 and true or (nRunCurr ~= nRunMax or nEvadeCurr ~= nEvadeMax)

	--[[self:UpdateEvades(nEvadeCurr, nEvadeMax)
	PotatoLib:SetBarVars("ProgressBar", self.wndMain, nRunCurr, nRunMax)
	PotatoLib:SetBarAppearance("ProgressBar", self.wndMain, "Charcoal", "00ffff", 100)]]--
	
	if (showFrame == 1 and bShowFull) or (showFrame == 2 and self.bInCombat and bShowFull) or editorMode then
		self.wndTwo:Show(true)
		PotatoLib:SetBarVars("Sprint", self.wndTwo, nRunCurr, nRunMax)
		PotatoLib:SetBarAppearance("Sprint", self.wndTwo, "Aluminum", "00ffff", 100)
		
		PotatoLib:SetBarVars("Dodge1", self.wndTwo, nEvadeCurr, nEvadeMax-100)
		PotatoLib:SetBarAppearance("Dodge1", self.wndTwo, "Aluminum", nEvadeCurr >= 100 and "ffff00" or "ff00dd", 100)
		self.wndTwo:FindChild("DodgeBack1"):SetSprite("WhiteFill")
		self.wndTwo:FindChild("DodgeBack1"):SetBGColor("AA000000")
		
		PotatoLib:SetBarVars("Dodge2", self.wndTwo, nEvadeCurr-100, 100)
		PotatoLib:SetBarAppearance("Dodge2", self.wndTwo, "Aluminum", nEvadeCurr-100 == 100 and "ffff00" or "ff00dd", 100)
		self.wndTwo:FindChild("DodgeBack2"):SetSprite("WhiteFill")
		self.wndTwo:FindChild("DodgeBack2"):SetBGColor("AA000000")
	else
		self.wndTwo:Show(false)
	end
end

--[[function PotatoSprint:UpdateEvades(nEvadeValue, nEvadeMax)
	local strSpriteFull = "sprResourceBar_DodgeFull"
	local nMaxTick = math.floor(nEvadeMax/100)
	local nMaxState = eEnduranceFlash.EnduranceFlashTwo

	if nMaxTick == 3 then
		strSpriteFull = "sprResourceBar_DodgeFull3"
		nMaxState = eEnduranceFlash.EnduranceFlashThree
	end

	if nEvadeValue >= nEvadeMax then -- all full

		self.wndEndurance:FindChild("EvadeProgressContainer"):Show(false)
		self.wndEndurance:FindChild("EvadeFullSprite"):SetSprite(strSpriteFull)

		if self.nEnduranceState ~= nMaxState then
			self.nEnduranceState = nMaxState
			self.wndEndurance:FindChild("EvadeFlashSprite"):SetSprite("sprResourceBar_DodgeFlashFull")
		end

	elseif math.floor(nEvadeValue/100) < 1 then -- none ready

		self:HelperDrawProgressAsTicks(nEvadeValue)
		self.wndEndurance:FindChild("EvadeFullSprite"):SetSprite("")

		if self.nEnduranceState ~= eEnduranceFlash.EnduranceFlashZero then
			self.nEnduranceState = eEnduranceFlash.EnduranceFlashZero
			self.wndEndurance:FindChild("EvadeFlashSprite"):SetSprite("sprResourceBar_DodgeFlashHalf")
		end

	else -- one ready, one filling
		if nMaxState == eEnduranceFlash.EnduranceFlashThree then
			if nEvadeValue >= 200 and nEvadeValue < 300 then
				self.wndEndurance:FindChild("EvadeFullSprite"):SetSprite("sprResourceBar_DodgeHalf2")
				self:HelperDrawProgressAsTicks(nEvadeValue - 200)
				if self.nEnduranceState ~= eEnduranceFlash.EnduranceFlashTwo then
					if self.nEnduranceState == eEnduranceFlash.EnduranceFlashThree then
						self.wndEndurance:FindChild("EvadeFlashSprite"):SetSprite("sprResourceBar_DodgeFlashFull")
					else
						self.wndEndurance:FindChild("EvadeFlashSprite"):SetSprite("sprResourceBar_DodgeFlashHalf")
					end
					self.nEnduranceState = eEnduranceFlash.EnduranceFlashTwo
				end
			elseif nEvadeValue >= 100 and nEvadeValue < 200 then
				self.wndEndurance:FindChild("EvadeFullSprite"):SetSprite("sprResourceBar_DodgeHalf")
				self:HelperDrawProgressAsTicks(nEvadeValue - 100)
				if self.nEnduranceState ~= eEnduranceFlash.EnduranceFlashOne then
					self.wndEndurance:FindChild("EvadeFlashSprite"):SetSprite("sprResourceBar_DodgeFlashHalf")
					self.nEnduranceState = eEnduranceFlash.EnduranceFlashOne
				end
			else
				self.wndEndurance:FindChild("EvadeFullSprite"):SetSprite("")
			end
		else
			self:HelperDrawProgressAsTicks(nEvadeValue - nEvadeMax/nMaxTick)
			self.wndEndurance:FindChild("EvadeFullSprite"):SetSprite("sprResourceBar_DodgeHalf")
			if self.nEnduranceState == eEnduranceFlash.EnduranceFlashZero then
				self.nEnduranceState = eEnduranceFlash.EnduranceFlashOne
				self.wndEndurance:FindChild("EvadeFlashSprite"):SetSprite("sprResourceBar_DodgeFlashHalf")
			elseif self.nEnduranceState == eEnduranceFlash.EnduranceFlashTwo then
				self.nEnduranceState = eEnduranceFlash.EnduranceFlashOne
				self.wndEndurance:FindChild("EvadeFlashSprite"):SetSprite("sprResourceBar_DodgeFlashFull")
			end
		end

	end
	
	local strEvadeTooltop = Apollo.GetString(Apollo.GetConsoleVariable("player.doubleTapToDash") and "HealthBar_EvadeDoubleTapTooltip" or "HealthBar_EvadeKeyTooltip")
	local strDisplayTooltip = String_GetWeaselString(strEvadeTooltop, math.floor(nEvadeValue / 100), math.floor(nEvadeMax / 100))
	self.wndEndurance:FindChild("EvadeProgressContainer"):SetTooltip(strDisplayTooltip)
	self.wndEndurance:FindChild("EvadeFullSprite"):SetTooltip(strDisplayTooltip)

	self.nLastEnduranceValue = nEvadeValue
end

function PotatoSprint:HelperDrawProgressAsTicks(nProgress)
	local nTick = 100 / 8
	local nAnimationOffset = 3 -- TODO animation hack, offsets the delayed bits to the diagonal
	for idx = 1, 8 do
		local bIsTrue = nProgress - nAnimationOffset > (nTick * (idx - 1))
		self.wndEndurance:FindChild("EvadeDodgeBit"..idx):Show(bIsTrue, not bIsTrue)
	end
	self.wndEndurance:FindChild("EvadeProgressContainer"):Show(true)
end]]--

function PotatoSprint:EditorModeToggle()
	editorMode = not editorMode
	
	--[[self.wndMain:SetStyle("Moveable", editorMode)
	self.wndMain:FindChild("EditorCover"):Show(editorMode)
	self.wndMain:SetStyle("Sizable", editorMode)]]--
	
	self.wndTwo:SetStyle("Moveable", editorMode)
	self.wndTwo:SetStyle("Sizable", editorMode)
	self.wndTwo:FindChild("EditorCover"):Show(editorMode)
end

function PotatoSprint:ResetFrames()
	--[[self.wndMain:SetAnchorPoints(0.5, 0.65, 0.5, 0.65)
	self.wndMain:SetAnchorOffsets(-105, 0, 105, 51)]]--

	self.wndTwo:SetAnchorPoints(0.5, 0.7, 0.5, 0.7)
	self.wndTwo:SetAnchorOffsets(-100, -15 - 65, 100, 15 - 65)
	showFrame = 1
end

function PotatoSprint:OnSave(eLevel)  --TODO: Improve this code, it's hacky.
    -- create a table to hold our data
    local tSave = {}

	-- Save target location
	--[[local a,b,c,d = self.wndMain:GetAnchorPoints()
	local e,f,g,h = self.wndMain:GetAnchorOffsets()
	tSave.targetFrame2 = { points = {a,b,c,d}, offsets = {e,f,g,h} }]]--
	
	local a,b,c,d = self.wndTwo:GetAnchorPoints()
	local e,f,g,h = self.wndTwo:GetAnchorOffsets()
	tSave = { points = {a,b,c,d}, offsets = {e,f,g,h}, showFrame = showFrame, showFull = showFull }
		
   	if eLevel == GameLib.CodeEnumAddonSaveLevel.Character then
        return tSave
    elseif eLevel == GameLib.CodeEnumAddonSaveLevel.Account then
		self.tAccountData[self.strCharacterName] = tSave
		return self.tAccountData
	else
		return nil
	end
end

function PotatoSprint:OnRestore(eLevel, tData)  --TODO: Improve this code, it's hacky.
	if eLevel == GameLib.CodeEnumAddonSaveLevel.Character then
	   -- just store this and use it later
		self.tSavedData = tData
		
		--Restore Target
		--[[local savedPoints = self.tSavedData.targetFrame2.points
		local savedOffsets = self.tSavedData.targetFrame2.offsets
		self.wndMain:SetAnchorPoints(savedPoints[1],savedPoints[2],savedPoints[3],savedPoints[4])
		self.wndMain:SetAnchorOffsets(savedOffsets[1],savedOffsets[2],savedOffsets[3],savedOffsets[4])]]--
		
		local strDataType = 1 --TODO: Replace instances of [strDatatype] with nothing after a later update. e.g. self.tSavedData[strDataType].points -> self.tSavedData.points
		
		if self.tSavedData then
			local savedPoints = self.tSavedData.points
			local savedOffsets = self.tSavedData.offsets
			self.wndTwo:SetAnchorPoints(unpack(self.tSavedData.points))
			self.wndTwo:SetAnchorOffsets(unpack(self.tSavedData.offsets))
			showFrame = self.tSavedData.showFrame
			showFull = self.tSavedData.showFull
		end
	elseif eLevel == GameLib.CodeEnumAddonSaveLevel.Account then
		self.tAccountData = tData
	end
end

function PotatoSprint:OnEnteredCombat(unit, bInCombat)
	if unit:GetName() == GameLib.GetPlayerUnit():GetName() then
		self.bInCombat = bInCombat
	end
end
---------------------------------------------------------------------------------------------------
-- Form1 Functions
---------------------------------------------------------------------------------------------------

function PotatoSprint:MouseDownTest(wndHandler, wndControl, eButton, x, y, bDouble)
	local elementName = wndControl:GetName()

	if wndHandler:GetName() == "Form1" and elementName == "Content" and editorMode then
		self:PopulateEditor(wndHandler, wndControl)
	end
end

function PotatoSprint:PopulateEditor(wndHandler, wndControl)
	local PLib = Apollo.GetAddon("PotatoLib")
	PLib.wndCustomize:Show(true)
	PLib.wndCustomize:FindChild("EditorContent"):DestroyChildren()
	PLib:ElementSelected(wndHandler, self)
	
	self.wndCustomize = Apollo.LoadForm("PotatoSprint.xml", "SprintDashCustomize", PLib.wndCustomize:FindChild("EditorContent"), self) --Ghetto fix.
	PLib.wndCustomize:FindChild("EditorContent"):DestroyChildren() --Oh well.
	
	--Populate PotatoLib editor frame; Set title
	self.wndCustomize = Apollo.LoadForm("PotatoSprint.xml", "SprintDashCustomize", PLib.wndCustomize:FindChild("EditorContent"), self)
	PLib.wndCustomize:FindChild("Title"):SetText("Sprint/Dash Settings")
	
	self.wndCustomize:FindChild("ShowFrame"):FindChild("Options"):SetRadioSel("ShowFrame", showFrame)
	self.wndCustomize:FindChild("ShowFull"):FindChild("Options"):SetRadioSel("ShowFull", showFull)
	
	local nX1, nY1, nX2, nY2 = wndHandler:GetAnchorOffsets()
	local nScreenX, nScreenY = Apollo.GetScreenSize()
	if self.wndCustomize:FindChild("XPos") ~= nil then
		self.wndCustomize:FindChild("XPos"):SetText((nScreenX/2)+nX1)
		self.wndCustomize:FindChild("YPos"):SetText(nScreenY+nY1)
		self.wndCustomize:FindChild("Width"):SetText(nX2-nX1)
		self.wndCustomize:FindChild("Height"):SetText(nY2-nY1)
	end
end

function PotatoSprint:OnShowChange( wndHandler, wndControl, eMouseButton )
	local nShowFrame = wndHandler:GetParent():GetRadioSel("ShowFrame") --1 = Always; 2 = Combat; 3 = Never
	
	showFrame = nShowFrame
end

function PotatoSprint:OnFullChange( wndHandler, wndControl, eMouseButton )
	local nShowFull = wndHandler:GetParent():GetRadioSel("ShowFull") --1 = Always; 2 = Combat; 3 = Never
	
	showFull = nShowFull
end

function PotatoSprint:WindowMove( wndHandler, wndControl, nOldLeft, nOldTop, nOldRight, nOldBottom )
	if editorMode and self.wndCustomize then
		local wndTarget = self.wndTwo
		
		local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()
		local nScreenX, nScreenY = Apollo.GetScreenSize()
		if self.wndCustomize:FindChild("XPos") ~= nil then
			self.wndCustomize:FindChild("XPos"):SetText((nScreenX/2)+nX1)
			self.wndCustomize:FindChild("YPos"):SetText(nScreenY+nY1)
			self.wndCustomize:FindChild("Width"):SetText(nX2-nX1)
			self.wndCustomize:FindChild("Height"):SetText(nY2-nY1)
		end
	end
end

function PotatoSprint:TxtPositionChanged( wndHandler, wndControl, strPos )
	local strChange = wndHandler:GetName()
	
	local wndTarget = self.wndTwo
	
	local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()
	local nWidth = nX2-nX1
	local nHeight = nY2-nY1
	local nScreenX, nScreenY = Apollo.GetScreenSize()

	strPos = string.gsub(strPos, "[^0-9.]", "")
	if #strPos > 1 and string.sub(strPos, 1, 1) == "0" then
		strPos = string.gsub(strPos, "0", "", 1)
	end
	
	if strPos == "" then
		strPos = "0"
	end
	
	if strChange == "XPos" then
		wndTarget:SetAnchorOffsets(strPos-nScreenX/2, nY1, strPos-nScreenX/2+nWidth, nY2)
	elseif strChange == "YPos" then
		wndTarget:SetAnchorOffsets(nX1, strPos-nScreenY, nX2, strPos-nScreenY+nHeight)
	end
	
	wndHandler:SetText(strPos)
	wndHandler:SetSel(#strPos,#strPos)
end

function PotatoSprint:TxtHWChanged( wndHandler, wndControl, strHW )

	local strChange = wndHandler:GetName()
	
	local wndTarget = self.wndTwo
	
	local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()

	strHW = string.gsub(strHW, "[^0-9.]", "")
	if #strHW > 0 and string.sub(strHW, 1, 1) == "0" then
		strHW = string.gsub(strHW, "0", "", 1)
	end
	
	if strHW == "" then
		strHW = "0"
	end	
		
	if strChange == "Width" then
		wndTarget:SetAnchorOffsets(nX1, nY1, nX1+strHW, nY2)
	elseif strChange == "Height" then
		wndTarget:SetAnchorOffsets(nX1, nY1, nX2, nY1+strHW)
	end	
		
	wndHandler:SetText(strHW)
	wndHandler:SetSel(#strHW,#strHW)
end
-----------------------------------------------------------------------------------------------
-- PotatoSprint Instance
-----------------------------------------------------------------------------------------------
local PotatoSprintInst = PotatoSprint:new()
PotatoSprintInst:Init()
