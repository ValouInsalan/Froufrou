-----------------------------------------------------------------------------------------------
-- Client Lua Script for PotatoLib
-- Copyright (c) Tyler T. Hardy. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
 
-----------------------------------------------------------------------------------------------
-- PotatoLib Module Definition
-----------------------------------------------------------------------------------------------
PotatoLib = {} 

local bRecentPing = false
local bShowToolbox = true
local strVersion = "2.5.6d"
-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
-- e.g. local kiExampleVariableMax = 999
PotatoLib.AddonsList =
{
	"PotatoFrames",
	"PotatoResources",
	"PotatoSprint",
}

PotatoLib.classColors =
{
[GameLib.CodeEnumClass.Engineer] = "FF9900",
[GameLib.CodeEnumClass.Esper] = "00BFFF",
[GameLib.CodeEnumClass.Medic] = "FFFF00",
[GameLib.CodeEnumClass.Spellslinger] = "7FFF00",
[GameLib.CodeEnumClass.Stalker] = "BF00FF",
[GameLib.CodeEnumClass.Warrior] = "FF0000"
  --[[[GameLib.CodeEnumClass.Engineer] = "02AB2E",
  [GameLib.CodeEnumClass.Esper] = "FF83FA",
  [GameLib.CodeEnumClass.Medic] = "DDDDDD",
  [GameLib.CodeEnumClass.Spellslinger] = "3366FF",
  [GameLib.CodeEnumClass.Stalker] = "FF9408",
  [GameLib.CodeEnumClass.Warrior] = "AD8150",
  [6] = "000000"]]--

}  -- TRANSPARENCY VALUES MUST BE APPENDED TO BEGINNING

PotatoLib.resourceColors =
{
  [GameLib.CodeEnumClass.Engineer] = "EE0000",--"B32E02",--"556655",
  [GameLib.CodeEnumClass.Esper] = "BE03FD",
  [GameLib.CodeEnumClass.Medic] = "BE03FD",
  [GameLib.CodeEnumClass.Spellslinger] = "BE03FD",
  [GameLib.CodeEnumClass.Stalker] = "FAC205",
  [GameLib.CodeEnumClass.Warrior] = "FF3D0D",
  [6] = "000000"
}  -- TRANSPARENCY VALUES MUST BE APPENDED TO BEGINNING

PotatoLib.factionNames = 
{
	[166] = "Dominion",
	[170] = "Dominion",
	[171] = "Exile", --Exile NPC
	[189] = "redenemy",
	[167] = "Exile"
}

PotatoLib.pathNames =
{
	[0] = "Soldier",
	[1] = "Colonist",
	[2] = "Scientist",
	[3] = "Explorer"
}

PotatoLib.frame = {
	anchors = {},
	offsets = {},
	showPortrait = nil,
	icons = {},
	barStyles = {},
	textFields = {}
}

PotatoLib.iconForm = {
	playerType = {},
	npcType = {}
}

PotatoLib.barStylesForm = {
	texture = {},
	color = {},
	transparency = {},
	textLeft = {},
	textRight = {}
}

PotatoLib.ktDefaultFramesMess =
{
	{
		name = "HP",
		colorType = "classcolor",
		color = "00FF00",
		textLeft = {
			type = 1,
			font = {
				base = "CRB_Interface",
				size = "10",
				props = "BBO"
			}
		},
		textMid = {
			type = 0,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		textRight = {
			type = 4,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		texture = "Aluminum",
		transparency = "100",
		barGrowth = 0
	},
	{
		name = "SP",
		colorType = "customcolor",
		color = "00FFFF",
		textLeft = {
			type = 2,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		textMid = {
			type = 0,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		textRight = {
			type = 4,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		texture = "Aluminum",
		transparency = "100",
		barGrowth = 0
	},
	{
		name = "AP",
		colorType = "customcolor",
		color = "FFFFFF",
		textLeft = {
			type = 2,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		textMid = {
			type = 0,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		textRight = {
			type = 4,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		texture = "Aluminum",
		transparency = "100",
		barGrowth = 1
	},
	{
		name = "RP",
		colorType = "resourcecolor",
		color = "FF00FF",
		textLeft = {
			type = 2,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		textMid = {
			type = 0,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		textRight = {
			type = 4,
			font = {
				base = "CRB_Pixel",
				size = "",
				props = "O"
			}
		},
		texture = "Aluminum",
		transparency = "100",
		barGrowth = 0,
		showResBar = true
	}
}

--------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function PotatoLib:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function PotatoLib:Init()
    Apollo.RegisterAddon(self)
end
 
local editorMode = false
-----------------------------------------------------------------------------------------------
-- PotatoLib OnLoad
-----------------------------------------------------------------------------------------------
function PotatoLib:OnLoad()
    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)
	Apollo.RegisterSlashCommand("potatoui", "ToggleToolbox", self)
	Apollo.RegisterSlashCommand("pui", "ToggleToolbox", self)
	Apollo.RegisterSlashCommand("potatoedit", "PotatoEditor", self)
	Apollo.RegisterSlashCommand("potatoreset", "PotatoReset", self)
	
	Apollo.RegisterSlashCommand("potatoping", "PotatoPing", self)
	Apollo.RegisterSlashCommand("potatosend", "PotatoSend", self)
	
	Apollo.RegisterEventHandler("SystemKeyDown",				"OnSystemKeyDown", self)

	Apollo.CreateTimer("TargetFrameUpdate", 1, true)
	Apollo.RegisterTimerHandler("TargetFrameUpdate", 						"MainThread", self)
	Apollo.CreateTimer("PingTimer", 20, false)
	Apollo.RegisterTimerHandler("PingTimer", "OnPingTimerEnd", self)
	Apollo.CreateTimer("AHToolboxTimer", 5, false) --AH = autohide
	Apollo.RegisterTimerHandler("AHToolboxTimer", "OnAHToolboxEnd", self)
	
	Apollo.LoadSprites("PotatoSprites.xml", "BarSprites")
	
    -- load our forms
	self.wndEditorBtns = Apollo.LoadForm("PotatoLib.xml", "TempEditorBtns", nil, self)
	
	self.wndCustomize = Apollo.LoadForm("PotatoLib.xml", "Form3", nil, self)
	self.wndCustomize:Show(false)
	
	self.wndCopySettings = Apollo.LoadForm("PotatoLib.xml", "Profiles", nil, self)
	
	self.wndPing = Apollo.LoadForm("PotatoLib.xml", "PingFrame", nil, self)
	
	--self.wndTest = Apollo.LoadForm("PotatoLib.xml", "TempEditorBtns1", nil, self)
	
	
	--[[self.wndTopBar = Apollo.LoadForm("PotatoLib.xml", "TopBar", nil, self)
	self.wndTopBar:SetSprite("BarSprites:TobBar")]]--
	
	--self.wndContent = Apollo.LoadForm("PotatoLib.xml", "FrameOptionsForm", nil, self)
	--self.wndContent:Show(true)
	
	--load communications
	self.chanPotato = ICCommLib.JoinChannel("PotatoChannel", "OnPotatoMessage", self)
	
	self.tCharacters = {}
end

function PotatoLib:OnTestTimerEnd()
	Print("[PotatoUI] Resetting Timer")
	bRecentPing = false
end

-----------------------------------------------------------------------------------------------
-- PotatoLib Functions
-----------------------------------------------------------------------------------------------
-- Define general functions here

function PotatoLib:MainThread()
	if GameLib.GetPlayerUnit() == nil then return end
	if self.strCharacterName == nil then self.strCharacterName = GameLib.GetPlayerUnit():GetName() end
end

function PotatoLib:ToggleToolbox()
	bShowToolbox = not bShowToolbox
	self.wndEditorBtns:Show(bShowToolbox)
	if not bShowToolbox then
		if editorMode then
			self:PotatoEditor()
		end
		Print("[PotatoUI] To show the PotatoUI toolbox again, type /potatoui or /pui.")
	end
end

function PotatoLib:PotatoEditor()
	Event_FireGenericEvent("PotatoEditor")
	editorMode = not editorMode
	
	local wndResetBtn =	self.wndEditorBtns:FindChild("Reset")
	
	if editorMode then
		wndResetBtn:SetTextColor("FFFFFFFF")
		wndResetBtn:SetBGColor("FFFFFFFF")
		GameLib.PauseGameActionInput(true)
	else
		wndResetBtn:SetTextColor("FF555555")
		wndResetBtn:SetBGColor("FF555555")
		GameLib.PauseGameActionInput(false)
		if self.previousElement ~= nil then
			self.previousElement:FindChild("CustomizeBorder"):Show(false)
			self.previousElement = nil
		end
		self.wndCustomize:Show(false)
	end
end

function PotatoLib:PotatoReset()
	if editorMode then
		self.wndConfirmReset = Apollo.LoadForm("PotatoLib.xml", "ConfirmReset", nil, self)
	else
		Print("[PotatoUI] You must be in editor mode to reset frame positions.")
	end
end

function PotatoLib:CopySettingsStart( wndHandler, wndControl, eMouseButton, nLastRelativeMouseX, nLastRelativeMouseY, bDoubleClick, bStopPropagation )
	if not self.wndCopySettings:IsVisible() then
		--Reset "Are you sure?" frame as if 'No' was pressed. 
		self:OnCopyNoBtn()
		self.wndCopySettings:Show(true)
		self.wndCopySettings:FindChild("CopySettings"):Enable(false)
		--Reset the Character and Addon Lists
		local tCharacters = {}
		self.wndCopySettings:FindChild("CharacterList"):DestroyChildren()
		self.wndCopySettings:FindChild("AddonList"):DestroyChildren()
		local counter = 1
		for key, val in pairs(self.tCharacters) do
			if key ~= self.strCharacterName then
				tCharacters[counter] = Apollo.LoadForm("PotatoLib.xml", "ProfileCharacter", self.wndCopySettings:FindChild("CharacterList"), self)
				tCharacters[counter]:SetText(key)
				counter = counter+1
			end
		end
		self.wndCopySettings:FindChild("CharacterList"):ArrangeChildrenVert(0)
	else
		self.wndCopySettings:Show(false)
	end
end

function PotatoLib:OnSelectSettingsCharacter( wndHandler, wndControl, eMouseButton )
	local strCharacterName = wndHandler:GetText()
	local tAddons = {}
	self.wndCopySettings:FindChild("AddonList"):DestroyChildren()
	--Populate Addon List
	for key, val in pairs(self.tCharacters[strCharacterName]) do
		if Apollo.GetAddon(val)~= nil then
			tAddons[key] = Apollo.LoadForm("PotatoLib.xml", "ProfileAddon", self.wndCopySettings:FindChild("AddonList"), self)
			tAddons[key]:SetText(val)
		end
	end
	self.wndCopySettings:FindChild("AddonList"):ArrangeChildrenVert(0)
	self.wndCopySettings:FindChild("AreYouSure"):SetData(strCharacterName)
end

function PotatoLib:OnCopySettingsBtn( wndHandler, wndControl, eMouseButton )
	if not self.wndCopySettings:FindChild("AreYouSure"):IsVisible() then
		--Arrange frames
		self.wndCopySettings:FindChild("AddonList"):SetAnchorOffsets(0,0,0,200)
		self.wndCopySettings:FindChild("AreYouSure"):SetAnchorOffsets(0,235,0,0)
		self.wndCopySettings:FindChild("RightSide"):ArrangeChildrenVert(0)
		self.wndCopySettings:FindChild("AreYouSure"):Show(true)	
	end
	
	--Populate string
	local strSettingsCharName = self.wndCopySettings:FindChild("AreYouSure"):GetData()
	local strCurrCharName = GameLib.GetPlayerUnit():GetName()
	local tAddonsSelected = {}
	for idx=1, #self.wndCopySettings:FindChild("AddonList"):GetChildren() do
		local currAddon = self.wndCopySettings:FindChild("AddonList"):GetChildren()[idx]
		if currAddon:IsChecked() then
			table.insert(tAddonsSelected, currAddon:GetText())
		end			
	end
	self.wndCopySettings:FindChild("AreYouSure"):SetText(string.format("Are you sure you want to copy settings from the %s addons "..
																		"selected above from %s to your current character, %s?",
																		#tAddonsSelected,
																		strSettingsCharName,
																		strCurrCharName))
	self.wndCopySettings:FindChild("CopyYes"):SetData({name=strSettingsCharName, addons=tAddonsSelected})
end

function PotatoLib:OnCopyYesBtn( wndHandler, wndControl, eMouseButton )
	--Do the copy stuff
	local tAddonsSelected = self.wndCopySettings:FindChild("CopyYes"):GetData().addons
	local strSettingsCharName = self.wndCopySettings:FindChild("CopyYes"):GetData().name
	for idx=1, #tAddonsSelected do
		local addonInstance = Apollo.GetAddon(tAddonsSelected[idx])
		if addonInstance.tAccountData ~= nil then --Check to see if addon data exists
			if addonInstance.tAccountData[strSettingsCharName] ~= nil then --Check to see if character data exists
				addonInstance:OnRestore(GameLib.CodeEnumAddonSaveLevel.Character, addonInstance.tAccountData[strSettingsCharName])
			end
		end
	end
	--Reset the frame as if 'No' was pressed
	self:OnCopyNoBtn()	
end

function PotatoLib:OnCopyNoBtn( wndHandler, wndControl, eMouseButton )
	self.wndCopySettings:FindChild("AddonList"):SetAnchorOffsets(0,0,0,320)
	self.wndCopySettings:FindChild("AreYouSure"):SetAnchorOffsets(0,0,0,0)
	self.wndCopySettings:FindChild("AreYouSure"):Show(false)	
	self.wndCopySettings:FindChild("RightSide"):ArrangeChildrenVert(0)
end

function PotatoLib:OnAddonCheck( wndHandler, wndControl, eMouseButton )
	local bAddonsChecked = wndHandler:IsChecked() --Check if current button is checked.
	
	if not bAddonsChecked then --If not, check the others.
		for idx=1, #self.wndCopySettings:FindChild("AddonList"):GetChildren() do
			local currAddon = self.wndCopySettings:FindChild("AddonList"):GetChildren()[idx]
			if currAddon:IsChecked() then
				bAddonsChecked = true
				break
			end			
		end
	end
	
	self.wndCopySettings:FindChild("CopySettings"):Enable(bAddonsChecked) --Enable CopySettings button if any are checked.
end

function PotatoLib:PotatoReloadUI( wndHandler, wndControl, eMouseButton, nLastRelativeMouseX, nLastRelativeMouseY, bDoubleClick, bStopPropagation )
	RequestReloadUI()
end

function PotatoLib:ElementSelected(element, addon)

	if self.previousElement ~= element and self.previousElement ~= nil then
		--Print(self.previousElement:GetData().name .. " disabled")
		self.previousElement:FindChild("EditorCover"):Show(true)
		self.previousElement:FindChild("CustomizeBorder"):Show(false)
	end
	self.previousElement = element	
		
	--Place frame around element
	element:FindChild("CustomizeBorder"):Show(true)
	element:FindChild("EditorCover"):Show(false)
	
end

function PotatoLib:GetFontTable(strFont)
	local final = {}
	local strBase = ""
	local nSize = nil
	local strProps = ""
	
	for key,val in pairs(self.ktFonts) do
		if string.find(strFont, val.base) then
		strBase = val.base --CRB_Interface // CRB_Alien
		strRemainder = string.gsub(strFont, val.base, "") --10_BBO // Small
		for size,props in pairs(val.sizeProp) do
			local nMatchStart, nMatchEnd = string.find(strRemainder, size)
			if nMatchStart == 1 then
					nSize = string.sub(strRemainder, nMatchStart, nMatchEnd)
					strRemainder = string.gsub(strRemainder, nSize, "")
					strRemainder = string.gsub(strRemainder, "_", "")
					strProps = strRemainder
				end
			end
			final.base = strBase
			final.size = nSize
			final.props = strProps
		end
	end
	
	return final
end

function PotatoLib:GetFontDataByBase(strBase)
	for key,val in pairs(self.ktFonts) do
		if val.base == strBase then
			return val
		end
	end
end

function PotatoLib:GetFontKeyByBase(strBase)
	for key,val in pairs(self.ktFonts) do
		if val.base == strBase then
			return key
		end
	end
end

function PotatoLib:GetSizeKeyByBaseSize(nBase, strSize)
	for key,val in pairs(self.ktFonts[nBase].sizes) do
		if val.."" == strSize.."" then
			return key
		end
	end
end
	
	
function PotatoLib:FontTableToString(tFont)
	local strFont = ""
	strFont = tFont.base .. tFont.size
	if tFont.props ~= "" and tFont.props ~= nil then
		strFont = strFont.."_"..tFont.props
	end
	return strFont
end

function PotatoLib:CloseEditorWnd()
	if self.previousElement and self.previousElement:FindChild("CustomizeBorder") then
		self.previousElement:FindChild("CustomizeBorder"):Show(false)
		self.previousElement:FindChild("EditorCover"):Show(true)
	end
	self.wndCustomize:Show(false)
end

function PotatoLib:PotatoPing()
	local myName = GameLib.GetPlayerUnit():GetName()
	if myName == "Otatop" or myName == "Potato" or myName == "Perterter" or myName == "Pootato" or myName == "Tabbouleh" then
		if not bRecentPing then
			Print("[PotatoUI] PING SENT!")
			local t = {}
			t.strUser = GameLib.GetPlayerUnit():GetName()
			t.strMessage = "ping"
			self.chanPotato:SendMessage(t) --send to others
			
			self:OnPotatoMessage(nil, t) --"send" to self
			self.pongCounter = 0
			self.wndPing:FindChild("Grid"):DeleteAll()
			
			bRecentPing = true
			Apollo.StartTimer("PingTimer")
		else
			Print("[PotatoUI] Pung too soon.")
		end
	end
end

function PotatoLib:OnPotatoMessage(channel, tMsg)
	local myName = GameLib.GetPlayerUnit():GetName()
	local myLevel = GameLib.GetPlayerUnit():GetLevel()
	local myClass = GameLib.GetClassName(GameLib.GetPlayerUnit():GetClassId())
	local myLocation = GameLib.GetCurrentZoneMap().strName
	
	local senderName = tMsg.strUser
	local senderLevel = tMsg.strLevel and tMsg.strLevel or "nil" --TODO: Remove this when significantly into updates
	local senderClass = tMsg.strClass and tMsg.strClass or "nil" --TODO: Remove this when significantly into updates
	local senderLocation = tMsg.strLocation and tMsg.strLocation or "nil" --TODO: Remove this when significantly into updates
	local senderVersion = tMsg.strVersion and tMsg.strVersion or "<=2.5.4" --TODO: Remove this when significantly into updates
	
	local strMessage = tMsg.strMessage
	
	if myName == "Otatop" or myName == "Potato" or myName == "Perterter" or myName == "Pootato" or myName == "Tabbouleh" then
		if strMessage == "PONG!" then
			self.pongCounter = self.pongCounter+1
			
			local wndGrid = self.wndPing:FindChild("Grid")
			local iCurrRow = wndGrid:AddRow(self.pongCounter)
			
			wndGrid:SetCellText(iCurrRow, 1, senderName)
			if senderLevel < 10 then
				senderLevel = "0"..senderLevel
			end
			wndGrid:SetCellText(iCurrRow, 2, senderLevel)
			wndGrid:SetCellText(iCurrRow, 3, senderClass)
			wndGrid:SetCellText(iCurrRow, 4, senderLocation)
			wndGrid:SetCellText(iCurrRow, 5, senderVersion)
			wndGrid:SetCellText(iCurrRow, 6, self.pongCounter)
			
			self.wndPing:FindChild("UserNo"):SetText(self.pongCounter)
			self.wndPing:Show(true)
		end
	else
		if not bRecentPing and strMessage == "ping" then
			local t = {}
			t.strUser = myName
			t.strMessage = "PONG!"
			t.strLevel = myLevel
			t.strClass = myClass
			t.strLocation = myLocation
			t.strVersion = strVersion
			self.chanPotato:SendMessage(t)
			bRecentPing = true
			Apollo.StartTimer("PingTimer")
		end
	end
end

function PotatoLib:OnPingTimerEnd()
	bRecentPing = false
end

function PotatoLib:OnAHToolboxEnd()
	--[[if not self.wndTest:ContainsMouse() then
		Print("Hiding")
		self:ShowToolbox(false)
	end]]--
end

function PotatoLib:PotatoSend(slashCommand, strMsg)
	local myName = GameLib.GetPlayerUnit():GetName()

	if myName == "Otatop" or myName == "Potato" or myName == "Perterter" or myName == "Pootato" then
		local t = {}
		t.strUser = myName
		t.strMessage = "PotatoAnnounce:" .. strMsg
		
		self.chanPotato:SendMessage(t)
	end
end	

function PotatoLib:OnSave(eLevel)  --TODO: Improve this code, it's hacky.
	if eLevel == GameLib.CodeEnumAddonSaveLevel.Character then
	    local tSave = {}
			tSave = {anchors = {self.wndEditorBtns:GetAnchorPoints()}, offsets = {self.wndEditorBtns:GetAnchorOffsets()}}
			tSave.bShowToolbox = bShowToolbox
	    return tSave
    elseif eLevel == GameLib.CodeEnumAddonSaveLevel.Account then
		local tAddons = {}
		
		for key, val in pairs(self.AddonsList) do
			if Apollo.GetAddon(val) ~= nil then
				table.insert(tAddons, val)
			end
		end
		
		self.tCharacters[self.strCharacterName] = tAddons
		
		return self.tCharacters
	else
		return nil
	end
end

function PotatoLib:OnRestore(eLevel, tData)  --TODO: Improve this code, it's hacky.
    if eLevel == GameLib.CodeEnumAddonSaveLevel.Character then
	    self.tSavedData = tData
		if tData.anchors and (tData.offsets[3]-tData.offsets[1] >= 160) then
			self.wndEditorBtns:SetAnchorPoints(unpack(tData.anchors))
			self.wndEditorBtns:SetAnchorOffsets(unpack(tData.offsets))
		end
		bShowToolbox = tData.bShowToolbox
		self.wndEditorBtns:Show(bShowToolbox)
	elseif eLevel == GameLib.CodeEnumAddonSaveLevel.Account then
		self.tCharacters = tData
	end
end

--Utility Functions

function PotatoLib:RandomColor()
	local strColor = ""
	local tBuilder = {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"}
	for idx=1,6 do
		strColor = strColor .. tBuilder[math.random(1,#tBuilder)]
	end
	return strColor
end

function PotatoLib:PrintAnchorStats(wnd)
	Print(wnd:GetName())
	Print(string.format("Anchors: %s, %s, %s, %s",wnd:GetAnchorPoints()))
	Print(string.format("Offsets: %s, %s, %s, %s",wnd:GetAnchorOffsets()))
end

function PotatoLib:PercentToHex(nPercent)
	return string.format("%X", 255*nPercent/100)
end

function PotatoLib:HexStr2RGBTable(hex)
  hex = hex:gsub("#","")
  return {tonumber("0x"..hex:sub(1,2)), tonumber("0x"..hex:sub(3,4)), tonumber("0x"..hex:sub(5,6)), tonumber("0x"..hex:sub(7,8))}
end

function PotatoLib:HexStr2ColorTable(hex)
  hex = hex:gsub("#","")
  return {a=tonumber("0x"..hex:sub(1,2))/255, r=tonumber("0x"..hex:sub(3,4))/255, g=tonumber("0x"..hex:sub(5,6))/255, b=tonumber("0x"..hex:sub(7,8))/255}
end

function PotatoLib:RGBTable2HexStr(tColor)
    local sColor = ""
	for idx=1, #tColor do
	    local strColor = string.format ( "%X", tColor[idx] )
	    sColor = ( ( string.len ( strColor ) == 1 ) and ( "0" .. strColor ) or strColor )
	end
    return sColor
end


function PotatoLib:SetBarVars(bar, barWnd, curr, max)
	barWnd:FindChild(bar):SetMax(max)
	barWnd:FindChild(bar):SetProgress(curr)
end

function PotatoLib:SetBarVars2(barWnd, curr, max)
	barWnd:SetMax(max)
	barWnd:SetProgress(curr)
end

function PotatoLib:DrawPixie(wnd, tAnchors, tOffsets, strColor)
	local tLoc = {
		fPoints = tAnchors,
		nOffsets = tOffsets
	}
	
	self:HexStr2RGBTable(strColor)

	wnd:AddPixie({
		iLayer = 2,
		bLine = false,
		strSprite = "ClientSprites:WhiteFill",
		cr = tColor,
		loc = tLoc})
end

function PotatoLib:ChangeBorderSize(wndMain, wndContent, nOld, nNew, strColor)
	local tInitOffsets = {wndMain:GetAnchorOffsets()}
	local tNewOffsets = {}
	for idx, val in pairs(tInitOffsets) do
		tNewOffsets[idx] = val - nOld + nNew
	end
	--Print(string.format("%s,%s,%s,%s",unpack(tNewOffsets)))
	wndMain:SetAnchorOffsets(unpack(tNewOffsets))
	wndContent:SetAnchorOffsets(nNew, nNew, -nNew, -nNew)

	wndMain:DestroyAllPixies()
	PotatoLib:DrawPixie(wndMain, {0,0,0,1}, {0,     nNew,  nNew, -nNew}, strColor)
	PotatoLib:DrawPixie(wndMain, {0,0,1,0}, {0,     0,     0,    nNew}, strColor)
	PotatoLib:DrawPixie(wndMain, {1,0,1,1}, {-nNew, nNew,  0,    -nNew}, strColor)
	PotatoLib:DrawPixie(wndMain, {0,1,1,1}, {0,     -nNew, 0,    0}, strColor)
end


function PotatoLib:SetBarAppearance(bar, barWnd, texture, color, percentTrans) 
    --Consider: input from Colorpicker will be at least 6 hex, possibly 8 hex. You can append 2 hex transparency with slider value stored to percentTrans.
    
    local transHex = "ff"
    local colorStr = "pink"
    
    if percentTrans and type(percentTrans) == "number" then
    	transHex = string.format("%x", (percentTrans/100)*255)
    end
    
    if tonumber("0x"..color) then
    	if string.len(color) == 6 then
    	    colorStr = transHex .. color
    	else
    	    colorStr = color
    	end
    else
    	colorStr = color
    end  	

    --Set Bar Color/transparency
    barWnd:FindChild(bar):SetBarColor(colorStr)
    
    --Set Bar Texture
    barWnd:FindChild(bar):SetFillSprite("BarSprites:" .. texture)
    barWnd:FindChild(bar):SetFullSprite("BarSprites:" .. texture)
end

function PotatoLib:SetBarAppearance2(barWnd, texture, color, percentTrans) 
    --Consider: input from Colorpicker will be at least 6 hex, possibly 8 hex. You can append 2 hex transparency with slider value stored to percentTrans.
    
    local transHex = "ff"
    local colorStr = "pink"
    
    if percentTrans and type(percentTrans) == "number" then
    	transHex = string.format("%x", (percentTrans/100)*255)
    end
    
    if tonumber("0x"..color) then
    	if string.len(color) == 6 then
    	    colorStr = transHex .. color
    	else
    	    colorStr = color
    	end
    else
    	colorStr = color
    end  	

    --Set Bar Color/transparency
    barWnd:SetBarColor(colorStr)
    
    --Set Bar Texture
	self:SetBarSprite(barWnd, texture)
end

function PotatoLib:SetSprite(wnd, sprite)
	wnd:SetSprite("BarSprites:" .. sprite)
end

function PotatoLib:SetBarSprite(wnd, sprite)
	if sprite == "WhiteFill" then
		wnd:SetFillSprite("WhiteFill")
		wnd:SetFullSprite("WhiteFill")
	else
		wnd:SetFillSprite("BarSprites:" .. sprite)
		wnd:SetFullSprite("BarSprites:" .. sprite)
	end
end

function PotatoLib:SetSpriteAppearance(wnd, container, texture, color, percentTrans)
    local transHex = "ff"
    local colorStr = "pink"
    
    if percentTrans and type(percentTrans) == "number" then
    	transHex = string.format("%x", (percentTrans/100)*255)
    end
    
    if tonumber("0x"..color) then
    	if string.len(color) == 6 then
    	    colorStr = transHex .. color
    	else
    	    colorStr = color
    	end
    else
    	colorStr = color
    end  	

    --Set Bar Color/transparency
    container:FindChild(wnd):SetBGColor(colorStr)
    
    --Set Bar Texture
    container:FindChild(wnd):SetSprite("BarSprites:" .. texture)
end

function PotatoLib:GetClassResource(unit)
	local classID = unit:GetClassId()
	
	if classID == GameLib.CodeEnumClass.Engineer or	classID == GameLib.CodeEnumClass.Warrior then
		return unit:GetResource(1), unit:GetMaxResource(1)
	elseif classID == GameLib.CodeEnumClass.Stalker then
		return unit:GetResource(3), unit:GetMaxResource(3)
	else
		return unit:GetMana(), unit:GetMaxMana()
	end
end

function PotatoLib:TextSquish(strText, wnd, strType, nPadding)
	strType = strType or ""
	nPadding = nPadding or 0
	
	local tCRBFonts = {
		{size=9, height=13},
		{size=10, height=14},
		{size=11, height=15},
		{size=12, height=17},
		{size=14, height=20},
		{size=16, height=22}
	}
	local nWndWidth = wnd:GetWidth()
	local nWndHeight = wnd:GetHeight()
	local previousFont = "CRB_Pixel_O"
	
	for idx=1, #tCRBFonts do
		--Print(idx)
		local fontName = "CRB_Interface"..tCRBFonts[idx].size
		local tVariations = { fontName..strType} --fontName,	fontName.."_O",	fontName.."_B",	fontName.."_BO",	fontName.."_BB",	fontName.."_BBO"}
		
		for idx2=1, #tVariations do
			local fontHeight = tCRBFonts[idx].height + nPadding
			if string.find(tVariations[idx2], "O") then fontHeight = fontHeight + 1 end
			local fontWidth = Apollo.GetTextWidth(tVariations[idx2], strText) + nPadding
			
			if nWndWidth >= fontWidth and nWndHeight >= fontHeight then
				previousFont = tVariations[idx2]
			else
				break
			end
		end
		--Print("end: " ..previousFont)
		wnd:SetText(strText)
		wnd:SetFont(previousFont)
	end
end

function PotatoLib:OnSystemKeyDown(iKey)
	if editorMode and self.previousElement ~= nil then
		local tLoc = {self.previousElement:GetAnchorOffsets()}
		if iKey == 38 then --Move UP
			self.previousElement:SetAnchorOffsets(tLoc[1], tLoc[2]-1, tLoc[3], tLoc[4]-1)
		end
		if iKey == 40 then --Move DOWN
			self.previousElement:SetAnchorOffsets(tLoc[1], tLoc[2]+1, tLoc[3], tLoc[4]+1)
		end
		if iKey == 37 then --Move Left
			self.previousElement:SetAnchorOffsets(tLoc[1]-1, tLoc[2], tLoc[3]-1, tLoc[4])
		end
		if iKey == 39 then --Move Right
			self.previousElement:SetAnchorOffsets(tLoc[1]+1, tLoc[2], tLoc[3]+1, tLoc[4])
		end
		if iKey == 104 then --Resize UP
			self.previousElement:SetAnchorOffsets(tLoc[1], tLoc[2]-1, tLoc[3], tLoc[4])
		end
		if iKey == 98 then -- Resize DOWN
			self.previousElement:SetAnchorOffsets(tLoc[1], tLoc[2]+1, tLoc[3], tLoc[4])
		end
		if iKey == 100 then --Resize Left
			self.previousElement:SetAnchorOffsets(tLoc[1], tLoc[2], tLoc[3]-1, tLoc[4])
		end
		if iKey == 102 then --Resize Right
			self.previousElement:SetAnchorOffsets(tLoc[1], tLoc[2], tLoc[3]+1, tLoc[4])
		end
	end
end 
	

---------------------------------------------------------------------------------------------------
-- PingFrame Functions
---------------------------------------------------------------------------------------------------

function PotatoLib:ClosePingFrame( wndHandler, wndControl, eMouseButton )
	self.wndPing:Show(false)
end

---------------------------------------------------------------------------------------------------
-- Form4 Functions
---------------------------------------------------------------------------------------------------

function PotatoLib:CloseSettingsWnd( wndHandler, wndControl, eMouseButton )
end

PotatoLib.ktFonts = {
	{
		name = "Standard",
		base = "CRB_Interface",
		defaultStr = "CRB_Interface12",
		defaultSettings = {base="CRB_Interface",size="12",props=""},
		sizeProp = {["9"]={"B","BB","BBO","O","I","BO"},["10"]={"B","BB","BBO","O","I","BO"},
					["11"]={"B","BB","BBO","O","I","BO"},["12"]={"B","BB","BBO","O","I","BO"},
					["14"]={"B","BB","BBO","O","I","BO"},["16"]={"B","BB","BBO","O","I","BO"}},
		sizes = {9,10,11,12,14,16}
	},
	{
		name = "Wildstar",
		base = "CRB_Header",
		defaultStr = "CRB_Header12",
		defaultSettings = {base="CRB_Header",size="12",props=""},
		sizeProp = {["9"]={},["10"]={},["11"]={"O"},["12"]={"O"},["13"]={"O"},["14"]={"O"},["16"]={"O"},["20"]={"O"},
					["24"]={"O"}},
		sizes = {9,10,11,12,13,14,16,20,24}
	},
	{
		name = "Pixel",
		base = "CRB_Pixel",
		defaultStr = "CRB_Pixel",
		defaultSettings = {base="CRB_Pixel",size="",props=""},
		sizeProp = {[""]={"O"}},
		sizes = {""}
	},
	{
		name = "Action",
		base = "CRB_Floater",
		defaultStr = "CRB_FloaterSmall",
		defaultSettings = {base="CRB_Floater",size="Small",props=""},
		sizeProp = {["Small"]={},["Medium"]={},["Large"]={},["Huge"]={"O"},["Gigantic"]={"O"}},
		sizes = {"Small","Medium","Large","Huge","Gigantic"}
	},
	{
		name = "Courier",
		base = "Courier",
		defaultStr = "Courier",
		defaultSettings = {base="Courier",size="",props=""},
		sizeProp = {[""]={}},
		sizes = {""}
	},
	{
		name = "Alien",
		base = "CRB_Alien",
		defaultStr = "CRB_AlienMedium",
		defaultSettings = {base="CRB_Alien",size="Medium",props=""},
		sizeProp = {["Small"]={},["Medium"]={},["Large"]={}},
		sizes = {"Small", "Medium", "Large"}
	},
}

---------------------------------------------------------------------------------------------------
-- TempEditorBtns1 Functions
---------------------------------------------------------------------------------------------------

function PotatoLib:OnHoverTrigger( wndHandler, wndControl, x, y )
	Print("Hovered")
	self:ShowToolbox(true)
end

function PotatoLib:OnToolboxExit( wndHandler, wndControl, x, y )
	Print("HAPPENED")
	if wndHandler == wndControl and wndHandler:FindChild("Buttons"):IsVisible() then
		Print("Left")
		Apollo.StartTimer("AHToolboxTimer")
	end
end

function PotatoLib:ShowToolbox(bShow)
	self.wndTest:SetStyle("Picture", bShow)
	self.wndTest:FindChild("Buttons"):Show(bShow)
	self.wndTest:FindChild("Title"):Show(bShow)
end

---------------------------------------------------------------------------------------------------
-- ConfirmReset Functions
---------------------------------------------------------------------------------------------------

function PotatoLib:OnResetYesBtn( wndHandler, wndControl, eMouseButton )
	Event_FireGenericEvent("PotatoReset")
	if self.previousElement ~= nil then
		self.previousElement:FindChild("EditorCover"):Show(true)
		self.previousElement:FindChild("CustomizeBorder"):Show(false)
		self.previousElement = nil
	end
	self.wndCustomize:Show(false)
	self:OnCloseReset()
end

function PotatoLib:OnCloseReset( wndHandler, wndControl, eMouseButton )
	self.wndConfirmReset:Show(false)
end

-----------------------------------------------------------------------------------------------
-- PotatoLib Instance
-----------------------------------------------------------------------------------------------
local PotatoLibInst = PotatoLib:new()
PotatoLibInst:Init()
