-----------------------------------------------------------------------------------------------
-- Client Lua Script for PotatoResources
-- Copyright (c) Tyler T. Hardy. All rights reserved
-----------------------------------------------------------------------------------------------
 
require "Window"
require "GameLib"
require "Unit"
require "Spell"
 
-----------------------------------------------------------------------------------------------
-- PotatoResources Module Definition
-----------------------------------------------------------------------------------------------
local PotatoResources = {} 

local DrawClass = {
	[GameLib.CodeEnumClass.Medic] = function(self, arg) self:DrawMedic(arg) end,
	[GameLib.CodeEnumClass.Spellslinger] = function(self, arg) self:DrawSpellslinger2(arg) end,
	[GameLib.CodeEnumClass.Esper] = function(self, arg) self:DrawEsper(arg) end,
	[GameLib.CodeEnumClass.Engineer] = function(self, arg) self:DrawEngineer(arg) end,
	[GameLib.CodeEnumClass.Warrior] = function(self, arg) self:DrawWarrior(arg) end,
	[GameLib.CodeEnumClass.Stalker] = function(self, arg) self:DrawStalker(arg) end
}

local ClassName = {
	[GameLib.CodeEnumClass.Medic] = "Medic",
	[GameLib.CodeEnumClass.Spellslinger] = "Spellslinger",
	[GameLib.CodeEnumClass.Esper] = "Esper",
	[GameLib.CodeEnumClass.Engineer] = "Engineer",
	[GameLib.CodeEnumClass.Warrior] = "Warrior",
	[GameLib.CodeEnumClass.Stalker] = "Stalker"
}

local showFrame = 1
local editorMode = false
-----------------------------------------------------------------------------------------------
-- Constants
-----------------------------------------------------------------------------------------------
-- e.g. local kiExampleVariableMax = 999
 
-----------------------------------------------------------------------------------------------
-- Initialization
-----------------------------------------------------------------------------------------------
function PotatoResources:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self 

    -- initialize variables here

    return o
end

function PotatoResources:Init()
    Apollo.RegisterAddon(self)
end
 
function PotatoResources:OnLoad()
    -- Register handlers for events, slash commands and timer, etc.
    -- e.g. Apollo.RegisterEventHandler("KeyDown", "OnKeyDown", self)
	Apollo.RegisterEventHandler("CharacterCreated", "OnCharacterCreated", self)
	Apollo.RegisterEventHandler("VarChange_FrameCount", "OnFrame", self)
	Apollo.RegisterEventHandler("UnitEnteredCombat", 			"OnEnteredCombat", self)
	
	Apollo.RegisterEventHandler("PotatoEditor", 			"EditorModeToggle", self)
	Apollo.RegisterEventHandler("PotatoReset", 			"ResetFrames", self)
	
	Apollo.RegisterSlashCommand("potatotest", "PotatoTest", self)
	
	--load our forms
    self.wndMain = Apollo.LoadForm("PotatoResources.xml", "ContainerNew1", "FixedHudStratum", self)
	self.wndMain:SetAnchorPoints(0.5, 1, 0.5, 1)
	self.wndMain:SetAnchorOffsets(-370,-232,-10,-202)
    self.wndMain:Show(true)

	self.wndContent = self.wndMain:FindChild("Bars")
	
	self.wndEngineer = Apollo.LoadForm("PotatoResources.xml", "EngineerButtons", nil, self)
	self.wndEngineer:FindChild("EditorText"):SetText("Pet Bar")	
	
	if GameLib.GetPlayerUnit() then
		self:OnCharacterCreated()
	end
	self.bInCombat = false
	self.tAccountData = {}
end

--P: happens once, when character is made
function PotatoResources:OnCharacterCreated()

	--P: checks if unit is player
	local unitPlayer = GameLib.GetPlayerUnit()
	self.playerClassId = unitPlayer:GetClassId()
	local playerClass = ClassName[self.playerClassId]

	if unitPlayer:GetClassId() == GameLib.CodeEnumClass.Spellslinger or unitPlayer:GetClassId() == GameLib.CodeEnumClass.Esper then
		Apollo.LoadForm("PotatoResources.xml", playerClass .. "2", self.wndMain:FindChild("Bars"), self)
		if not unitPlayer then
			return
		else
			self.wndMain:FindChild(playerClass .. "2"):Show(true)
		end

	else
		Apollo.LoadForm("PotatoResources.xml", playerClass, self.wndMain:FindChild("Bars"), self)
	
		if not unitPlayer then
			return
		else
			self.wndMain:FindChild(playerClass):Show(true)
		end
	end	
	
	local strResource = string.format("<T Font=\"CRB_InterfaceSmall\">%s</T>", Apollo.GetString("CRB_" .. playerClass .. "Resource"))
	self.wndMain:FindChild("Bars"):SetTooltip(strResource)
	
	if playerClass == "Warrior" then
		Apollo.RegisterTimerHandler("WarriorResource_StartOverDriveTimer", 	"OnWarriorResource_StartOverDriveTimer", self)
		Apollo.CreateTimer("WarriorResource_StartOverDriveTimer", 0.01, false)
	
		PotatoLib:SetBarVars("OverdriveBar", self.wndMain, 0, 1, self)
		self.wndMain:FindChild("OverdriveBar"):SetProgress(0)
	end
	
	if playerClass == "Medic" then
		self.tCores = {} -- windows
	
		for idx = 1,4 do
			self.tCores[idx] = 
			{
				--Gives each of the 4 CoreContainer windows an instance of MedicCore window stored in self.tCores[idx].wndCore
				wndCore = Apollo.LoadForm("PotatoResources.xml", "MedicCore",  self.wndMain:FindChild("CoreContainer" .. idx), self),
			}
			self.tCores[idx].wndCore:FindChild("PowerSurge"):SetMax(3)
			self.tCores[idx].wndCore:FindChild("PowerSurge"):SetProgress(0)
		end
	end
	
	if playerClass == "Engineer" then
		if not self.tSavedData then
			self.wndMain:SetAnchorPoints(0.5, 1, 0.5, 1)
			self.wndMain:SetAnchorOffsets(-370,-232,-130,-202)
	
			self.wndEngineer:Show(true)
		end
	else
		self.wndEngineer:Destroy()
	end		
end
	
function PotatoResources:OnFrame()
	local unitPlayer = GameLib.GetPlayerUnit()
	if not unitPlayer or unitPlayer == nil then return end
	if self.strCharacterName == nil then self.strCharacterName = GameLib.GetPlayerUnit():GetName() end

	--[[if not unitPlayer then
		return
	elseif unitPlayer:GetClassId() ~= GameLib.CodeEnumClass.Medic then
		if self.wndMain then
			self.wndMain:Destroy()
		end
		return
	end

	if not self.wndMain:IsValid() then
		return
	end]]--

	if showFrame == 1 or (showFrame == 2 and self.bInCombat) or editorMode then
		self.wndMain:Show(true)
	else
		self.wndMain:Show(false)
	end
	DrawClass[unitPlayer:GetClassId()](self, unitPlayer)

end

function PotatoResources:DrawMedic(unitPlayer)
	local nResourceCurr = unitPlayer:GetResource(1)
	local nResourceMax = unitPlayer:GetMaxResource(1)

	local playerBuffs = unitPlayer:GetBuffs()
	local powerCharge = 0
	local beneficialBuffs = playerBuffs["arBeneficial"]
	
	for key, value in pairs(beneficialBuffs) do
		if value.splEffect:GetId() == 42569 then 
			powerCharge = value.nCount
		end
	end

	for idx = 1, #self.tCores do
		local wndCoreBar = self.tCores[idx].wndCore:FindChild("PowerSurge")
				
		if idx <= nResourceCurr then --if the current core is filled
			--mark core as full
			wndCoreBar:SetProgress(3)
		else
			if idx == nResourceCurr + 1 then --if the core is the next (filling) core
				--partial core full via buffcount
				wndCoreBar:SetProgress(powerCharge)
			else
				wndCoreBar:SetProgress(0)
			end
		end
	end
end

function PotatoResources:DrawEsper(unitPlayer)
	PotatoLib:SetBarVars("EsperManaBar", self.wndMain, unitPlayer:GetMana(), unitPlayer:GetMaxMana())
	PotatoLib:SetBarAppearance("EsperManaBar", self.wndMain, "Charcoal", "ffff44ff", 100)
	local nResourceCurr = unitPlayer:GetResource(1)
	local nResourceMax = unitPlayer:GetMaxResource(1)
	local type = "Disabled"
	for idx = 1, nResourceMax do
		type = idx<=nResourceCurr and "PressedFlyby" or "Disabled"
		self.wndMain:FindChild("EsperContainer"..idx):SetSprite("CRB_UIKitSprites:btn_radioLARGE"..type)
	end
end

function PotatoResources:DrawStalker(unitPlayer)
	PotatoLib:SetBarVars("StalkerResBar", self.wndMain, unitPlayer:GetResource(3), unitPlayer:GetMaxResource(3))
	PotatoLib:SetBarAppearance("StalkerResBar", self.wndMain, "Aluminum", PotatoLib.resourceColors[GameLib.CodeEnumClass.Stalker], 100)
end

function PotatoResources:DrawWarrior(unitPlayer)
	PotatoLib:SetBarVars("WarriorResBar", self.wndMain, unitPlayer:GetResource(1), unitPlayer:GetMaxResource(1))
	PotatoLib:SetBarAppearance("WarriorResBar", self.wndMain, "Aluminum", PotatoLib.resourceColors[GameLib.CodeEnumClass.Warrior], 100)
			
	local bOverdrive = GameLib.IsOverdriveActive()
	
	local bLastKnownOverdriveState = self.wndMain:FindChild("OverdriveBar"):GetData()
	if bOverdrive and not bLastKnownOverdriveState then
		self.wndMain:FindChild("OverdriveBar"):SetData(true)
		self.wndMain:FindChild("OverdriveBar"):SetProgress(1)
		self.wndMain:FindChild("OverdriveBar"):Show(true)
		Apollo.StartTimer("WarriorResource_StartOverDriveTimer")
	elseif not bOverdrive and bLastKnownOverdriveState then
		self.wndMain:FindChild("OverdriveBar"):SetData(false)
		self.wndMain:FindChild("OverdriveBar"):Show(false)
	end
end

function PotatoResources:OnWarriorResource_StartOverDriveTimer()
	local bOverdrive = GameLib.IsOverdriveActive()
	if bOverdrive then
	self.wndMain:FindChild("OverdriveBar"):Show(true)
	self.wndMain:FindChild("OverdriveBar"):SetProgress(0, 1 / 8) -- 2nd arg is rate for animation
	end
end

function PotatoResources:DrawSpellslinger(unitPlayer)
	local currSS = unitPlayer:GetResource(4)
	local maxSS = unitPlayer:GetMaxResource(4)
	
	PotatoLib:SetBarVars("Spellsurge", self.wndMain, currSS, maxSS)
	PotatoLib:SetBarAppearance("Spellsurge", self.wndMain, "Bantobar", "ffffcc00", 100)
	self.wndMain:FindChild("SpellsurgeActive"):Show(GameLib.IsSpellSurgeActive())
	
	for idx=1, 3 do
		self.wndMain:FindChild("Breaker" .. idx):SetAnchorPoints(25/maxSS*idx, 0, 25/maxSS*idx, 1)
	end
end

function PotatoResources:DrawSpellslinger2(unitPlayer)
	local currSP  = unitPlayer:GetResource(4) --150
	local maxSP  = unitPlayer:GetMaxResource(4)
		
	local currOFSP = currSP - 25
	local maxOFSP = maxSP - 25
	
	local curr25SP = currSP
	local max25SP = 25	
	
	PotatoLib:SetBarVars("MainSP", self.wndMain, curr25SP, max25SP)
	PotatoLib:SetBarVars("OFSP", self.wndMain, currOFSP, maxOFSP)
	PotatoLib:SetBarAppearance("MainSP", self.wndMain, "Bantobar", "ffff3300", 100)
	PotatoLib:SetBarAppearance("OFSP", self.wndMain, "Bantobar", "ffffcc00", 100)
	self.wndMain:FindChild("SSActive"):Show(GameLib.IsSpellSurgeActive())
	
	--[[for idx=1, 3 do
		self.wndMain:FindChild("Breaker" .. idx):SetAnchorPoints(25/maxSS*idx, 0, 25/maxSS*idx, 1)
	end]]--
end

function PotatoResources:DrawEngineer(unitPlayer)
	local currRP, maxRP = PotatoLib:GetClassResource(unitPlayer)
	PotatoLib:SetBarVars("EngineerResBar", self.wndMain, currRP, maxRP)
	PotatoLib:SetBarAppearance("EngineerResBar", self.wndMain, "Aluminum", PotatoLib.resourceColors[GameLib.CodeEnumClass.Engineer], 100)
	
	local ktEngineerStanceToShortString =
	{
		[0] = "",
		[1] = Apollo.GetString("EngineerResource_Aggro"),
		[2] = Apollo.GetString("EngineerResource_Defend"),
		[3] = Apollo.GetString("EngineerResource_Passive"),
		[4] = Apollo.GetString("EngineerResource_Assist"),
		[5] = Apollo.GetString("EngineerResource_Stay"),
	}
	local tPetStances = {}
	local strStance = "None"
	for key, unitPet in pairs(GameLib.GetPlayerPets()) do
		if unitPet:GetUnitRaceId() == 298 then
			tPetStances[key] = Pet_GetStance(unitPet:GetId())
		end	
	end	
	if tPetStances[2] ~= nil and tPetStances[1] ~= tPetStances[2] then
		strStance = "Mixed"
	else
		strStance = ktEngineerStanceToShortString[tPetStances[1] or 0]
		for idx=1, 5 do
			local nCurrPetStance = tPetStances[1]
	
			self.wndEngineer:FindChild("Stance"..idx):FindChild("StanceText"):SetTextColor(idx == nCurrPetStance and "FFFFFF00" or "FFFFFFFF")
			self.wndEngineer:FindChild("Stance"..idx):ChangeArt(idx == nCurrPetStance and "CRB_Basekit:kitBtn_List_HoloSort" or "CRB_Basekit:kitBtn_List_Holo")
		end
	end
	self.wndEngineer:FindChild("Stance"):SetText(strStance)
end

function PotatoResources:EditorModeToggle()
	editorMode = not editorMode

	self.wndMain:FindChild("Bars"):GetChildren()[1]:SetStyle("IgnoreMouse", editorMode)
	self.wndMain:SetStyle("Moveable", editorMode)
	self.wndMain:FindChild("EditorCover"):Show(editorMode)
	self.wndMain:SetStyle("Sizable", editorMode)
	if GameLib.GetPlayerUnit():GetClassId() == GameLib.CodeEnumClass.Engineer then
		self.wndEngineer:SetStyle("Moveable", editorMode)
		self.wndEngineer:FindChild("EditorCover"):Show(editorMode)
		self.wndEngineer:SetStyle("Sizable", editorMode)
		self.wndEngineer:FindChild("PetBarIcons"):Show(not editorMode)
		self.wndEngineer:FindChild("Stance"):Show(not editorMode)
		self.wndEngineer:FindChild("FakePetBarIcons"):Show(editorMode)
		self.wndEngineer:FindChild("FakeStance"):Show(editorMode)
	end
end

function PotatoResources:OnSave(eLevel)  --TODO: Improve this code, it's hacky.
    -- create a table to hold our data
    local tSave = {}

	--Save location
	tSave.resourceFrame = { points = {self.wndMain:GetAnchorPoints()}, offsets = {self.wndMain:GetAnchorOffsets()}, showFrame = showFrame }
	if self.playerClassId == GameLib.CodeEnumClass.Engineer then
		tSave.engineerFrame = { points = {self.wndEngineer:GetAnchorPoints()}, offsets = {self.wndEngineer:GetAnchorOffsets()}}
	end
	
	if eLevel == GameLib.CodeEnumAddonSaveLevel.Character then
        return tSave
    elseif eLevel == GameLib.CodeEnumAddonSaveLevel.Account then
		self.tAccountData[self.strCharacterName] = tSave
		return self.tAccountData
	else
		return nil
	end
end

function PotatoResources:OnRestore(eLevel, tData)  --TODO: Improve this code, it's hacky.
    if eLevel == GameLib.CodeEnumAddonSaveLevel.Character then
		self.tSavedData = tData
		
		self.wndMain:SetAnchorPoints(unpack(self.tSavedData.resourceFrame.points))
		self.wndMain:SetAnchorOffsets(unpack(self.tSavedData.resourceFrame.offsets))
		showFrame = self.tSavedData.resourceFrame.showFrame	~= nil and	self.tSavedData.resourceFrame.showFrame or 1

		if self.tSavedData.engineerFrame then
			self.wndEngineer:SetAnchorPoints(unpack(self.tSavedData.engineerFrame.points))
			self.wndEngineer:SetAnchorOffsets(unpack(self.tSavedData.engineerFrame.offsets))
		end
	elseif eLevel == GameLib.CodeEnumAddonSaveLevel.Account then
		self.tAccountData = tData
	end
end

function PotatoResources:ResetFrames()
	if GameLib.GetPlayerUnit():GetClassId() ~= GameLib.CodeEnumClass.Engineer then
		self.wndMain:SetAnchorPoints(0.5,1,0.5,1)
		self.wndMain:SetAnchorOffsets(-370,-232, -10,-202)
		showFrame = 1
	else
		self.wndMain:SetAnchorPoints(0.5,1,0.5,1)
		self.wndMain:SetAnchorOffsets(-370,-234,-130,-202)
		self.wndEngineer:SetAnchorPoints(0.5,1,0.5,1)
		self.wndEngineer:SetAnchorOffsets(-130,-232,-10,-202)
		showFrame = 1
	end
end

function PotatoResources:MouseDownTest(wndHandler, wndControl, eButton, x, y, bDouble)
	local elementName = wndControl:GetName()

	if ((wndHandler:GetName() == "ContainerNew1" and elementName == "Bars") or wndHandler:GetName() == "EngineerButtons") and editorMode then
		self:PopulateEditor(wndHandler, wndControl)
	end
end

function PotatoResources:PopulateEditor(wndHandler, wndControl)
	local PLib = Apollo.GetAddon("PotatoLib")
	PLib.wndCustomize:Show(true)
	PLib.wndCustomize:FindChild("EditorContent"):DestroyChildren()
	PLib:ElementSelected(wndHandler, self)
	
	self.wndCustomize = Apollo.LoadForm("PotatoResources.xml", "MedicCore", PLib.wndCustomize:FindChild("EditorContent"), self) --Ghetto fix.
	PLib.wndCustomize:FindChild("EditorContent"):DestroyChildren() --Oh well.
	
	if wndHandler:GetName() == "ContainerNew1" then
		--Populate PotatoLib editor frame; Set title
		self.wndCustomize = Apollo.LoadForm("PotatoResources.xml", "ResourceCustomize", PLib.wndCustomize:FindChild("EditorContent"), self)
		PLib.wndCustomize:FindChild("Title"):SetText("Resource Frame Settings")
		self.wndCustomize:FindChild("ShowFrame"):FindChild("Options"):SetRadioSel("ShowFrame", showFrame)
	end
	if wndHandler:GetName() == "EngineerButtons" then
		--Populate PotatoLib editor frame; Set title
		self.wndCustomize = Apollo.LoadForm("PotatoResources.xml", "PetBarCustomize", PLib.wndCustomize:FindChild("EditorContent"), self)
		PLib.wndCustomize:FindChild("Title"):SetText("Pet Bar Settings")
		self.wndCustomize:FindChild("ShowFrame"):FindChild("Options"):SetRadioSel("ShowFrame", showFrame)
	end
	
	local nX1, nY1, nX2, nY2 = wndHandler:GetAnchorOffsets()
	local nScreenX, nScreenY = Apollo.GetScreenSize()
	if self.wndCustomize:FindChild("XPos") ~= nil then
		self.wndCustomize:FindChild("XPos"):SetText((nScreenX/2)+nX1)
		self.wndCustomize:FindChild("YPos"):SetText(nScreenY+nY1)
		self.wndCustomize:FindChild("Width"):SetText(nX2-nX1)
		self.wndCustomize:FindChild("Height"):SetText(nY2-nY1)
	end
end

function PotatoResources:OnShowChange( wndHandler, wndControl, eMouseButton )
	local nShowFrame = wndHandler:GetParent():GetRadioSel("ShowFrame") --1 = Always; 2 = Combat; 3 = Never
	
	showFrame = nShowFrame
end

function PotatoResources:OnEnteredCombat(unit, bInCombat)
	if unit:GetName() == GameLib.GetPlayerUnit():GetName() then
		self.bInCombat = bInCombat
	end
end

function PotatoResources:TxtPositionChanged( wndHandler, wndControl, strPos )
	local strChange = wndHandler:GetName()
	
	local wndTarget = self.wndMain
	
	local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()
	local nWidth = nX2-nX1
	local nHeight = nY2-nY1
	local nScreenX, nScreenY = Apollo.GetScreenSize()

	strPos = string.gsub(strPos, "[^0-9.]", "")
	if #strPos > 1 and string.sub(strPos, 1, 1) == "0" then
		strPos = string.gsub(strPos, "0", "", 1)
	end
	
	if strPos == "" then
		strPos = "0"
	end
	
	if strChange == "XPos" then
		wndTarget:SetAnchorOffsets(strPos-nScreenX/2, nY1, strPos-nScreenX/2+nWidth, nY2)
	elseif strChange == "YPos" then
		wndTarget:SetAnchorOffsets(nX1, strPos-nScreenY, nX2, strPos-nScreenY+nHeight)
	end
	
	wndHandler:SetText(strPos)
	wndHandler:SetSel(#strPos,#strPos)
end

function PotatoResources:TxtHWChanged( wndHandler, wndControl, strHW )

	local strChange = wndHandler:GetName()
	
	local wndTarget = self.wndMain
	
	local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()

	strHW = string.gsub(strHW, "[^0-9.]", "")
	if #strHW > 0 and string.sub(strHW, 1, 1) == "0" then
		strHW = string.gsub(strHW, "0", "", 1)
	end
	
	if strHW == "" then
		strHW = "0"
	end	
		
	if strChange == "Width" then
		wndTarget:SetAnchorOffsets(nX1, nY1, nX1+strHW, nY2)
	elseif strChange == "Height" then
		wndTarget:SetAnchorOffsets(nX1, nY1, nX2, nY1+strHW)
	end	
		
	wndHandler:SetText(strHW)
	wndHandler:SetSel(#strHW,#strHW)
end

function PotatoResources:WindowMove( wndHandler, wndControl, nOldLeft, nOldTop, nOldRight, nOldBottom )
	if editorMode and self.wndCustomize then
		local wndTarget = self.wndMain
		
		local nX1, nY1, nX2, nY2 = wndTarget:GetAnchorOffsets()
		local nScreenX, nScreenY = Apollo.GetScreenSize()
		if self.wndCustomize:FindChild("XPos") ~= nil then
			self.wndCustomize:FindChild("XPos"):SetText((nScreenX/2)+nX1)
			self.wndCustomize:FindChild("YPos"):SetText(nScreenY+nY1)
			self.wndCustomize:FindChild("Width"):SetText(nX2-nX1)
			self.wndCustomize:FindChild("Height"):SetText(nY2-nY1)
		end
	end
end
---------------------------------------------------------------------------------------------------
-- EngineerButtons Functions
---------------------------------------------------------------------------------------------------

function PotatoResources:ShowStanceBG( wndHandler, wndControl, eMouseButton )
	if not editorMode then
		self.wndEngineer:FindChild("StanceMenuBG"):Show(not self.wndEngineer:FindChild("StanceMenuBG"):IsVisible())
	end
end

function PotatoResources:OnStanceBtn( wndHandler, wndControl, eMouseButton )
	local nStance = string.gsub(wndHandler:GetName(), "Stance", "") + 0
	Pet_SetStance(0, nStance) -- 0 is for all pets. TODO: Make separate pet control
	self.wndEngineer:FindChild("StanceMenuBG"):Show(false)
end

-----------------------------------------------------------------------------------------------
-- PotatoResources Instance
-----------------------------------------------------------------------------------------------
local PotatoResourcesInst = PotatoResources:new()
PotatoResourcesInst:Init()
