local L = Apollo.GetPackage("Gemini:Locale-1.0").tPackage:NewLocale("SpaceStashBank", "enUS", true)
if not L then return end
 	  	
L["BANKSTASH"] = "Bank"
L["NEXTBAGCOST"] = "Next bag cost"
L["BUYBANKBAGSLOT"] = "Click to buy this slot."
L["EMPTYSLOT"] = "Empty slot. You can drop a bag here to increase your bank space."
L["YOURCASH"] = "Your cash:"
L["SSOPTIONS"] = "Options"
L["SSOPTIONS_TOOLTIP"] = "Open a window to configure SpaceStash Bank."
L["PMCHARS"] = "Characters"

L["EMPTYPLACEHODER"] = "Currently empty placehoder"
L["EMPTYSLOT"] = "Empty slot. You can drop a bag here to increase your bank space."