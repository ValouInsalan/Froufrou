http://www.curse.com/ws-addons/WildStar/220186-spacestash

TODO:
Afficher la capacité des sacs
Adapter la taille des sacs
Tester la position du micro menu des devices.

FIX:
SpaceStashInventory is correctly close by pressing Escape.